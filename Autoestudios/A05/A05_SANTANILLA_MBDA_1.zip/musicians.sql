/*Tables creations*/
CREATE TABLE band (band_no NUMBER(11) NOT NULL,band_name VARCHAR(20),band_home NUMBER(11) NOT NULL, band_type VARCHAR(10), b_date DATE, band_contact NUMBER(11) NOT NULL);
CREATE TABLE composer (comp_no NUMBER(11) NOT NULL, comp_is NUMBER(11) NOT NULL, comp_type VARCHAR(10));
CREATE TABLE composition(c_no NUMBER(11) NOT NULL, comp_date DATE, c_title VARCHAR(40) NOT NULL, c_in NUMBER(11));
CREATE TABLE concert(concert_no	NUMBER(11) NOT NULL, concert_venue VARCHAR(20), concert_in	NUMBER(11) NOT NULL, con_date DATE, concert_orgniser NUMBER(11));
CREATE TABLE place (place_no NUMBER(11) NOT NULL, place_town VARCHAR(20), place_country VARCHAR(20));
CREATE TABLE performer (perf_no NUMBER(11) NOT NULL, perf_is NUMBER(11), instrument VARCHAR(10) NOT NULL, perf_type VARCHAR(10));
CREATE TABLE performanceTable (pfrmnc_no NUMBER(11) NOT NULL, gave NUMBER(11),performed NUMBER(11),conducted_by NUMBER(11),performed_in	NUMBER(11));
CREATE TABLE musician(m_no NUMBER(11) NOT NULL,m_name VARCHAR(20),born DATE,died DATE,born_in NUMBER(11),living_in NUMBER(11));
CREATE TABLE has_composed (cmpr_no NUMBER(11) NOT NULL, cmpn_no NUMBER(11) NOT NULL);
CREATE TABLE plays_in (player NUMBER(11) NOT NULL, band_id NUMBER(11) NOT NULL);

/*Primary keys*/
ALTER TABLE band ADD CONSTRAINT PK_band PRIMARY KEY (band_no);
ALTER TABLE composer ADD CONSTRAINT PK_composer PRIMARY KEY (comp_no);
ALTER TABLE composition ADD CONSTRAINT PK_composition PRIMARY KEY (c_no);
ALTER TABLE concert ADD CONSTRAINT PK_concert PRIMARY KEY(concert_no);
ALTER TABLE place ADD CONSTRAINT PK_place PRIMARY KEY (place_no);
ALTER TABLE performer ADD CONSTRAINT PK_performer PRIMARY KEY (perf_no);
ALTER TABLE performanceTable ADD CONSTRAINT PK_performance PRIMARY KEY(pfrmnc_no);
ALTER TABLE musician ADD CONSTRAINT PK_m_no PRIMARY KEY (m_no);
ALTER TABLE has_composed ADD CONSTRAINT PK_has_composed PRIMARY KEY (cmpr_no, cmpn_no);
ALTER TABLE plays_in ADD CONSTRAINT PK_plays_in PRIMARY KEY (player, band_id);

/*Unique values*/
ALTER TABLE band ADD CONSTRAINT UK_band_name UNIQUE (band_name);
ALTER TABLE composition ADD  CONSTRAINT UK_c_title UNIQUE (c_title);
ALTER TABLE place ADD CONSTRAINT UK_place_town UNIQUE (place_town);

/*Foreign Keys*/
ALTER TABLE band ADD CONSTRAINT FK_band_place FOREIGN KEY(band_no) REFERENCES place(place_no);
ALTER TABLE band ADD CONSTRAINT FK_band_musician  FOREIGN KEY(band_contact) REFERENCES musician(m_no);
ALTER TABLE composer ADD CONSTRAINT FK_composer_musician FOREIGN KEY(comp_is) REFERENCES musician(m_no);
ALTER TABLE composition ADD CONSTRAINT FK_compostion_place FOREIGN KEY(c_in) REFERENCES place(place_no);
ALTER TABLE concert ADD CONSTRAINT FK_concert_place FOREIGN KEY(concert_in) REFERENCES place(place_no);
ALTER TABLE concert ADD CONSTRAINT FK_concert_musician FOREIGN KEY(concert_orgniser) REFERENCES musician(m_no);
ALTER TABLE performer ADD CONSTRAINT FK_performer_musician FOREIGN KEY(perf_is) REFERENCES musician(m_no);
ALTER TABLE performanceTable ADD CONSTRAINT FK_performance_band FOREIGN KEY(gave) REFERENCES band(band_no);
ALTER TABLE performanceTable ADD CONSTRAINT FK_performance_composition FOREIGN KEY(performed) REFERENCES composition(c_no);
ALTER TABLE performanceTable ADD CONSTRAINT FK_performance_musician FOREIGN KEY(conducted_by) REFERENCES musician(m_no);
ALTER TABLE performanceTable ADD CONSTRAINT FK_performance_concert FOREIGN KEY(performed_in) REFERENCES concert(concert_no);
ALTER TABLE musician ADD CONSTRAINT FK_musician_place_b FOREIGN KEY(born_in) REFERENCES place(place_no);
ALTER TABLE musician ADD CONSTRAINT FK_musician_place_1 FOREIGN KEY(living_in) REFERENCES place(place_no);
ALTER TABLE has_composed ADD CONSTRAINT FK_has_composed_composer FOREIGN KEY(cmpr_no) REFERENCES composer(comp_no);
ALTER TABLE has_composed ADD CONSTRAINT FK_has_composed_composition FOREIGN KEY(cmpn_no) REFERENCES composition(c_no);
ALTER TABLE plays_in ADD CONSTRAINT FK_plays_in_band FOREIGN KEY(band_id) REFERENCES band(band_no);
ALTER TABLE plays_in ADD CONSTRAINT FK_plays_in_performer FOREIGN KEY(player) REFERENCES performer(perf_no); 

/*Insert to place*/
INSERT INTO place (place_no, place_town, place_country) VALUES (1,'Manchester','England');
INSERT INTO place (place_no, place_town, place_country) VALUES (2,'Edinburgh','Scotland');
INSERT INTO place (place_no, place_town, place_country) VALUES (3,'Salzburg','Austria');
INSERT INTO place (place_no, place_town, place_country) VALUES (4,'New York','USA');
INSERT INTO place (place_no, place_town, place_country) VALUES (5,'Birmingham','England');
INSERT INTO place (place_no, place_town, place_country) VALUES (6,'Glasgow','Scotland');
INSERT INTO place (place_no, place_town, place_country) VALUES (7,'London','England');
INSERT INTO place (place_no, place_town, place_country) VALUES (8,'Chicago','USA');
INSERT INTO place (place_no, place_town, place_country) VALUES (9,'Amsterdam','Netherlands');

/*Insert to musician*/
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (1, 'Fred Bloggs', '02/01/48',NULL, 1, 2);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (2, 'John Smith', '03/03/50',NULL, 3, 4);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (3, 'Helen Smyth', '08/08/48',NULL, 4, 5);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (4, 'Harriet Smithson', '09/05/1909', '20/09/80', 5, 6);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (5, 'James First', '10/06/65',NULL, 7, 7);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (6, 'Theo Mengel', '12/08/48',NULL, 7, 1);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (7, 'Sue Little', '21/02/45',NULL, 8, 9);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (8, 'Harry Forte', '28/02/51',NULL, 1, 8);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (9, 'Phil Hot', '30/06/42',NULL, 2, 7);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (10, 'Jeff Dawn', '12/12/45',NULL, 3, 6);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (11, 'Rose Spring', '25/05/48',NULL, 4, 5);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (12, 'Davis Heavan', '03/10/75',NULL, 5, 4);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (13, 'Lovely Time', '28/12/48',NULL, 6, 3);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (14, 'Alan Fluff', '15/01/35','15/05/97' , 7, 2);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (15, 'Tony Smythe', '02/04/32',NULL, 8, 1);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (16, 'James Quick', '08/08/1924',NULL, 9, 2);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (17, 'Freda Miles', '04/07/1920',NULL, 9, 3);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (18, 'Elsie James', '06/05/47',NULL, 8, 5);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (19, 'Andy Jones', '08/10/58',NULL, 7, 6);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (20, 'Louise Simpson', '10/01/48', '11/02/98', 6, 6);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (21, 'James Steeple', '10/01/47',NULL, 5, 6);
INSERT INTO musician (m_no, m_name, born, died, born_in, living_in) VALUES (22, 'Steven Chaytors', '11/03/56',NULL, 6, 7);

/*Insert to composer*/
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (1,1,'jazz');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (2,3,'classical');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (3,5,'jazz');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (4,7,'classical');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (5,9,'jazz');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (6,11,'rock');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (7,13,'classical');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (8,15,'jazz');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (9,17,'classical');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (10,19,'jazz');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (11,10,'rock');
INSERT INTO composer (comp_no, comp_is, comp_type) VALUES (12,8,'jazz');

/*Insert to performer*/
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (1,2,'violin','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (2,4,'viola','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (3,6,'banjo','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (4,8,'violin','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (5,12,'guitar','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (6,14,'violin','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (7,16,'trumpet','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (8,18,'viola','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (9,20,'bass','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (10,2,'flute','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (11,20,'cornet','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (12,6,'violin','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (13,8,'drums','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (14,10,'violin','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (15,12,'cello','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (16,14,'viola','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (17,16,'flute','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (18,18,'guitar','not known');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (19,20,'trombone','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (20,3,'horn','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (21,5,'violin','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (22,7,'cello','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (23,2,'bass','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (24,4,'violin','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (25,6,'drums','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (26,8,'clarinet','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (27,10,'bass','jazz');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (28,12,'viola','classical');
INSERT INTO performer (perf_no, perf_is, instrument, perf_type) VALUES (29,18,'cello','classical');

/*Insert to band*/
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (1, 'ROP', 5, 'classical', '30/01/01', 11);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (2,'AASO',6,'classical',null,10);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (3,'The J Bs',8,'jazz',null,12);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (4,'BBSO',9,'classical',null,21);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (5,'The left Overs',2,'jazz',null,8);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (6,'Somebody Loves this',1,'jazz',null,6);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (7,'Oh well',4,'classical',null,3);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (8,'Swinging strings',4,'classical',null,7);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (9,'The Rest',9,'jazz',null,16);

/*Insert to composition*/
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (1, '17/06/75', 'Opus 1', 1);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (2, '21/07/76', 'Here Goes', 2);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (3, '14/12/81', 'Valiant Knight', 3);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (4, '12/01/82', 'Little Piece', 4);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (5, '13/03/85', 'Simple Song', 5);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (6, '14/04/86', 'Little Swing Song', 6);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (7, '13/05/87', 'Fast Journey', 7);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (8, '14/02/76', 'Simple Love Song', 8);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (9, '21/01/82', 'Complex Rythms', 9);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (10, '23/02/85', 'Drumming Rythms', 9);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (11, '18/03/78', 'Fast Drumming', 8);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (12, '13/08/84', 'Slow Song', 7);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (13, '14/09/68', 'Blue Roses', 6);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (14, '15/11/83', 'Velvet Rain', 5);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (15, '16/05/82', 'Cold Wind', 4);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (16, '18/06/83', 'After the Wind Blows', 3);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (17, NULL, 'A Simple Piece', 2);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (18, '12/01/85', 'Long Rythms', 1);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (19, '12/02/88', 'Eastern Wind', 1);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (20, NULL , 'Slow Symphony Blowing', 2);
INSERT INTO composition (c_no, comp_date, c_title, c_in) VALUES (21, '12/07/90', 'A Last Song', 6);

/*Insert to concert*/
INSERT INTO concert VALUES(1, 'Bridgewater Hall', 1, TO_DATE('1995/01/06','YYYY/MM/DD'), 21);
INSERT INTO concert VALUES(2, 'Bridgewater Hall', 1, TO_DATE('1996/05/08','YYYY/MM/DD'), 3);
INSERT INTO concert VALUES(3, 'Usher Hall', 2, TO_DATE('1995/06/03','YYYY/MM/DD'), 3);
INSERT INTO concert VALUES(4, 'Assembly Rooms', 2, TO_DATE('1997/09/20','YYYY/MM/DD'), 21);
INSERT INTO concert VALUES(5, 'Festspiel Haus', 3, TO_DATE('1995/02/21','YYYY/MM/DD'), 8);
INSERT INTO concert VALUES(6, 'Royal Albert Hall', 7, TO_DATE('1993/04/12','YYYY/MM/DD'), 8);
INSERT INTO concert VALUES(7, 'Concertgebouw', 9, TO_DATE('1993/05/14','YYYY/MM/DD'), 8);
INSERT INTO concert VALUES(8, 'Metropolitan', 4, TO_DATE('1997/06/15','YYYY/MM/DD'), 21);

/*Insert to percormance*/
INSERT INTO performanceTable VALUES(1, 1, 1, 21, 1);
INSERT INTO performanceTable VALUES(2, 1, 3, 21, 1);
INSERT INTO performanceTable VALUES(3, 1, 5, 21, 1);
INSERT INTO performanceTable VALUES(4, 1, 2, 1, 2);
INSERT INTO performanceTable VALUES(5, 2, 4, 21, 2);
INSERT INTO performanceTable VALUES(6, 2, 6, 21, 2);
INSERT INTO performanceTable VALUES(7, 4, 19, 9, 3);
INSERT INTO performanceTable VALUES(8, 4, 20, 10, 3);
INSERT INTO performanceTable VALUES(9, 5, 12, 10, 4);
INSERT INTO performanceTable VALUES(10, 5, 13, 11, 4);
INSERT INTO performanceTable VALUES(11, 3, 5, 13, 5);
INSERT INTO performanceTable VALUES(12, 3, 6, 13, 5);
INSERT INTO performanceTable VALUES(13, 3, 7, 13, 5);
INSERT INTO performanceTable VALUES(14, 6, 20, 14, 6);
INSERT INTO performanceTable VALUES(15, 8, 12, 15, 7);
INSERT INTO performanceTable VALUES(16, 9, 16, 21, 8);
INSERT INTO performanceTable VALUES(17, 9, 17, 21, 8);
INSERT INTO performanceTable VALUES(18, 9, 18, 21, 8);
INSERT INTO performanceTable VALUES(19, 9, 19, 21, 8);
INSERT INTO performanceTable VALUES(20, 4, 12, 10, 3);

/*Insert to has_composed*/
INSERT INTO has_composed VALUES (1,1);
INSERT INTO has_composed VALUES (1,8);
INSERT INTO has_composed VALUES (2,11);
INSERT INTO has_composed VALUES (3,2);
INSERT INTO has_composed VALUES (3,13);
INSERT INTO has_composed VALUES (3,14);
INSERT INTO has_composed VALUES (3,18);
INSERT INTO has_composed VALUES (4,12);
INSERT INTO has_composed VALUES (4,20);
INSERT INTO has_composed VALUES (5,3);
INSERT INTO has_composed VALUES (5,13);
INSERT INTO has_composed VALUES (5,14);
INSERT INTO has_composed VALUES (6,15);
INSERT INTO has_composed VALUES (6,21);
INSERT INTO has_composed VALUES (7,4);
INSERT INTO has_composed VALUES (7,9);
INSERT INTO has_composed VALUES (8,16);
INSERT INTO has_composed VALUES (9,5);
INSERT INTO has_composed VALUES (9,10);
INSERT INTO has_composed VALUES (10,17);
INSERT INTO has_composed VALUES (11,6);
INSERT INTO has_composed VALUES (12,7);
INSERT INTO has_composed VALUES (12,19);

/*Insert to plays_in*/
INSERT INTO plays_in (player, band_id) VALUES(1, 1);
INSERT INTO plays_in (player, band_id) VALUES(1, 7);
INSERT INTO plays_in (player, band_id) VALUES(3, 1);
INSERT INTO plays_in (player, band_id) VALUES(4, 1);
INSERT INTO plays_in (player, band_id) VALUES(4, 7);
INSERT INTO plays_in (player, band_id) VALUES(5, 1);
INSERT INTO plays_in (player, band_id) VALUES(6, 1);
INSERT INTO plays_in (player, band_id) VALUES(6, 7);
INSERT INTO plays_in (player, band_id) VALUES(7, 1);
INSERT INTO plays_in (player, band_id) VALUES(8, 1);
INSERT INTO plays_in (player, band_id) VALUES(8, 7);
INSERT INTO plays_in (player, band_id) VALUES(10, 2);
INSERT INTO plays_in (player, band_id) VALUES(12, 2);
INSERT INTO plays_in (player, band_id) VALUES(13, 2);
INSERT INTO plays_in (player, band_id) VALUES(14, 2);
INSERT INTO plays_in (player, band_id) VALUES(14, 8);
INSERT INTO plays_in (player, band_id) VALUES(15, 2);
INSERT INTO plays_in (player, band_id) VALUES(15, 8);
INSERT INTO plays_in (player, band_id) VALUES(17, 2);
INSERT INTO plays_in (player, band_id) VALUES(18, 2);
INSERT INTO plays_in (player, band_id) VALUES(19, 3);
INSERT INTO plays_in (player, band_id) VALUES(20, 3);
INSERT INTO plays_in (player, band_id) VALUES(21, 4);
INSERT INTO plays_in (player, band_id) VALUES(22, 4);
INSERT INTO plays_in (player, band_id) VALUES(23, 4);
INSERT INTO plays_in (player, band_id) VALUES(25, 5);
INSERT INTO plays_in (player, band_id) VALUES(26, 6);
INSERT INTO plays_in (player, band_id) VALUES(27, 6);
INSERT INTO plays_in (player, band_id) VALUES(28, 7);
INSERT INTO plays_in (player, band_id) VALUES(28, 8);
INSERT INTO plays_in (player, band_id) VALUES(29, 7);

/*CONSULTAS*/
/*Consulta 1*/
 SELECT m_name AS organiser
 FROM musician 
 WHERE m_no = (SELECT concert_orgniser
      FROM concert
      WHERE concert_venue = 'Assembly Rooms');
 
/*Consulta 2*/
 SELECT m_name FROM musician
 WHERE born_in IN (SELECT place_no FROM place
 WHERE place_country = 'England') 
 AND m_no IN (SELECT perf_is FROM performer
 WHERE instrument = 'violin' OR instrument = 'guitar');
 
/*Consulta 3*/
 SELECT DISTINCT m_name,place_town,con_date
 FROM performanceTable
 JOIN concert ON (performed_in =concert_no)
 JOIN musician on (conducted_by = m_no)
 JOIN place ON (place_no=concert_in)
 WHERE place_country = 'USA';
 
/*Consulta 4*/
 SELECT con_date, concert_venue, c_title
 FROM musician
 JOIN composer ON (m_no= comp_is)
 JOIN has_composed ON (comp_no= cmpr_no)
 JOIN composition ON (cmpn_no= c_no)
 JOIN performanceTable ON (c_no = performed)
 JOIN concert ON (performed_in = concert_no)
 WHERE m_name = 'Andy Jones';
 
/*Consulta 5
 SELECT instrument, num_mus/(SELECT sum(num_mus) FROM 
 ((SELECT instrument, COUNT(m_name) AS num_mus FROM musician 
   JOIN performer ON (m_no=perf_is)
   GROUP BY instrument) AS b) AS average_num_mus
   FROM (SELECT instrument, COUNT(m_name) as num_mus
   FROM musician
      JOIN performer 
         on (m_no=perf_is)
   GROUP BY instrument) as a;*/


/*MANTAIN A BAND*/
/*Atribute restriction*/
ALTER TABLE band ADD CONSTRAINT CK_band_type CHECK (band_type NOT LIKE '% %');
ALTER TABLE band ADD CONSTRAINT CK_band_name CHECK (band_name LIKE '_%');
/*Tuple restriction*/
ALTER TABLE plays_in DROP CONSTRAINT FK_plays_in_band;
ALTER TABLE plays_in ADD CONSTRAINT FK_PLAY_IN_BAND FOREIGN KEY (band_id) REFERENCES band(band_no) ON DELETE CASCADE;

/*Disparadores*/
CREATE OR REPLACE TRIGGER TR_BAND_BI
    BEFORE INSERT ON band
FOR EACH ROW 
DECLARE
    band_num NUMBER(11);
    band_date DATE;
BEGIN
    SELECT MAX(band_no) INTO band_num FROM band;
    IF band_num IS NULL THEN
        band_num := 0;  
    END IF;
    SELECT CURRENT_DATE INTO band_date FROM DUAL;
    IF :new.band_type IS NULL THEN
        :new.band_type := 'rock';
    END IF;
    :new.band_no := band_num+1;
    :new.b_date := band_date;
END;

CREATE OR REPLACE TRIGGER TR_BAND_BU
    BEFORE UPDATE ON band
FOR EACH ROW
BEGIN
    :new.band_no := :old.band_no;
    :new.band_name := :old.band_name;
    :new.band_home := :old.band_home;
    :new.b_date := :old.b_date;
    :new.band_contact := :old.band_contact;
END;

CREATE OR REPLACE TRIGGER TR_PLAYS_IN_BI
    BEFORE INSERT ON plays_in
FOR EACH ROW
DECLARE
    V_player NUMBER(11);
    V_band_id NUMBER(11);
    V_band_contact NUMBER(11);
BEGIN
    V_band_id := :new.band_id;
    V_player := :new.player;
    SELECT band_contact INTO V_band_contact FROM band WHERE V_band_id = band_no;
    IF V_player = V_band_contact THEN
        RAISE_APPLICATION_ERROR(-20601,'El contacto de la banda no puede aparecer como inteprete.');
    END IF;
END;

CREATE OR REPLACE TRIGGER TR_PLAYS_IN_BU
    BEFORE UPDATE ON plays_in
BEGIN
    IF :new.player != :old.player THEN
        RAISE_APPLICATION_ERROR(-20600,'No se puede modificar el interprete.');
    END IF;
END;

CREATE OR REPLACE TRIGGER TR_PLAYS_IN_BD
    BEFORE UPDATE ON plays_in
BEGIN
    RAISE_APPLICATION_ERROR(-20600,'No se puede eliminar el interprete.');
END;

/*DisparadoresOk*/
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (1, 'ROP', 5, 'classical', '30/01/01', 11);
INSERT INTO band (band_no, band_name, band_home, band_type, b_date, band_contact) VALUES (9,'The Rest',9,'jazz',null,16);
UPDATE band SET band_type='clasical' WHERE band_name = 'The Rest';
UPDATE band SET band_name='clasical' WHERE band_name = 'The Rest';
INSERT INTO plays_in (player, band_id) VALUES (7,1);

/*DisparadoresNoOk*/
INSERT INTO plays_in (player, band_id) VALUES (11,1);

/*CRUDE*/
CREATE OR REPLACE PACKAGE PC_BANDS IS
    FUNCTION ad (name IN VARCHAR, home IN NUMBER, type IN VARCHAR, contact IN NUMBER) RETURN NUMBER;
    PROCEDURE up_type (band IN NUMBER, type IN VARCHAR);
    PROCEDURE up_ad_player (band IN NUMBER, player IN NUMBER);
    FUNCTION co_band (band IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_players (band IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE de (band IN NUMBER);
    FUNCTION co_byComposer (composer IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_theBigOnes RETURN SYS_REFCURSOR;
END;

/*CRUDI*/
CREATE OR REPLACE PACKAGE BODY PC_BANS IS
    PROCEDURE up_type (band IN NUMBER, type IN VARCHAR) IS
        BEGIN
            UPDATE band SET band_type = type WHERE band_no = band;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR (-20001,'Error al actualizar el tipo de banda');
        END;
    
    PROCEDURE up_ad_player (band IN NUMBER, player IN NUMBER) IS
        BEGIN
            UPDATE band SET band_contact = player WHERE band_no = band;
            COMMIT;
            EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                RAISE_APPLICATION_ERROR (-20001,'Error al actualizar el tipo de banda');
        END;
    

END;

/*XPoblar*/
DELETE FROM performanceTable;
DELETE FROM plays_in;
DELETE FROM has_composed;
DELETE FROM concert;
DELETE FROM composition;
DELETE FROM band;
DELETE FROM performer;
DELETE FROM composer;
DELETE FROM musician;
DELETE FROM place;
 
/*XTablas*/
DROP TABLE band CASCADE CONSTRAINTS;
DROP TABLE composition CASCADE CONSTRAINTS;
DROP TABLE concert CASCADE CONSTRAINTS;
DROP TABLE musician CASCADE CONSTRAINTS;
DROP TABLE place CASCADE CONSTRAINTS;
DROP TABLE composer  CASCADE CONSTRAINTS;
DROP TABLE performer CASCADE  CONSTRAINTS;
DROP TABLE performanceTable CASCADE CONSTRAINTS;
DROP TABLE has_composed CASCADE CONSTRAINTS;
DROP TABLE plays_in CASCADE CONSTRAINTS;

/*XDisparadores*/
DROP TRIGGER TR_BAND_BI;
DROP TRIGGER TR_BAND_BU;
DROP TRIGGER TR_PLAYS_IN_BI;
DROP TRIGGER TR_PLAYS_IN_BU;
DROP TRIGGER TR_PLAYS_IN_BD;

/*XCRUD*/
DROP PACKAGE PC_BANDS;

      