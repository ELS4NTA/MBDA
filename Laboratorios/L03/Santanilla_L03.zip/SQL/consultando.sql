/*Consultar cuentas que tienen mas suscripcinoes
las 10 cuentas con mas suscripciones*/
SELECT nameAccount, suscrcibers FROM accounts 
WHERE rownum<=10 ORDER BY suscrcibers;

/*Consultar los usuarios con mas contenido en la platafroma
las 100 cuentas con mas contenido en la paltamorma*/
SELECT nameUsuario, COUNT(idContent) AS num_content 
FROM usuarios JOIN contentsYT ON (idUsuario = usuario_id) 
WHERE rownum<=100 ORDER BY num_content DESC;