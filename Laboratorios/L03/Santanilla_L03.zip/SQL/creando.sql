/*Tablas*/
/*GC yellow astah*/
CREATE TABLE usuarios (
idUsuario NUMBER(5) NOT NULL,
email VARCHAR2(100) NOT NULL,
nameUsuario VARCHAR2(50) NOT NULL,
createAt DATE
);
CREATE TABLE likes (
usuarios_id NUMBER(5) NOT NULL, 
contentsYT_id NUMBER(10) NOT NULL
);

/*GC green astah*/
CREATE TABLE accounts (
idAccount NUMBER(5) NOT NULL,
nameAccount VARCHAR(70) NOT NULL,
createdAt DATE NOT NULL,
suscrcibers NUMBER(5),
usuario_id NUMBER(5)
);
CREATE TABLE exclusiveness (
code VARCHAR2(9) NOT NULL,
orderExcl NUMBER(3),
nameExcl VARCHAR(55),
price NUMBER(9),
durationExcl NUMBER(2),
account_id NUMBER(5)
);
CREATE TABLE lables (
exclusiveness_code VARCHAR2(9) NOT NULL,
labelExclusivenes VARCHAR(10)
);

/*GC blue astah*/
CREATE TABLE subscriptions (
idSubsciption NUMBER(5) NOT NULL,
createAt DATE,
detail VARCHAR(50),
account_id NUMBER(5)
);
CREATE TABLE stages (
idStage NUMBER(10) NOT NULL,
startAt DATE,
endAt DATE,
price NUMBER(9),
status CHAR,
exclusiveness_code VARCHAR2(9),
subscription_id NUMBER(5)
);

/*GC red astah*/
CREATE TABLE contentsYT (
idContent NUMBER(10) NOT NULL,
title VARCHAR(20) NOT NULL,
publishingDate DATE NOT NULL,
descriptionContent VARCHAR2(30),
usuario_id NUMBER(5),
exclusiveness_code VARCHAR2(9)
);
CREATE TABLE videos (
contentsYT_id NUMBER(10) NOT NULL,
durationVideo NUMBER(4) NOT NULL
);
CREATE TABLE eventsYT (
events_contentsYT_id NUMBER(10) NOT NULL,
plannedDate DATE NOT NULL,
actualDate DATE,
durationEvent NUMBER(4)
);
CREATE TABLE posts (
contentsYT_id NUMBER(10) NOT NULL,
textPost VARCHAR(50) NOT NULL
);

/*XTablas*/
DROP TABLE usuarios PURGE;
DROP TABLE likes PURGE;
DROP TABLE accounts PURGE;
DROP TABLE exclusiveness PURGE;
DROP TABLE lables PURGE;
DROP TABLE subscriptions PURGE;
DROP TABLE stages PURGE;
DROP TABLE contentsYT PURGE;
DROP TABLE videos PURGE;
DROP TABLE eventsYT PURGE;
DROP TABLE posts PURGE;




