INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (1, 'rfloyde0@ow.ly', 'Rowney Floyde', '12/05/2021');
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (2, 'kzorzin1@theglobeandmail.com', 'Kirstyn Zorzin', '2/04/2013');
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (3, 'atwydell2@usgs.gov', 'Andromache Twydell', '10/05/2005');
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (4, 'pheinicke3@irs.gov', 'Prudi Heinicke', '11/05/2005');
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (5, 'dwillgoose4@usnews.com', 'Durante Willgoose', '5/03/2013');
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (3, 4);
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (1, 5);
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (1, 5);
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (4, 2);
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (5, 1);

INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (1, 'lingle0', '08/06/2021', '25', 1);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (2, 'mjereatt1', '29/06/2020', '75', 2);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (3, 'aklimt2', '24/07/2021', '55', 3);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (4, 'efaust3', '16/10/2019', '15', 4);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (5, 'bmcturk4', '15/02/2019', '25', 5);

INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (1, '1/31/2022', null, 5);
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (2, '3/2/2022', null, 4);
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (3, '8/19/2021', null, 2);
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (4, '4/14/2021', null, 2);
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (5, '4/23/2021', null, 2);