/*PoblarOK*/
/*1*/
/*usuarios*/
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (1, 'jaime1234@hotmail.com', 'Jaime',  to_date('05/03/2017', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (2, 'estefantuyo@hotmail.com', 'Estefania',  to_date('05/02/2022', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (3, 'danixdani@hotmail.com', 'Daniela',  to_date('05/01/2020', 'dd/mm/yyyy'));
/*likes*/
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (1, 2);
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (2, 2);
INSERT INTO likes (usuarios_id, contentsYT_id) VALUES (3, 1);

/*accounts*/
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (1, 'JaimeTutos',  to_date('23/05/2017', 'dd/mm/yyyy'), 9890, 1);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (2, 'Pantufla',  to_date('16/07/2020', 'dd/mm/yyyy'), 1000, 3);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (3, 'Laboratorios',  to_date('05/03/2022', 'dd/mm/yyyy'), 1000, 2);
/*exclusiveness*/
INSERT INTO exclusiveness (code, orderExcl, nameExcl, price, durationExcl, account_id) VALUES ('EX-000010', 10, 'Bronce', 0,30,1);
INSERT INTO exclusiveness (code, orderExcl, nameExcl, price, durationExcl, account_id) VALUES ('EX-000020', 20, 'Oro', 70000,60,1);
INSERT INTO exclusiveness (code, orderExcl, nameExcl, price, durationExcl, account_id) VALUES ('EX-000030', 30, 'Pastelito', 0,30,3);
/*lables*/
INSERT INTO lables (exclusiveness_code, labelExclusivenes) VALUES ('EX-1','#TECNOLO');
INSERT INTO lables (exclusiveness_code, labelExclusivenes) VALUES ('EX-2','#CURSOS');
INSERT INTO lables (exclusiveness_code, labelExclusivenes) VALUES ('EX-3','#H1GH_FLY');

/*subscriptions*/
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (1,  to_date('01/03/2022', 'dd/mm/yyyy'), 'Bronce', 2);
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (2,  to_date('01/08/2021', 'dd/mm/yyyy'), 'Oro', 3);
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (3,  to_date('01/10/2021', 'dd/mm/yyyy'), 'Pastelito', 3);
/*stages*/
INSERT INTO stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) VALUES (1,  to_date('01/03/2022', 'dd/mm/yyyy'),  to_date('01/04/2022', 'dd/mm/yyyy'),0,'T','EX-000030',1);
INSERT INTO stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) VALUES (2,  to_date('01/03/2021', 'dd/mm/yyyy'),  to_date('01/05/2021', 'dd/mm/yyyy'),70000,'T','EX-000020',2);
INSERT INTO stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) VALUES (3,  to_date('01/10/2021', 'dd/mm/yyyy'),  to_date('01/11/2021', 'dd/mm/yyyy'),0,'T','EX-000030',3);

/*contentsYT*/
INSERT INTO contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) VALUES (1, 'Cursos',  to_date('02/06/2017', 'dd/mm/yyyy'), NULL, 1, 'EX-000020');
INSERT INTO contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) VALUES (2, 'Volgs',  to_date('03/08/2020', 'dd/mm/yyyy'), NULL, 3, 'EX-000020');
INSERT INTO contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) VALUES (3, 'Tutoriales',  to_date('20/02/2018', 'dd/mm/yyyy'),NULL,1, 'EX-000020');
/*videos*/
INSERT INTO videos (contentsYT_id, durationVideo) VALUES (2, 15);
INSERT INTO videos (contentsYT_id, durationVideo) VALUES (1, 78);
INSERT INTO videos (contentsYT_id, durationVideo) VALUES (3, 10);
/*eventsYT*/
INSERT INTO eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) VALUES (1,  to_date('02/06/2017', 'dd/mm/yyyy'),  to_date('02/06/2017', 'dd/mm/yyyy'), 120);
INSERT INTO eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) VALUES (1,  to_date('02/07/2017', 'dd/mm/yyyy'),  to_date('05/07/2017', 'dd/mm/yyyy'), 130);
INSERT INTO eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) VALUES (1,  to_date('02/08/2017', 'dd/mm/yyyy'),  to_date('02/08/2017', 'dd/mm/yyyy'), 400);
/*posts*/
INSERT INTO posts (contentsYT_id, textPost) VALUES (2, 'En casita');
INSERT INTO posts (contentsYT_id, textPost) VALUES (1, 'Tutorial cerca de publicarse');
INSERT INTO posts (contentsYT_id, textPost) VALUES (2, 'Cocinando con mi pareja');

/*PoblarNoOk*/
/*2*/
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (NULL, 'jaime1234@hotmail.com', 'Jaime', 05/03/2017);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES ('CanalJaime', 'JaimeTutos', 23/05/2017, 9890, 1);
INSERT INTO subscriptions (idSubsciption, createAt, detail, account_id) VALUES (1, 01/03/2022, 'Bronce', 2);
INSERT INTO stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) VALUES (1, '22/03/01', 01/04/2022,0,'T','EX-000030',1);
INSERT INTO contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) VALUES (1, NULL, 02/06/2017, NULL, 1, 'EX-000020');
/*3*/
INSERT INTO exclusiveness (code, orderExcl, nameExcl, price, durationExcl, account_id) VALUES ('0192', 10, 'Bronce', 0,30,1);
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (1, 'jaime1234.com', 'Jaime', 05/03/2017);
INSERT INTO videos (contentsYT_id, durationVideo) VALUES (2, 1500);
INSERT INTO eventsYT (contentsYT_id, durationVideo) VALUES (2, 2000);
INSERT INTO stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) VALUES (1, '22/03/01', 22/04/01,-300,'T','EX-000030',1);

/*XPoblar*/
DELETE FROM usuarios;
DELETE FROM likes;
DELETE FROM accounts;
DELETE FROM exclusiveness;
DELETE FROM lables;
DELETE FROM subscriptions;
DELETE FROM stages;
DELETE FROM contentsYT;
DELETE FROM videos;
DELETE FROM eventsYT;
DELETE FROM posts;









