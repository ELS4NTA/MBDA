/*TABLAS*/
/*GC yellow astah*/
CREATE TABLE usuarios (idUsuario NUMBER(5) NOT NULL, email VARCHAR2(100) NOT NULL, nameUsuario VARCHAR2(50) NOT NULL, createAt DATE);
CREATE TABLE likes (usuarios_id NUMBER(5) NOT NULL, contentsYT_id NUMBER(10) NOT NULL);
/*GC green astah*/
CREATE TABLE accounts (idAccount NUMBER(5) NOT NULL, nameAccount VARCHAR(70) NOT NULL, createdAt DATE NOT NULL, suscrcibers NUMBER(5), usuario_id NUMBER(5));
CREATE TABLE exclusiveness (code VARCHAR2(9) NOT NULL, orderExcl NUMBER(3), nameExcl VARCHAR(55), price NUMBER(9), durationExcl NUMBER(2), account_id NUMBER(5) NOT NULL);
CREATE TABLE labels (exclusiveness_code VARCHAR2(9) NOT NULL, labelExclusivenes VARCHAR(10));
/*GC blue astah*/
CREATE TABLE subscriptions (idSubsciption NUMBER(5) NOT NULL, createAt DATE, detail VARCHAR(50), account_id NUMBER(5), subs_account_id NUMBER(5));
CREATE TABLE stages (idStage NUMBER(10) NOT NULL, startAt DATE, endAt DATE, price NUMBER(9), status CHAR, exclusiveness_code VARCHAR2(9), subscription_id NUMBER(5) NOT NULL);
/*GC red astah*/
CREATE TABLE contentsYT (idContent NUMBER(10) NOT NULL, title VARCHAR(20) NOT NULL, publishingDate DATE NOT NULL, descriptionContent VARCHAR2(30), usuario_id NUMBER(5), exclusiveness_code VARCHAR2(9));
CREATE TABLE videos (contentsYT_id NUMBER(10) NOT NULL, durationVideo NUMBER(4) NOT NULL);
CREATE TABLE eventsYT (contentsYT_id NUMBER(10) NOT NULL, plannedDate DATE NOT NULL, actualDate DATE, durationEvent NUMBER(4));
CREATE TABLE posts (contentsYT_id NUMBER(10) NOT NULL, textPost VARCHAR(50) NOT NULL);

/*ATRIBUTOS*/
ALTER TABLE usuarios ADD CONSTRAINT CK_usuarios_email CHECK (email LIKE '%@%.%');
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_code CHECK (REGEXP_LIKE (code, 'EX-\d{1,6}'));
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_orderExcl CHECK (orderExcl >= 0);
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_price CHECK (price >= 0);
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_durationExcl CHECK (durationExcl >= 0 AND durationExcl <= 90);
ALTER TABLE labels ADD CONSTRAINT CK_labels_labelExclusivenes CHECK (REGEXP_LIKE (labelExclusivenes ,'#\w{1,10}'));
ALTER TABLE stages ADD CONSTRAINT CK_stages_price CHECK (price >= 0);
ALTER TABLE stages ADD CONSTRAINT CK_stages_status CHECK (status IN ('A','T','C'));
ALTER TABLE videos ADD CONSTRAINT CK_videos_durationVideo CHECK (durationVideo > 0 AND durationVideo <= 1380 );
ALTER TABLE eventsYT ADD CONSTRAINT CK_eventsYT_durationEvent CHECK (durationEvent > 0 AND durationEvent <= 1380 );
ALTER TABLE posts ADD CONSTRAINT CK_posts_textPost CHECK (textPost LIKE '% %' OR textPost LIKE '% % % % % % % % % %');
/*PRIMARIAS*/
ALTER TABLE usuarios ADD CONSTRAINT PK_usuarios PRIMARY KEY (idUsuario);
ALTER TABLE likes ADD CONSTRAINT PK_likes PRIMARY KEY (usuarios_id, contentsYT_id);
ALTER TABLE accounts ADD CONSTRAINT PK_accounts PRIMARY KEY (idAccount);
ALTER TABLE exclusiveness ADD CONSTRAINT PK_exclusiveness PRIMARY KEY (code);
ALTER TABLE labels ADD CONSTRAINT PK_labels PRIMARY KEY (exclusiveness_code);
ALTER TABLE subscriptions ADD CONSTRAINT PK_subscriptions PRIMARY KEY (idSubsciption);
ALTER TABLE stages ADD CONSTRAINT PK_stages PRIMARY KEY (idStage);
ALTER TABLE contentsYT ADD CONSTRAINT PK_contentsYT PRIMARY KEY (idContent);
ALTER TABLE videos ADD CONSTRAINT PK_videos PRIMARY KEY (contentsYT_id);
ALTER TABLE eventsYT ADD CONSTRAINT PK_eventsYT PRIMARY KEY (contentsYT_id);
ALTER TABLE posts ADD CONSTRAINT PK_posts PRIMARY KEY (contentsYT_id);
/*UNICAS*/
ALTER TABLE usuarios ADD CONSTRAINT UK_usuarios_email UNIQUE (email);
/*FORANEAS*/
ALTER TABLE likes ADD CONSTRAINT FK_likes_usuarios FOREIGN KEY (usuarios_id) REFERENCES usuarios(idUsuario);
ALTER TABLE likes ADD CONSTRAINT FK_likes_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE accounts ADD CONSTRAINT FK_accounts_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario);
ALTER TABLE exclusiveness ADD CONSTRAINT FK_exclusiveness_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount);
ALTER TABLE labels ADD CONSTRAINT FK_labels_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_subsaccounts FOREIGN KEY (subs_account_id) REFERENCES accounts(idAccount);
ALTER TABLE stages ADD CONSTRAINT FK_stages_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE stages ADD CONSTRAINT FK_stages_subscriptions FOREIGN KEY (subscription_id) REFERENCES subscriptions(idSubsciption);
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario);
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE videos ADD CONSTRAINT FK_videos_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE eventsYT ADD CONSTRAINT FK_eventsYT_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE posts ADD CONSTRAINT FK_posts_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);

/*DISPARADORES*/
/*Mantener Suscripcion*/
CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BI
BEFORE INSERT ON subscriptions
FOR EACH ROW
DECLARE
    actual_date DATE;
    subscriptionId NUMBER(5);
    stageId NUMBER(10);
BEGIN
    SELECT CURRENT_DATE INTO actual_date FROM DUAL;
    SELECT MAX(idSubsciption) INTO subscriptionId FROM subscriptions;
    IF (subscriptionId IS NULL) THEN
        subscriptionId := 0;  
    END IF;
    SELECT MAX(idStage) INTO stageId FROM stages;
    IF (stageId IS NULL) THEN
        stageId := 0;  
    END IF;
    :new.createAt := actual_date;
    :new.idSubsciption := subscriptionId+1;
    -- Se define nivel de exclusividad gratuito para la cuenta a la que se va a suscribir
    INSERT INTO exclusiveness(code, orderExcl, nameExcl, price, durationExcl, account_id) VALUES ('EX-0',0,'FREE',0,null,:new.subs_account_id);
    -- Se crea la etapa de la cuenta deacuerdo al nivel de esclusividad
    INSERT INTO stages(idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id)  VALUES(stageId,actual_date,null,0,'A','EX-0',subscriptionId);
END;

CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BU
BEFORE UPDATE ON subscriptions
FOR EACH ROW
BEGIN
    -- Solo se puede actualizar detail y stage
    IF (:new.idSubsciption != :old.idSubsciption OR :new.createAt != :old.createAt 
    OR :new.account_id != :old.account_id OR :new.subs_account_id != :old.subs_account_id) THEN
        RAISE_APPLICATION_ERROR(-20600,'No se puede actualizar la suscripcion.');
    END IF;
END;

CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BD
BEFORE DELETE ON subscriptions
FOR EACH ROW
DECLARE
    twoDaysLater DATE;
    actualDate DATE;
BEGIN
    SELECT CURRENT_DATE INTO actualDate FROM DUAL;
    twoDaysLater := :old.createAt+2;
    -- Si pasaron 2 dias a la fecha de creacion no se puede eliminar
    IF (actualDate+2 > twoDaysLater) THEN
        RAISE_APPLICATION_ERROR(-20600,'No se puede eliminar la suscripcion.');
    END IF;
END;
/*Mantener Usuario*/
CREATE OR REPLACE TRIGGER TG_USERS_BI
BEFORE INSERT ON usuarios
FOR EACH ROW
DECLARE
    idGenerado NUMBER(5);
    actualDate DATE;
BEGIN
    SELECT CURRENT_DATE INTO actualDate FROM DUAL;
    SELECT MAX(idUsuario) INTO idGenerado FROM usuarios;
    IF (idGenerado IS NULL) THEN
        idGenerado := 0;  
    END IF;
    :new.idUsuario := idGenerado+1;
    :new.createAt := actualDate;
END;

CREATE OR REPLACE TRIGGER TG_USERS_BU
BEFORE UPDATE ON usuarios
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20605,'No se puede modificar el usuario.');
END;

CREATE OR REPLACE TRIGGER TG_LIKES_BUD
BEFORE UPDATE OR DELETE ON likes
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20605,'No se puede modificar o eliminar el contenido a�adido como "me gusta".');
END;



/*XDisparadores*/
DROP TRIGGER TG_SUBSCRIPTIONS_BI;
DROP TRIGGER TG_SUBSCRIPTIONS_BU;
DROP TRIGGER TG_SUBSCRIPTIONS_BD;
DROP TRIGGER TG_USERS_BI;
DROP TRIGGER TG_USERS_BU;
DROP TRIGGER TG_LIKES_BUD;


/*XPoblar*/
DELETE FROM usuarios;
DELETE FROM accounts;
DELETE FROM subscriptions;
DELETE FROM exclusiveness;
DELETE FROM stages;
DELETE FROM labels;
DELETE FROM contentsYT;
DELETE FROM videos;
DELETE FROM eventsYT;
DELETE FROM posts;
DELETE FROM likes;

/*XTablas*/
DROP TABLE likes PURGE;
DROP TABLE posts PURGE;
DROP TABLE eventsYT PURGE;
DROP TABLE videos PURGE;
DROP TABLE contentsYT PURGE;
DROP TABLE labels PURGE;
DROP TABLE stages PURGE;
DROP TABLE exclusiveness PURGE;
DROP TABLE subscriptions PURGE;
DROP TABLE accounts PURGE;
DROP TABLE usuarios PURGE;



