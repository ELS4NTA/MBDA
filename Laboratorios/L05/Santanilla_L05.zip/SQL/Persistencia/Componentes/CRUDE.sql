CREATE OR REPLACE PACKAGE PC_SUBSCRIPTIONS IS
    PROCEDURE ad (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER, xSubsAccount_ID IN NUMBER);
    PROCEDURE mo_datail (xIdSubscription IN NUMBER, xDetail IN VARCHAR);
    PROCEDURE mo_stage(xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE);
    PROCEDURE eliminar(xIdSubscription IN NUMBER);
    FUNCTION consultar RETURN SYS_REFCURSOR;
    FUNCTION co_estadoSuscripcion(xIdSubscription IN NUMBER) RETURN SYS_REFCURSOR;
END;