/*CRUDI*/
CREATE OR REPLACE PACKAGE BODY PC_SUBSCRIPTIONS IS
    PROCEDURE ad (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER, xSubsAccount_ID IN NUMBER) 
    IS
    BEGIN
        INSERT INTO subscriptions (idSubscription, createAt, detail, account_id, subs_account_id) 
        VALUES (xIdSubscription,xCreatedAt,xDetail, xAccount_Id, xSubsAccount_ID);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede insertar la suscripcion.');
    END;
    --
    PROCEDURE mo_datail (xIdSubscription IN NUMBER, xDetail IN VARCHAR) 
    IS
    BEGIN
        UPDATE subscriptions SET detail = xDetail WHERE idSubscription = xIdSubscription;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20006, 'No se puede actualizar la suscripcion.');
    END;
    --
    PROCEDURE mo_stage(xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE) 
    IS
    BEGIN
        UPDATE stages SET status = xStatus, price = xPrice, endAt = xEndAt WHERE subscription_id = xIdSubscription;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede actualizar el estado de la suscripcion.');
    END;
    --
    PROCEDURE eliminar(xIdSubscription IN NUMBER)
    IS
    BEGIN
        DELETE FROM subscriptions WHERE idSubscription = xIdSubscription;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20008, 'No se puede elimar la suscripcion.');
    END;
    --
    FUNCTION consultar RETURN SYS_REFCURSOR IS consulta SYS_REFCURSOR;
    BEGIN
	OPEN consulta FOR
		SELECT * FROM subscriptions;
	RETURN consulta;
	END;
    --
    FUNCTION co_estadoSuscripcion(xIdSubscription IN NUMBER) RETURN SYS_REFCURSOR IS co_estado SYS_REFCURSOR;
    BEGIN
	OPEN co_estado FOR
		SELECT subscription_id, startAt, status FROM stages WHERE subscription_id =xIdSubscription;
	RETURN co_estado;
	END;
END;