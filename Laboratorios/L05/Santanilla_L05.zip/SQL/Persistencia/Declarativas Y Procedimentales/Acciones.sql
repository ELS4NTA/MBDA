/*ACCIONES*/
ALTER TABLE stages DROP CONSTRAINT FK_stages_subscriptions;
ALTER TABLE likes DROP CONSTRAINT FK_likes_usuarios;
ALTER TABLE accounts DROP CONSTRAINT FK_accounts_usuarios;
ALTER TABLE contentsYT DROP CONSTRAINT FK_contentsYT_usuarios;
ALTER TABLE exclusiveness DROP CONSTRAINT FK_exclusiveness_accounts;

ALTER TABLE stages ADD CONSTRAINT FK_stages_subscriptions FOREIGN KEY (subscription_id) REFERENCES subscriptions(idSubscription) ON DELETE CASCADE;
ALTER TABLE likes ADD CONSTRAINT FK_likes_usuarios FOREIGN KEY (usuarios_id) REFERENCES usuarios(idUsuario) ON DELETE CASCADE;
ALTER TABLE accounts ADD CONSTRAINT FK_accounts_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario) ON DELETE CASCADE;
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario) ON DELETE CASCADE;
ALTER TABLE exclusiveness ADD CONSTRAINT FK_exclusiveness_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount) ON DELETE CASCADE;