/*DISPARADORES*/
/*Mantener Suscripcion*/
CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BI
BEFORE INSERT ON subscriptions
FOR EACH ROW
DECLARE
    actual_date DATE;
    subscriptionId NUMBER(5);
BEGIN
    -- id  de la suscripcion y del stage autogenerado, fecha autogenerada
    SELECT CURRENT_DATE INTO actual_date FROM DUAL;
    SELECT MAX(idSubscription) INTO subscriptionId FROM subscriptions;
    IF (subscriptionId IS NULL) THEN
        subscriptionId := 0;
    END IF;
    :new.createAt := actual_date;
    :new.idSubscription := subscriptionId + 1;
END;

CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_AI
AFTER INSERT ON subscriptions
FOR EACH ROW
DECLARE
    actual_date DATE;
    excCode VARCHAR(10);
    stageId NUMBER(10);
BEGIN
    SELECT CURRENT_DATE INTO actual_date FROM DUAL;
    SELECT MAX(idStage) INTO stageId FROM stages;
    IF (stageId IS NULL) THEN
        stageId := 0;
    END IF;
    excCode := 'EX-'||LPAD(:new.subs_account_id,6,'0');
    stageId := stageId + 1;
    -- Se define nivel de exclusividad gratuito para la cuenta a la que se va a suscribir
    INSERT INTO exclusiveness(code, orderExcl, nameExcl, price, durationExcl, account_id) 
    VALUES (excCode,0,'Free',0,null,:new.subs_account_id);
    -- Se crea la etapa de la cuenta deacuerdo al nivel de esclusividad
    INSERT INTO stages(idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id)  
    VALUES(stageId,actual_date,null,0,'Active',excCode,:new.account_id);
END;
    
CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BU
BEFORE UPDATE ON subscriptions
FOR EACH ROW
BEGIN
    -- Solo se puede actualizar detail y stage
    IF (:new.idSubscription != :old.idSubscription OR :new.createAt != :old.createAt 
    OR :new.account_id != :old.account_id OR :new.subs_account_id != :old.subs_account_id) THEN
        RAISE_APPLICATION_ERROR(-20600,'No se puede actualizar la suscripcion.');
    END IF;
END;

CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BD
BEFORE DELETE ON subscriptions
FOR EACH ROW
DECLARE
    twoDaysLater DATE;
    actualDate DATE;
BEGIN
    SELECT CURRENT_DATE INTO actualDate FROM DUAL;
    -- Si pasaron 2 dias a la fecha de creacion no se puede eliminar
    IF (actualDate - :old.createAt > 2) THEN
        RAISE_APPLICATION_ERROR(-20600,'No se puede eliminar la suscripcion.');
    END IF;
END;

/*Mantener Usuario*/
CREATE OR REPLACE TRIGGER TG_USERS_BI
BEFORE INSERT ON usuarios
FOR EACH ROW
DECLARE
    idGenerado NUMBER(5);
    actualDate DATE;
    
BEGIN
    SELECT CURRENT_DATE INTO actualDate FROM DUAL;
    SELECT MAX(idUsuario) INTO idGenerado FROM usuarios;
    IF (idGenerado IS NULL) THEN
        idGenerado := 0;  
    END IF;
    :new.idUsuario := idGenerado+1;
    :new.createAt := actualDate;
END;

CREATE OR REPLACE TRIGGER TG_USERS_BU
BEFORE UPDATE ON usuarios
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20605,'No se puede modificar el usuario.');
END;

CREATE OR REPLACE TRIGGER TG_LIKES_BUD
BEFORE UPDATE OR DELETE ON likes
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20605,'No se puede modificar o eliminar el contenido a�adido como me gusta.');
END;