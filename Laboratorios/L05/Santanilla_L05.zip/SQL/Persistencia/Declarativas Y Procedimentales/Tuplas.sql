/*TUPLAS*/
ALTER TABLE usuarios ADD CONSTRAINT CK_usuarios_email CHECK (REGEXP_LIKE(email, '(.+)\@(.+)\.(.+)'));
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_code CHECK (REGEXP_LIKE (code, 'EX-\d{6}'));
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_orderExcl CHECK (orderExcl >= 0);
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_price CHECK (price >= 0);
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_durationExcl CHECK (durationExcl >= 0 AND durationExcl <= 90);
ALTER TABLE labels ADD CONSTRAINT CK_labels_labelExclusivenes CHECK (REGEXP_LIKE (labelExclusivenes ,'#\w{1,10}'));
ALTER TABLE stages ADD CONSTRAINT CK_stages_price CHECK (price >= 0);
ALTER TABLE stages ADD CONSTRAINT CK_stages_status CHECK (status IN ('Active','Finished','Cancelled'));
ALTER TABLE videos ADD CONSTRAINT CK_videos_durationVideo CHECK (durationVideo > 0 AND durationVideo <= 1380 );
ALTER TABLE eventsYT ADD CONSTRAINT CK_eventsYT_durationEvent CHECK (durationEvent > 0 AND durationEvent <= 1380 );
ALTER TABLE posts ADD CONSTRAINT CK_posts_textPost CHECK ((length(textPost) - length(replace(textPost,' ')))>=1 
AND (length(textPost) - length(replace(textPost,' ')))<=10);