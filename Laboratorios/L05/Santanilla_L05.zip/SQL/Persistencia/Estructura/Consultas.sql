/*CONSULTAS*/
/*Consultar cuentas que tienen mas suscripcinoes
las 10 cuentas con mas suscripciones*/
SELECT nameAccount, suscrcibers FROM accounts 
WHERE rownum<=10 ORDER BY suscrcibers DESC;

/*Consultar los usuarios con mas contenido en la platafroma
las 100 cuentas con mas contenido en la paltamorma*/
SELECT nameUsuario, COUNT(idContent) FROM usuarios 
JOIN contentsYT ON (idUsuario = usuario_id) 
WHERE rownum<=100 GROUP BY nameUsuario ORDER BY nameUsuario DESC;