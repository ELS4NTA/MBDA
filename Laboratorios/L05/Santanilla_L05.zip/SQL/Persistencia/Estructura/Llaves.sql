/*PRIMARIAS*/
ALTER TABLE usuarios ADD CONSTRAINT PK_usuarios PRIMARY KEY (idUsuario);
ALTER TABLE likes ADD CONSTRAINT PK_likes PRIMARY KEY (usuarios_id, contentsYT_id);
ALTER TABLE accounts ADD CONSTRAINT PK_accounts PRIMARY KEY (idAccount);
ALTER TABLE exclusiveness ADD CONSTRAINT PK_exclusiveness PRIMARY KEY (code);
ALTER TABLE labels ADD CONSTRAINT PK_labels PRIMARY KEY (exclusiveness_code);
ALTER TABLE subscriptions ADD CONSTRAINT PK_subscriptions PRIMARY KEY (idSubscription);
ALTER TABLE stages ADD CONSTRAINT PK_stages PRIMARY KEY (idStage);
ALTER TABLE contentsYT ADD CONSTRAINT PK_contentsYT PRIMARY KEY (idContent);
ALTER TABLE videos ADD CONSTRAINT PK_videos PRIMARY KEY (contentsYT_id);
ALTER TABLE eventsYT ADD CONSTRAINT PK_eventsYT PRIMARY KEY (contentsYT_id);
ALTER TABLE posts ADD CONSTRAINT PK_posts PRIMARY KEY (contentsYT_id);
/*UNICAS*/
ALTER TABLE usuarios ADD CONSTRAINT UK_usuarios_email UNIQUE (email);
/*FORANEAS*/
ALTER TABLE likes ADD CONSTRAINT FK_likes_usuarios FOREIGN KEY (usuarios_id) REFERENCES usuarios(idUsuario);
ALTER TABLE likes ADD CONSTRAINT FK_likes_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE accounts ADD CONSTRAINT FK_accounts_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario);
ALTER TABLE exclusiveness ADD CONSTRAINT FK_exclusiveness_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount);
ALTER TABLE labels ADD CONSTRAINT FK_labels_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_subsaccounts FOREIGN KEY (subs_account_id) REFERENCES accounts(idAccount);
ALTER TABLE stages ADD CONSTRAINT FK_stages_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE stages ADD CONSTRAINT FK_stages_subscriptions FOREIGN KEY (subscription_id) REFERENCES subscriptions(idSubscription);
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario);
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE videos ADD CONSTRAINT FK_videos_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE eventsYT ADD CONSTRAINT FK_eventsYT_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE posts ADD CONSTRAINT FK_posts_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);