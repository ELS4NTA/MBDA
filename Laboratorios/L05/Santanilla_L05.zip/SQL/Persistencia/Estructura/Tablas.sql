/*TABLAS*/
/*GC yellow astah*/
CREATE TABLE usuarios(
    idUsuario NUMBER(5) NOT NULL, 
    email VARCHAR2(100) NOT NULL, 
    nameUsuario VARCHAR2(50) NOT NULL, 
    createAt DATE
);
CREATE TABLE likes(
    usuarios_id NUMBER(5) NOT NULL, 
    contentsYT_id NUMBER(10) NOT NULL
);
/*GC green astah*/
CREATE TABLE accounts(
    idAccount NUMBER(5) NOT NULL, 
    nameAccount VARCHAR(70) NOT NULL, 
    createdAt DATE NOT NULL, 
    suscrcibers NUMBER(5) NOT NULL, 
    usuario_id NUMBER(5) NOT NULL
);
CREATE TABLE exclusiveness(
    code VARCHAR2(9) NOT NULL, 
    orderExcl NUMBER(3) NOT NULL, 
    nameExcl VARCHAR(55) NOT NULL, 
    price NUMBER(9), 
    durationExcl NUMBER(2), 
    account_id NUMBER(5) NOT NULL
);
CREATE TABLE labels(
    exclusiveness_code VARCHAR2(9) NOT NULL, 
    labelExclusivenes VARCHAR(10)
);
/*GC blue astah*/
CREATE TABLE subscriptions(
    idSubscription NUMBER(5) NOT NULL, 
    createAt DATE NOT NULL, 
    detail VARCHAR(50), 
    account_id NUMBER(5) NOT NULL, 
    subs_account_id NUMBER(5) NOT NULL
);
CREATE TABLE stages(
    idStage NUMBER(10) NOT NULL, 
    startAt DATE NOT NULL, 
    endAt DATE, 
    price NUMBER(9) NOT NULL, 
    status VARCHAR(20) NOT NULL, 
    exclusiveness_code VARCHAR(9) NOT NULL, 
    subscription_id NUMBER(5) NOT NULL
);
/*GC red astah*/
CREATE TABLE contentsYT(
    idContent NUMBER(10) NOT NULL, 
    title VARCHAR(20) NOT NULL, 
    publishingDate DATE NOT NULL, 
    descriptionContent VARCHAR(30), 
    usuario_id NUMBER(5) NOT NULL, 
    exclusiveness_code VARCHAR(9)
);
CREATE TABLE videos(
    contentsYT_id NUMBER(10) NOT NULL, 
    durationVideo NUMBER(4) NOT NULL
);
CREATE TABLE eventsYT(
    contentsYT_id NUMBER(10) NOT NULL, 
    plannedDate DATE NOT NULL, 
    actualDate DATE, 
    durationEvent NUMBER(4)
);
CREATE TABLE posts(
    contentsYT_id NUMBER(10) NOT NULL, 
    textPost VARCHAR(50) NOT NULL
);