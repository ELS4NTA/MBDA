/*ActoresE*/
CREATE OR REPLACE PACKAGE PA_USER IS
    PROCEDURE ad_subscription (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER);
    FUNCTION co_subscription RETURN SYS_REFCURSOR;
    PROCEDURE mo_subscription_detail (xIdSubscription IN NUMBER, xDetail IN VARCHAR);
    PROCEDURE mo_subscription_stage (xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE);
    PROCEDURE el_subscription (xIdSubscription IN NUMBER);
END;

CREATE OR REPLACE PACKAGE PA_EXPERIENCE_A IS
     FUNCTION co_accounts RETURN SYS_REFCURSOR;
END;