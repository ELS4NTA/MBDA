/*ActoresI*/
CREATE OR REPLACE PACKAGE BODY PA_USER IS
    PROCEDURE ad_subscription (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.ad(xIdSubscription, xCreatedAt, xDetail, xAccount_Id);
    END;
    --
    FUNCTION co_subscription RETURN SYS_REFCURSOR IS co_subscription SYS_REFCURSOR;
    BEGIN
        co_subscription := PC_SUBSCRIPTIONS.consultar;
        RETURN co_subscription;
	END;
    --
    PROCEDURE mo_subscription_detail (xIdSubscription IN NUMBER, xDetail IN VARCHAR)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.mo_datail(xIdSubscription, xDetail);
    END;
    --
    PROCEDURE mo_subscription_stage (xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.mo_stage(xIdSubscription, xStatus, xPrice, xEndAt);
    END;
    --
    PROCEDURE el_subscription (xIdSubscription IN NUMBER)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.eliminar(xIdSubscription);
    END;
END;
--??????????????
CREATE OR REPLACE PACKAGE BODY PA_EXPERIENCE_A IS
    FUNCTION co_accounts RETURN SYS_REFCURSOR IS co_accounts SYS_REFCURSOR;
    BEGIN
	OPEN co_accounts FOR
		SELECT idAccount, AVG(suscrcibers) AS promedio FROM accounts
        WHERE systate in (SELECT * FROM subscriptions WHERE createAt = sysdate-1) ORDER BY promedio DESC;
	RETURN co_accounts;
	END;
END;