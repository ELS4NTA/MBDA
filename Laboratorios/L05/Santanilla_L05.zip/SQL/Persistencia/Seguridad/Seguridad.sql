/*Seguridad*/
CREATE ROLE usuarioYT;
CREATE ROLE experienceA;

GRANT usuarioYT TO algunUsuarioDePrueba;
GRANT experienceA TO algunUsuarioDePrueba;

GRANT INSERT, SELECT, UPDATE, DELETE ON subscriptions TO usuarioYT;
GRANT INSERT, SELECT ON accounts TO usuarioYT;
GRANT INSERT, SELECT, UPDATE, DELETE ON contentsYT TO usuarioYT;
GRANT INSERT, SELECT, UPDATE, DELETE ON usuarios TO usuarioYT;
GRANT SELECT ON accounts TO experienceA;