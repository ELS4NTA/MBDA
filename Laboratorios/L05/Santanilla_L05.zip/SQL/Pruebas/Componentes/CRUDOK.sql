/*CRUDOK*/
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES
(1,'Daniel Santanilla', '28/04/2022',0,46311);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES
(2,'nhensmanss', '28/04/2022',0,15819);
/*PC_SUBSCRIPTIONS - ad*/
BEGIN 
    PC_SUBSCRIPTIONS.ad(2, '20/8/2022', 'Una prueba de suscripcion', 1, 2);
END;
/*PC_SUBSCRIPTIONS - mo_datail*/
BEGIN 
    PC_SUBSCRIPTIONS.mo_datail(1, 'Una prueba de detalle');
END;
/*PC_SUBSCRIPTIONS - mo_stage*/
BEGIN 
    PC_SUBSCRIPTIONS.mo_stage(1, 'Cancelled', 0, '28/04/2022');
END;
/*PC_SUBSCRIPTIONS - eliminar*/
BEGIN 
    PC_SUBSCRIPTIONS.eliminar(1);
END;