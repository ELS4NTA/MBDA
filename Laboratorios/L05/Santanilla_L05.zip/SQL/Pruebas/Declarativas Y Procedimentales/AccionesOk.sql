/*AccionesOk*/
insert into usuarios (idUsuario, email, nameUsuario, createAt) values (1, 'fheselwood0@liveinternet.ru', 'Francesca Heselwood', '29/8/2021');
insert into usuarios (idUsuario, email, nameUsuario, createAt) values (2, 'bzmitruk1@sitemeter.com', 'Bing Zmitruk', '26/7/2021');
insert into accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) values (1, 'Roodel', '22/7/2021', 1, 1);
insert into accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) values (2, 'Cogilith', '14/11/2021', 1, 2);
insert into exclusiveness (code, orderExcl, nameExcl, price, durationExcl, account_id) values ('EX-796029', 21, 'XD', 37, 30, 1);
insert into exclusiveness (code, orderExcl, nameExcl, price, durationExcl, account_id) values ('EX-893541', 22, 'HOlA',86, 20, 2);
insert into subscriptions (idSubscription, createAt, detail, account_id, subs_account_id) values (1, '14/5/2021', 'diam vitae quam', 1, 1);
insert into subscriptions (idSubscription, createAt, detail, account_id, subs_account_id) values (2, '7/9/2021', 'lectus pellentesque eget nunc', 2, 2);
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (1, '18/02/2022', null, 24, 'Cancelled', 'EX-796029', 1);
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (2, '22/02/2022', '01/03/2022', 49, 'Finished', 'EX-893541', 2);


DELETE FROM subscriptions WHERE idSubscription = 1;
DELETE FROM usuarios WHERE idUsuario = 1;
