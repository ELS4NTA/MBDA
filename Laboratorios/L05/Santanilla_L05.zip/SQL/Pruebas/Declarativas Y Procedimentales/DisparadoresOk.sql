/*DisparadoresOk*/
/*Insert Subscriptions*/
insert into usuarios (idUsuario, email, nameUsuario, createAt) values (1, 'rbonson0@usatoday.com', 'Rik Bonson', '14/10/2021');
insert into usuarios (idUsuario, email, nameUsuario, createAt) values (2, 'cde1@ustream.tv', 'Cathrin de Guerre', '19/5/2021');
insert into accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) values (1, 'Agimba', '16/05/2021', 2, 1);
insert into accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) values (2, 'Feedfire', '03/08/2021', 2, 2);
insert into subscriptions (idSubscription, createAt, detail, account_id, subs_account_id) values (4, '03/08/2021', 'nam nulla', 1, 2);
insert into subscriptions (idSubscription, createAt, detail, account_id, subs_account_id) values (2, '24/04/2021', 'cubilia curae nulla dapibus dolor', 2, 1);
/*Update Subscriptions*/
update subscriptions set detail = 'Hola como estas' where idSubscription = 1;
/*Delete Subscriptions*/
delete subscriptions where idSubscription = 1;
/*Insert Usuarios*/

/*Update Usuarios*/

/*Update or Delete likes*/