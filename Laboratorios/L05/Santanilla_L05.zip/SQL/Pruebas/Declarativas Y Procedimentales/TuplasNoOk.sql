/*TuplasNoOk*/
/*usuarios*/
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (1, 'mwiggans0@wiredcom', 'Mia Wiggans', to_date('24/07/2021', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (2, 'jselwyn1yelp.com', 'Jayme Selwyn', to_date('22/07/2021', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (3, 'cfynes2googlecouk', 'Cloe Fynes', to_date('11/05/2021', 'dd/mm/yyyy'));
/*exclusiveness*/
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('EX-79609', 21, 37, 30, 1);
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('EX893541', 22, 86, 20, 2);
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('X-738815', 12, 33, 10, 3);
/*labels*/
insert into labels (exclusiveness_code, labelExclusivenes) values ('EX-796029', 'afild');
/*stages*/
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (1, to_date('20/11/2020', 'dd/mm/yyyy'), to_date('21/08/2021', 'dd/mm/yyyy'), -1, 'T', 'EX-796029', 1);
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (2, to_date('23/12/2020', 'dd/mm/yyyy'), to_date('28/06/2021', 'dd/mm/yyyy'), 22, 'W', 'EX-893541', 2);
/*videos*/
insert into videos (contentsYT_id, durationVideo) values (1, 2000);
insert into videos (contentsYT_id, durationVideo) values (2, 3852);
/*eventsYT*/
insert into eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) values (1, to_date('7/5/2021', 'dd/mm/yyyy'), to_date('12/11/2021', 'dd/mm/yyyy'), 1571);
insert into eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) values (2, to_date('6/6/2021', 'dd/mm/yyyy'), to_date('12/2/2021', 'dd/mm/yyyy'), 6286);
/*posts*/
insert into posts (contentsYT_id, textPost) values (1, 'dui');
insert into posts (contentsYT_id, textPost) values (2, 'pos fel sed med asd por myr zxd hol uyt zxn uyq');


