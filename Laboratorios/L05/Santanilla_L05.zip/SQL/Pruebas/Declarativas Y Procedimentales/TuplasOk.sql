/*TuplasOk*/
/*usuarios*/
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (1, 'mwiggans0@wired.com', 'Mia Wiggans', to_date('24/07/2021', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (2, 'jselwyn1@yelp.com', 'Jayme Selwyn', to_date('22/07/2021', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (3, 'cfynes2@google.co.uk', 'Cloe Fynes', to_date('11/05/2021', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (4, 'jcancutt3@sina.com.cn', 'Jesselyn Cancutt', to_date('29/11/2021', 'dd/mm/yyyy'));
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (5, 'cvanyard4@behance.net', 'Cindelyn Vanyard', to_date('17/11/2021', 'dd/mm/yyyy'));
--
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (1, 'mwiggans0',  to_date('24/07/2021', 'dd/mm/yyyy'), 9890, 1);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (2, 'jselwyn1',  to_date('22/07/2021', 'dd/mm/yyyy'), 1000, 2);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (3, 'cfynes2',  to_date('11/05/2021', 'dd/mm/yyyy'), 2000, 3);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (4, 'jcancutt3',  to_date('29/11/2021', 'dd/mm/yyyy'), 3000, 4);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES (5, 'cvanyard4',  to_date('17/11/2021', 'dd/mm/yyyy'), 4000, 5);
/*exclusiveness*/
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('EX-796029', 21, 37, 30, 1);
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('EX-893541', 22, 86, 20, 2);
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('EX-738815', 12, 33, 10, 3);
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('EX-173519', 1, 8, 67, 4);
insert into exclusiveness (code, orderExcl, price, durationExcl, account_id) values ('EX-717891', 6, 53, 1, 5);
/*labels*/
insert into labels (exclusiveness_code, labelExclusivenes) values ('EX-796029', '#afield');
insert into labels (exclusiveness_code, labelExclusivenes) values ('EX-893541', '#erstwhile');
insert into labels (exclusiveness_code, labelExclusivenes) values ('EX-738815', '#husky''s');
insert into labels (exclusiveness_code, labelExclusivenes) values ('EX-173519', '#pokiest');
insert into labels (exclusiveness_code, labelExclusivenes) values ('EX-717891', '#provision');
--
insert into subscriptions (idSubscription, createAt, detail, account_id) values (1, to_date('25/06/2020', 'dd/mm/yyyy'), 'porttitor lacus at turpis donec', 1);
insert into subscriptions (idSubscription, createAt, detail, account_id) values (2, to_date('28/08/2020', 'dd/mm/yyyy'), 'viverra diam vitae quam nullam porttitor', 2);
insert into subscriptions (idSubscription, createAt, detail, account_id) values (3, to_date('01/12/2020', 'dd/mm/yyyy'), null, 3);
insert into subscriptions (idSubscription, createAt, detail, account_id) values (4, to_date('21/06/2020', 'dd/mm/yyyy'), 'sapien cursus vestibulum proin eu', 4);
insert into subscriptions (idSubscription, createAt, detail, account_id) values (5, to_date('24/07/2020', 'dd/mm/yyyy'), 'eleifend quam a odio in', 5);
/*stages*/
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (1, to_date('20/11/2020', 'dd/mm/yyyy'), to_date('21/08/2021', 'dd/mm/yyyy'), 98, 'Finished', 'EX-796029', 1);
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (2, to_date('23/12/2020', 'dd/mm/yyyy'), to_date('28/06/2021', 'dd/mm/yyyy'), 22, 'Cancelled', 'EX-893541', 2);
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (3, to_date('10/12/2020', 'dd/mm/yyyy'), to_date('02/02/2022', 'dd/mm/yyyy'), 40, 'Cancelled', 'EX-738815', 3);
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (4, to_date('27/01/2021', 'dd/mm/yyyy'), to_date('16/12/2021', 'dd/mm/yyyy'), 78, 'Active', 'EX-173519', 4);
insert into stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) values (5, to_date('04/03/2021', 'dd/mm/yyyy'), to_date('14/10/2021', 'dd/mm/yyyy'), 12, 'Cancelled', 'EX-717891', 5);
--
insert into contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) values (1, 'nulla sed', to_date('08/12/2021', 'dd/mm/yyyy'), 'donec ut mauris eget', 1, 'EX-796029');
insert into contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) values (2, 'a pede posuere', to_date('06/12/2021', 'dd/mm/yyyy'), 'nisi venenatis', 2, 'EX-893541');
insert into contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) values (3, 'lacus morbi', to_date('14/11/2021', 'dd/mm/yyyy'), 'pede justo lacinia', 3, 'EX-738815');
insert into contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) values (4, 'orci nullam', to_date('03/08/2021', 'dd/mm/yyyy'), 'posuere felis sed', 4, 'EX-173519');
insert into contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) values (5, 'et ultrices', to_date('03/02/2022', 'dd/mm/yyyy'), 'amet diam in magna', 5, 'EX-717891');
/*videos*/
insert into videos (contentsYT_id, durationVideo) values (1, 1000);
insert into videos (contentsYT_id, durationVideo) values (2, 852);
insert into videos (contentsYT_id, durationVideo) values (3, 424);
insert into videos (contentsYT_id, durationVideo) values (4, 572);
insert into videos (contentsYT_id, durationVideo) values (5, 1001);
/*eventsYT*/
insert into eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) values (1, to_date('7/5/2021', 'dd/mm/yyyy'), to_date('12/11/2021', 'dd/mm/yyyy'), 71);
insert into eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) values (2, to_date('6/6/2021', 'dd/mm/yyyy'), to_date('12/2/2021', 'dd/mm/yyyy'), 186);
insert into eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) values (3, to_date('6/1/2021', 'dd/mm/yyyy'), to_date('2/3/2022', 'dd/mm/yyyy'), 1071);
insert into eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) values (4, to_date('9/5/2021', 'dd/mm/yyyy'), to_date('2/7/2022', 'dd/mm/yyyy'), 593);
insert into eventsYT (contentsYT_id, plannedDate, actualDate, durationEvent) values (5, to_date('9/1/2021', 'dd/mm/yyyy'), to_date('6/11/2021', 'dd/mm/yyyy'), 462);
/*posts*/
insert into posts (contentsYT_id, textPost) values (1, 'dui lou');
insert into posts (contentsYT_id, textPost) values (2, 'posuere felis sed');
insert into posts (contentsYT_id, textPost) values (3, 'd d f g h j k y r t d');
insert into posts (contentsYT_id, textPost) values (4, 'duis consequat dui');
insert into posts (contentsYT_id, textPost) values (5, 'dui maecenas tristique est et');
