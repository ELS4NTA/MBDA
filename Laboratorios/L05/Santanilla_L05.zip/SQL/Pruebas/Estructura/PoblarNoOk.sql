/*PoblarNoOk*/
/*no deberian permitirse y no se permiten  porlas reglas de integridad definidas*/
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (NULL, 'jaime1234@hotmail.com', 'Jaime', 05/03/2017);
INSERT INTO accounts (idAccount, nameAccount, createdAt, suscrcibers, usuario_id) VALUES ('CanalJaime', 'JaimeTutos', 23/05/2017, 9890, 1);
INSERT INTO subscriptions (idSubscription, createAt, detail, account_id) VALUES (1, 01/03/2022, 'Bronce', 2);
INSERT INTO stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) VALUES (1, '22/03/01', 01/04/2022,0,'T','EX-000030',1);
INSERT INTO contentsYT (idContent, title, publishingDate, descriptionContent, usuario_id, exclusiveness_code) VALUES (1, NULL, 02/06/2017, NULL, 1, 'EX-000020');
/*no deberian permitirse y todavia se permiten*/
INSERT INTO exclusiveness (code, orderExcl, nameExcl, price, durationExcl, account_id) VALUES ('0192', 10, 'Bronce', 0,30,1);
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) VALUES (1, 'jaime1234.com', 'Jaime', 05/03/2017);
INSERT INTO videos (contentsYT_id, durationVideo) VALUES (2, 1500);
INSERT INTO eventsYT (contentsYT_id, durationVideo) VALUES (2, 2000);
INSERT INTO stages (idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id) VALUES (1, '22/03/01', 22/04/01,-300,'T','EX-000030',1);