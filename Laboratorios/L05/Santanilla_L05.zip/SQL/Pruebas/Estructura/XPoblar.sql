/*XPoblar*/
DELETE FROM stages;
DELETE FROM labels;
DELETE FROM posts;
DELETE FROM videos;
DELETE FROM likes;
DELETE FROM eventsYT;
DELETE FROM subscriptions;
DELETE FROM contentsYT;
DELETE FROM exclusiveness;
DELETE FROM accounts;
DELETE FROM usuarios;