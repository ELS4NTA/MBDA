/*SeguridadOk*/
UPDATE accounts SET nameAccount = 'Mi seguridad' WHERE idAccount = 1;