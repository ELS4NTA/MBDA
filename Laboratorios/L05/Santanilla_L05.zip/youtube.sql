/*TABLAS*/
/*GC yellow astah*/
CREATE TABLE usuarios(
    idUsuario NUMBER(5) NOT NULL, 
    email VARCHAR2(100) NOT NULL, 
    nameUsuario VARCHAR2(50) NOT NULL, 
    createAt DATE
);
CREATE TABLE likes(
    usuarios_id NUMBER(5) NOT NULL, 
    contentsYT_id NUMBER(10) NOT NULL
);
/*GC green astah*/
CREATE TABLE accounts(
    idAccount NUMBER(5) NOT NULL, 
    nameAccount VARCHAR(70) NOT NULL, 
    createdAt DATE NOT NULL, 
    suscrcibers NUMBER(5) NOT NULL, 
    usuario_id NUMBER(5) NOT NULL
);
CREATE TABLE exclusiveness(
    code VARCHAR2(9) NOT NULL, 
    orderExcl NUMBER(3) NOT NULL, 
    nameExcl VARCHAR(55) NOT NULL, 
    price NUMBER(9), 
    durationExcl NUMBER(2), 
    account_id NUMBER(5) NOT NULL
);
CREATE TABLE labels(
    exclusiveness_code VARCHAR2(9) NOT NULL, 
    labelExclusivenes VARCHAR(10)
);
/*GC blue astah*/
CREATE TABLE subscriptions(
    idSubscription NUMBER(5) NOT NULL, 
    createAt DATE NOT NULL, 
    detail VARCHAR(50), 
    account_id NUMBER(5) NOT NULL, 
    subs_account_id NUMBER(5) NOT NULL
);
CREATE TABLE stages(
    idStage NUMBER(10) NOT NULL, 
    startAt DATE NOT NULL, 
    endAt DATE, 
    price NUMBER(9) NOT NULL, 
    status VARCHAR(20) NOT NULL, 
    exclusiveness_code VARCHAR(9) NOT NULL, 
    subscription_id NUMBER(5) NOT NULL
);
/*GC red astah*/
CREATE TABLE contentsYT(
    idContent NUMBER(10) NOT NULL, 
    title VARCHAR(20) NOT NULL, 
    publishingDate DATE NOT NULL, 
    descriptionContent VARCHAR(30), 
    usuario_id NUMBER(5) NOT NULL, 
    exclusiveness_code VARCHAR(9)
);
CREATE TABLE videos(
    contentsYT_id NUMBER(10) NOT NULL, 
    durationVideo NUMBER(4) NOT NULL
);
CREATE TABLE eventsYT(
    contentsYT_id NUMBER(10) NOT NULL, 
    plannedDate DATE NOT NULL, 
    actualDate DATE, 
    durationEvent NUMBER(4)
);
CREATE TABLE posts(
    contentsYT_id NUMBER(10) NOT NULL, 
    textPost VARCHAR(50) NOT NULL
);
-------------
/*PRIMARIAS*/
ALTER TABLE usuarios ADD CONSTRAINT PK_usuarios PRIMARY KEY (idUsuario);
ALTER TABLE likes ADD CONSTRAINT PK_likes PRIMARY KEY (usuarios_id, contentsYT_id);
ALTER TABLE accounts ADD CONSTRAINT PK_accounts PRIMARY KEY (idAccount);
ALTER TABLE exclusiveness ADD CONSTRAINT PK_exclusiveness PRIMARY KEY (code);
ALTER TABLE labels ADD CONSTRAINT PK_labels PRIMARY KEY (exclusiveness_code);
ALTER TABLE subscriptions ADD CONSTRAINT PK_subscriptions PRIMARY KEY (idSubscription);
ALTER TABLE stages ADD CONSTRAINT PK_stages PRIMARY KEY (idStage);
ALTER TABLE contentsYT ADD CONSTRAINT PK_contentsYT PRIMARY KEY (idContent);
ALTER TABLE videos ADD CONSTRAINT PK_videos PRIMARY KEY (contentsYT_id);
ALTER TABLE eventsYT ADD CONSTRAINT PK_eventsYT PRIMARY KEY (contentsYT_id);
ALTER TABLE posts ADD CONSTRAINT PK_posts PRIMARY KEY (contentsYT_id);
/*UNICAS*/
ALTER TABLE usuarios ADD CONSTRAINT UK_usuarios_email UNIQUE (email);
/*FORANEAS*/
ALTER TABLE likes ADD CONSTRAINT FK_likes_usuarios FOREIGN KEY (usuarios_id) REFERENCES usuarios(idUsuario);
ALTER TABLE likes ADD CONSTRAINT FK_likes_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE accounts ADD CONSTRAINT FK_accounts_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario);
ALTER TABLE exclusiveness ADD CONSTRAINT FK_exclusiveness_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount);
ALTER TABLE labels ADD CONSTRAINT FK_labels_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount);
ALTER TABLE subscriptions ADD CONSTRAINT FK_subscriptions_subsaccounts FOREIGN KEY (subs_account_id) REFERENCES accounts(idAccount);
ALTER TABLE stages ADD CONSTRAINT FK_stages_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE stages ADD CONSTRAINT FK_stages_subscriptions FOREIGN KEY (subscription_id) REFERENCES subscriptions(idSubscription);
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario);
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_exclusiveness FOREIGN KEY (exclusiveness_code) REFERENCES exclusiveness(code);
ALTER TABLE videos ADD CONSTRAINT FK_videos_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE eventsYT ADD CONSTRAINT FK_eventsYT_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
ALTER TABLE posts ADD CONSTRAINT FK_posts_contentsYT FOREIGN KEY (contentsYT_id) REFERENCES contentsYT(idContent);
-------------
/*TUPLAS*/
ALTER TABLE usuarios ADD CONSTRAINT CK_usuarios_email CHECK (REGEXP_LIKE(email, '(.+)\@(.+)\.(.+)'));
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_code CHECK (REGEXP_LIKE (code, 'EX-\d{6}'));
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_orderExcl CHECK (orderExcl >= 0);
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_price CHECK (price >= 0);
ALTER TABLE exclusiveness ADD CONSTRAINT CK_exclusiveness_durationExcl CHECK (durationExcl >= 0 AND durationExcl <= 90);
ALTER TABLE labels ADD CONSTRAINT CK_labels_labelExclusivenes CHECK (REGEXP_LIKE (labelExclusivenes ,'#\w{1,10}'));
ALTER TABLE stages ADD CONSTRAINT CK_stages_price CHECK (price >= 0);
ALTER TABLE stages ADD CONSTRAINT CK_stages_status CHECK (status IN ('Active','Finished','Cancelled'));
ALTER TABLE videos ADD CONSTRAINT CK_videos_durationVideo CHECK (durationVideo > 0 AND durationVideo <= 1380 );
ALTER TABLE eventsYT ADD CONSTRAINT CK_eventsYT_durationEvent CHECK (durationEvent > 0 AND durationEvent <= 1380 );
ALTER TABLE posts ADD CONSTRAINT CK_posts_textPost CHECK ((length(textPost) - length(replace(textPost,' ')))>=1 
AND (length(textPost) - length(replace(textPost,' ')))<=10);
-------------
/*ACCIONES*/
ALTER TABLE stages DROP CONSTRAINT FK_stages_subscriptions;
ALTER TABLE likes DROP CONSTRAINT FK_likes_usuarios;
ALTER TABLE accounts DROP CONSTRAINT FK_accounts_usuarios;
ALTER TABLE contentsYT DROP CONSTRAINT FK_contentsYT_usuarios;
ALTER TABLE exclusiveness DROP CONSTRAINT FK_exclusiveness_accounts;

ALTER TABLE stages ADD CONSTRAINT FK_stages_subscriptions FOREIGN KEY (subscription_id) REFERENCES subscriptions(idSubscription) ON DELETE CASCADE;
ALTER TABLE likes ADD CONSTRAINT FK_likes_usuarios FOREIGN KEY (usuarios_id) REFERENCES usuarios(idUsuario) ON DELETE CASCADE;
ALTER TABLE accounts ADD CONSTRAINT FK_accounts_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario) ON DELETE CASCADE;
ALTER TABLE contentsYT ADD CONSTRAINT FK_contentsYT_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(idUsuario) ON DELETE CASCADE;
ALTER TABLE exclusiveness ADD CONSTRAINT FK_exclusiveness_accounts FOREIGN KEY (account_id) REFERENCES accounts(idAccount) ON DELETE CASCADE;
-------------
/*DISPARADORES*/
/*Mantener Suscripcion*/
CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BI
BEFORE INSERT ON subscriptions
FOR EACH ROW
DECLARE
    actual_date DATE;
    subscriptionId NUMBER(5);
BEGIN
    -- id  de la suscripcion y del stage autogenerado, fecha autogenerada
    SELECT CURRENT_DATE INTO actual_date FROM DUAL;
    SELECT MAX(idSubscription) INTO subscriptionId FROM subscriptions;
    IF (subscriptionId IS NULL) THEN
        subscriptionId := 0;
    END IF;
    :new.createAt := actual_date;
    :new.idSubscription := subscriptionId + 1;
END;

CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_AI
AFTER INSERT ON subscriptions
FOR EACH ROW
DECLARE
    actual_date DATE;
    excCode VARCHAR(10);
    stageId NUMBER(10);
BEGIN
    SELECT CURRENT_DATE INTO actual_date FROM DUAL;
    SELECT MAX(idStage) INTO stageId FROM stages;
    IF (stageId IS NULL) THEN
        stageId := 0;
    END IF;
    excCode := 'EX-'||LPAD(:new.subs_account_id,6,'0');
    stageId := stageId + 1;
    -- Se define nivel de exclusividad gratuito para la cuenta a la que se va a suscribir
    INSERT INTO exclusiveness(code, orderExcl, nameExcl, price, durationExcl, account_id) 
    VALUES (excCode,0,'Free',0,null,:new.subs_account_id);
    -- Se crea la etapa de la cuenta deacuerdo al nivel de esclusividad
    INSERT INTO stages(idStage, startAt, endAt, price, status, exclusiveness_code, subscription_id)  
    VALUES(stageId,actual_date,null,0,'Active',excCode,:new.account_id);
END;
    
CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BU
BEFORE UPDATE ON subscriptions
FOR EACH ROW
BEGIN
    -- Solo se puede actualizar detail y stage
    IF (:new.idSubscription != :old.idSubscription OR :new.createAt != :old.createAt 
    OR :new.account_id != :old.account_id OR :new.subs_account_id != :old.subs_account_id) THEN
        RAISE_APPLICATION_ERROR(-20001,'No se puede actualizar la suscripcion.');
    END IF;
END;

CREATE OR REPLACE TRIGGER TG_SUBSCRIPTIONS_BD
BEFORE DELETE ON subscriptions
FOR EACH ROW
DECLARE
    twoDaysLater DATE;
    actualDate DATE;
BEGIN
    SELECT CURRENT_DATE INTO actualDate FROM DUAL;
    -- Si pasaron 2 dias a la fecha de creacion no se puede eliminar
    IF (actualDate - :old.createAt > 2) THEN
        RAISE_APPLICATION_ERROR(-20002,'No se puede eliminar la suscripcion.');
    END IF;
END;

/*Mantener Usuario*/
CREATE OR REPLACE TRIGGER TG_USERS_BI
BEFORE INSERT ON usuarios
FOR EACH ROW
DECLARE
    idGenerado NUMBER(5);
    actualDate DATE;
    
BEGIN
    SELECT CURRENT_DATE INTO actualDate FROM DUAL;
    SELECT MAX(idUsuario) INTO idGenerado FROM usuarios;
    IF (idGenerado IS NULL) THEN
        idGenerado := 0;  
    END IF;
    :new.idUsuario := idGenerado+1;
    :new.createAt := actualDate;
END;

CREATE OR REPLACE TRIGGER TG_USERS_BU
BEFORE UPDATE ON usuarios
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20003,'No se puede modificar el usuario.');
END;

CREATE OR REPLACE TRIGGER TG_LIKES_BUD
BEFORE UPDATE OR DELETE ON likes
FOR EACH ROW
BEGIN
    RAISE_APPLICATION_ERROR(-20004,'No se puede modificar o eliminar el contenido a�adido como me gusta.');
END;
-------------
/*DATA*/
SELECT * FROM MBDAA01.DATA;
/*Incluyendome como Usuario en DATA*/
--INSERT INTO MBDAA01.DATA (ID,NAME,EMAIL,NDAY) VALUES (46311 ,'Daniel Santanilla', 'daniel.santanilla@mail.escuelaing.edu.co', 22);
/*Intentando modificarme o borrarme en DATA*/
UPDATE MBDAA01.DATA SET NAME = 'DANIEL SANTANILLA' WHERE ID = 46311;
DELETE FROM MBDAA01.DATA WHERE ID = 46311;
/*Otorgando permisos, esto lo deberia hacer el administrador de la base de datos*/
GRANT UPDATE, DELETE ON MBDAA01.DATA TO BD1000046311;
/*Importando los datos de DATA*/
INSERT INTO usuarios (idUsuario, email, nameUsuario, createAt) 
SELECT ID, EMAIL,NAME,TO_DATE(TO_CHAR(NDAY||'/04/2022'),'DD/MM/YYYY') 
FROM MBDAA01.DATA WHERE (ID IS NOT NULL AND ID NOT IN 
(SELECT ID FROM MBDAA01.DATA GROUP BY id HAVING COUNT(ID ) > 1) AND ID != 987) 
AND (EMAIL NOT IN (SELECT EMAIL FROM MBDAA01.DATA GROUP BY EMAIL HAVING COUNT(EMAIL) > 1))
AND (NDAY BETWEEN 1 AND 30) ORDER BY ID;
-------------
/*CRUDE*/
CREATE OR REPLACE PACKAGE PC_SUBSCRIPTIONS IS
    PROCEDURE ad (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER, xSubsAccount_ID IN NUMBER);
    PROCEDURE mo_datail (xIdSubscription IN NUMBER, xDetail IN VARCHAR);
    PROCEDURE mo_stage(xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE);
    PROCEDURE eliminar(xIdSubscription IN NUMBER);
    FUNCTION consultar RETURN SYS_REFCURSOR;
    FUNCTION co_estadoSuscripcion(xIdSubscription IN NUMBER) RETURN SYS_REFCURSOR;
END;
-------------
/*CRUDI*/
CREATE OR REPLACE PACKAGE BODY PC_SUBSCRIPTIONS IS
    PROCEDURE ad (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER, xSubsAccount_ID IN NUMBER) 
    IS
    BEGIN
        INSERT INTO subscriptions (idSubscription, createAt, detail, account_id, subs_account_id) 
        VALUES (xIdSubscription,xCreatedAt,xDetail, xAccount_Id, xSubsAccount_ID);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede insertar la suscripcion.');
    END;
    --
    PROCEDURE mo_datail (xIdSubscription IN NUMBER, xDetail IN VARCHAR) 
    IS
    BEGIN
        UPDATE subscriptions SET detail = xDetail WHERE idSubscription = xIdSubscription;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20006, 'No se puede actualizar la suscripcion.');
    END;
    --
    PROCEDURE mo_stage(xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE) 
    IS
    BEGIN
        UPDATE stages SET status = xStatus, price = xPrice, endAt = xEndAt WHERE subscription_id = xIdSubscription;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede actualizar el estado de la suscripcion.');
    END;
    --
    PROCEDURE eliminar(xIdSubscription IN NUMBER)
    IS
    BEGIN
        DELETE FROM subscriptions WHERE idSubscription = xIdSubscription;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20008, 'No se puede elimar la suscripcion.');
    END;
    --
    FUNCTION consultar RETURN SYS_REFCURSOR IS consulta SYS_REFCURSOR;
    BEGIN
	OPEN consulta FOR
		SELECT * FROM subscriptions;
	RETURN consulta;
	END;
    --
    FUNCTION co_estadoSuscripcion(xIdSubscription IN NUMBER) RETURN SYS_REFCURSOR IS co_estado SYS_REFCURSOR;
    BEGIN
	OPEN co_estado FOR
		SELECT subscription_id, startAt, status FROM stages WHERE subscription_id =xIdSubscription;
	RETURN co_estado;
	END;
END;
-------------
/*ActoresE*/
CREATE OR REPLACE PACKAGE PA_USER IS
    PROCEDURE ad_subscription (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER);
    FUNCTION co_subscription RETURN SYS_REFCURSOR;
    PROCEDURE mo_subscription_detail (xIdSubscription IN NUMBER, xDetail IN VARCHAR);
    PROCEDURE mo_subscription_stage (xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE);
    PROCEDURE el_subscription (xIdSubscription IN NUMBER);
END;

CREATE OR REPLACE PACKAGE PA_EXPERIENCE_A IS
     FUNCTION co_accounts RETURN SYS_REFCURSOR;
END;
-------------
/*ActoresI*/
CREATE OR REPLACE PACKAGE BODY PA_USER IS
    PROCEDURE ad_subscription (xIdSubscription IN NUMBER, xCreatedAt IN DATE, xDetail IN VARCHAR, xAccount_Id IN NUMBER)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.ad(xIdSubscription, xCreatedAt, xDetail, xAccount_Id);
    END;
    --
    FUNCTION co_subscription RETURN SYS_REFCURSOR IS co_subscription SYS_REFCURSOR;
    BEGIN
        co_subscription := PC_SUBSCRIPTIONS.consultar;
        RETURN co_subscription;
	END;
    --
    PROCEDURE mo_subscription_detail (xIdSubscription IN NUMBER, xDetail IN VARCHAR)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.mo_datail(xIdSubscription, xDetail);
    END;
    --
    PROCEDURE mo_subscription_stage (xIdSubscription IN NUMBER, xStatus IN VARCHAR, xPrice IN NUMBER, xEndAt IN DATE)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.mo_stage(xIdSubscription, xStatus, xPrice, xEndAt);
    END;
    --
    PROCEDURE el_subscription (xIdSubscription IN NUMBER)
    IS
    BEGIN
        PC_SUBSCRIPTIONS.eliminar(xIdSubscription);
    END;
END;
--??????????????
CREATE OR REPLACE PACKAGE BODY PA_EXPERIENCE_A IS
    FUNCTION co_accounts RETURN SYS_REFCURSOR IS co_accounts SYS_REFCURSOR;
    BEGIN
	OPEN co_accounts FOR
		SELECT idAccount, AVG(suscrcibers) FROM accounts
        HAVING suscrcibers >  AVG(suscrcibers) ORDER BY AVG(suscrcibers) DESC;
	RETURN co_accounts;
	END;
END;
-------------
/*Seguridad*/
CREATE ROLE usuarioYT;
CREATE ROLE experienceA;

GRANT usuarioYT TO bd1000046311;
GRANT experienceA TO bd1000046311;

GRANT INSERT, SELECT, UPDATE, DELETE ON subscriptions TO usuarioYT;
GRANT INSERT, SELECT ON accounts TO usuarioYT;
GRANT INSERT, SELECT, UPDATE, DELETE ON contentsYT TO usuarioYT;
GRANT INSERT, SELECT, UPDATE, DELETE ON usuarios TO usuarioYT;
GRANT SELECT ON accounts TO experienceA;
-------------
/*XSeguridad*/
DROP PACKAGE PA_USER;
DROP PACKAGE PA_EXPERIENCE_A;

REVOKE INSERT, SELECT, UPDATE, DELETE ON subscriptions FROM usuarioYT;
REVOKE INSERT, SELECT ON accounts FROM usuarioYT;
REVOKE INSERT, SELECT, UPDATE, DELETE ON contentsYT FROM usuarioYT;
REVOKE INSERT, SELECT, UPDATE, DELETE ON usuarios FROM usuarioYT;
REVOKE SELECT ON accounts FROM experienceA;

DROP ROLE usuarioYT;
DROP ROLE experienceA;
-------------
/*XCRUD*/
DROP PACKAGE PC_SUBSCRIPTIONS;
-------------
/*XDisparadores*/
DROP TRIGGER TG_SUBSCRIPTIONS_BI;
DROP TRIGGER TG_SUBSCRIPTIONS_AI;
DROP TRIGGER TG_SUBSCRIPTIONS_BU;
DROP TRIGGER TG_SUBSCRIPTIONS_BD;
DROP TRIGGER TG_USERS_BI;
DROP TRIGGER TG_USERS_BU;
DROP TRIGGER TG_LIKES_BUD;
-------------
/*XPoblar*/
DELETE FROM usuarios;
DELETE FROM accounts;
DELETE FROM subscriptions;
DELETE FROM exclusiveness;
DELETE FROM stages;
DELETE FROM labels;
DELETE FROM contentsYT;
DELETE FROM videos;
DELETE FROM eventsYT;
DELETE FROM posts;
DELETE FROM likes;
-------------
/*XTablas*/
DROP TABLE likes PURGE;
DROP TABLE posts PURGE;
DROP TABLE eventsYT PURGE;
DROP TABLE videos PURGE;
DROP TABLE contentsYT PURGE;
DROP TABLE labels PURGE;
DROP TABLE stages PURGE;
DROP TABLE exclusiveness PURGE;
DROP TABLE subscriptions PURGE;
DROP TABLE accounts PURGE;
DROP TABLE usuarios PURGE;