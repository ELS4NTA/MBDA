/*CONSULTAS*/
/*Consultar cuentas que tienen mas suscripcinoes
las 10 cuentas con mas suscripciones*/
SELECT nameAccount, suscrcibers FROM accounts 
WHERE rownum<=10 ORDER BY suscrcibers DESC;

/*Consultar los usuarios con mas contenido en la platafroma
las 100 cuentas con mas contenido en la paltamorma*/
SELECT nameUsuario, COUNT(idContent) FROM usuarios 
JOIN contentsYT ON (idUsuario = usuario_id) 
WHERE rownum<=100 GROUP BY nameUsuario ORDER BY nameUsuario DESC;

/*Subscriptions requiring violent content*/
SELECT account_id, EXTRACTVALUE(detail, 'Details/Description/text()="Requiring violent content"') FROM subscriptions;

/*Consultar etiquetas del detalle de la suscripcion*/
SELECT EXTRACT(detail, '/Details/Tags/@name') AS Tags,
EXTRACT(detail, 'Details/Tags/@description') AS Descripcion FROM subscriptions;

/*Consultar informacion del detalle de la suscripcion*/
SELECT EXTRACTVALUE(detail, 'Details/Information/@age') AS Age, 
EXTRACTVALUE(detail, 'Details/Information/@country') AS Country 
FROM subscriptions;