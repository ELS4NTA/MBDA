/*Implemente la estructura de las tablas dise�adas en el punto 1*/
CREATE TABLE profesores(
    numDocumento VARCHAR(50) NOT NULL,
    nobre VARCHAR(50) NOT NULL,
    nivelEducativo VARCHAR(50) NOT NULL,
    correo VARCHAR(50) NOT NULL,
    institucion VARCHAR(50) NOT NULL
);

CREATE TABLE asignaturaXProfesor(
    asignaturas_idAsignatura NUMBER NOT NULL,
    profesres_numDoc VARCHAR(50) NOT NULL
);

CREATE TABLE asignaturas(
    idAsignatura NUMBER NOT NULL,
    codigo VARCHAR(50) NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    colegios_nit VARCHAR(50) NOT NULL,
    anno VARCHAR(4)
);

CREATE TABLE logros(
    idLogro NUMBER NOT NULL,
    proposito VARCHAR(50) NOT NULL,
    descripcion VARCHAR(50) NOT NULL,
    porcentaje  NUMBER(3) NOT NULL,
    asignaturas_idA NUMBER NOT NULL
);

CREATE TABLE colegios(
    nit VARCHAR(50) NOT NULL,
    razonsocial VARCHAR(50) NOT NULL,
    direccion VARCHAR(50) NOT NULL,
    correo VARCHAR(50) NOT NULL
);

CREATE TABLE telefonosColegios(
    idTelColegio NUMBER NOT NULL,
    colegios_nit VARCHAR(50) NOT NULL,
    numero VARCHAR(50) NOT NULL
);

CREATE TABLE actividades(
    idActividad NUMBER NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    descripcion VARCHAR(500) NOT NULL,
    porcentaje NUMBER NOT NULL,
    logros_idL NUMBER NOT NULL
);

CREATE TABLE parciales(
    actividades_idA NUMBER NOT NULL,
    vinculo VARCHAR(50) NOT NULL,
    documento VARCHAR(50) NOT NULL
);

CREATE TABLE refuerzos(
    actividaders_idA NUMBER NOT NULL,
    urlRefuerzo VARCHAR(50) NOT NULL
);

CREATE TABLE recomendaciones(
    idRecomendacion NUMBER NOT NULL,
    refuerzos_idRe NUMBER,
    recomendacion VARCHAR(50) NOT NULL
);

CREATE TABLE entregas(
    idEntrega NUMBER NOT NULL,
    actividades_idA NUMBER NOT NULL,
    fechaEntrega DATE,
    documento VARCHAR(50) NOT NULL,
    calificaiones_idC NUMBER NOT NULL
);

CREATE TABLE calificaciones(
    idClificacion NUMBER NOT NULL,
    calificacion VARCHAR(50) NOT NULL
);

CREATE TABLE observaciones(
    idObservacion NUMBER NOT NULL,
    calificaciones_idC NUMBER,
    observacion VARCHAR(50) NOT NULL
);

CREATE TABLE estudiantes(
    numDocumento VARCHAR(50) NOT NULL,
    tipoDocumento VARCHAR(50) NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    estado VARCHAR(50) NOT NULL,
    nPadre VARCHAR(50) NOT NULL,
    nMadre VARCHAR(50) NOT NULL,
    direccion VARCHAR(50) NOT NULL
);

CREATE TABLE telefonosEstudiantes(
    idTelEstudiante NUMBER NOT NULL,
    estudiantes_numDoc VARCHAR(50) NOT NULL,
    estudiantes_tipoDoc VARCHAR(50) NOT NULL,
    numero VARCHAR(50) NOT NULL
);


ALTER TABLE profesores ADD CONSTRAINT PK_numDocumento PRIMARY KEY (numDocumento);
ALTER TABLE asignaturaXProfesor ADD CONSTRAINT PK_idAsignatura_numDoc PRIMARY KEY (asignaturas_idAsignatura, profesres_numDoc);
ALTER TABLE asignaturas ADD CONSTRAINT PK_idAsignatura PRIMARY KEY (idAsignatura);
ALTER TABLE logros ADD CONSTRAINT PK_idLogro PRIMARY KEY (idLogro); 
ALTER TABLE colegios ADD CONSTRAINT PK_nit PRIMARY KEY (nit);
ALTER TABLE telefonosColegios ADD CONSTRAINT PK_idTelColegio PRIMARY KEY (idTelColegio);
ALTER TABLE actividades ADD CONSTRAINT PK_idActividad PRIMARY KEY (idActividad);
ALTER TABLE parciales ADD CONSTRAINT PK_parci_actividades_idA PRIMARY KEY (actividades_idA);
ALTER TABLE refuerzos ADD CONSTRAINT PK_refu_actividaders_idA PRIMARY KEY (actividaders_idA);
ALTER TABLE recomendaciones ADD CONSTRAINT PK_idRecomendacion PRIMARY KEY (idRecomendacion);
ALTER TABLE entregas ADD CONSTRAINT PK_idEntrega PRIMARY KEY (idEntrega);
ALTER TABLE calificaciones ADD CONSTRAINT PK_entregas_idE PRIMARY KEY (entregas_idE);
ALTER TABLE observaciones ADD CONSTRAINT PK_idObservacion PRIMARY KEY (idObservacion);
ALTER TABLE estudiantes ADD CONSTRAINT PK_numDoc_tipoDoc PRIMARY KEY (numDocumento, tipoDocumento);
ALTER TABLE telefonosEstudiantes ADD CONSTRAINT PK_idTelEstudiante PRIMARY KEY (idTelEstudiante);

/*Implemente todas las restricciones de integridad declarativa correspondientes al CRUD Mantener Actividades*/
ALTER TABLE asignaturas ADD CONSTRAINT CK_asignatura_codigo CHECK (SUBSTR(nombre,1,1) || anno || REGEXP_LIKE('\d{8}') );
ALTER TABLE entregas ADD CONSTRAINT CK_entregas_documento CHECK (documento IN ('%.pdf','%.doc','%.png'));
ALTER TABLE calificaciones ADD CONSTRAINT CK_calificaciones_calificacion CHECK (calificacion >= 0 AND calificacion <= 5);

/*Implemente los mecanismos dise�ados para cumplir las reglas de negocio del caso de uso*/
/*ASIGNAR*/
CREATE OR REPLACE TRIGGER TG_ASIGNATURAS_BI
BEFORE INSERT ON asignaturas
FOR EACH ROW
DECLARE
    letraAsignatura VARCHAR(1);
    aleatorio VARCHAR(4);
BEGIN
    SELECT substr(nombre,1,1) INTO letraAsignatura FROM asignaturas;
    SELECT DBMS_RANDOM.VALUE(1,8) INTO aleatorio FROM DUAL;
    :new.codigo := letraAsignatura || :new.anno || aleatorio;
    IF LENGTH(:new.descipcion) > 500 THEN
        raise_application_error(-20001,'Esta descripcion sobrepasa 500 caracteres');
    END IF;
END;
/*Modificar*/
CREATE OR REPLACE TRIGGER TG_LOGROS_BU
BEFORE UPDATE ON logros
FOR EACH ROW
DECLARE
    asociada  NUMBER;
BEGIN
    IF (EXISTS(SELECT logros_idL INTO asociada FROM actividades WHERE logros_idL = :old.idLogro;) THEN
        raise_application_error(-20001,'No se puede actualizar el logro porque tiene actividades asociadas');
    END IF;
END;
/*Eliminar*/
ALTER TABLE entregas ADD CONSTRAINT FK_ENGREGAS_CALIFICACIONES FOREIGN KEY (calificaiones_idC) REFERENCES calificaiones(idClificacion) ON DELETE RESTRICT;
    
    

























