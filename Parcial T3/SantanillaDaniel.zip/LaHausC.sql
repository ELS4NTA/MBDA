/*CREANDO*/
/*Tablas*/
CREATE TABLE ofertas (
    codigoVivienda VARCHAR(6) NOT NULL,
    costo NUMBER NOT NULL,
    descripcion VARCHAR(500) NOT NULL,
    condicion CHAR(1) NOT NULL,
    tipoVivienda VARCHAR(50) NOT NULL,
    tamanno NUMBER NOT NULL,
    proyectoVivienda CHAR(1) NOT NULL,
    estado VARCHAR(50) NOT NULL,
    anexo XMLTYPE,
    cliente_documento VARCHAR(50)
);
CREATE TABLE ubicaciones (
    latitud VARCHAR(50) NOT NULL,
    longitud VARCHAR(50) NOT NULL,
    ciudad VARCHAR(50) NOT NULL,
    zona VARCHAR(50) NOT NULL,
    direccion VARCHAR(50) NOT NULL,
    barrio VARCHAR(50) NOT NULL,
    ofertas_codigo VARCHAR(6) NOT NULL
);
CREATE TABLE condicionesDePago (
    idCondicionPago NUMBER NOT NULL,
    credito CHAR(1) NOT NULL,
    plazo NUMBER,
    valor NUMBER NOT NULL,
    fechaDesembolso DATE NOT NULL,
    ofertas_codigo VARCHAR(6) NOT NULL
);
CREATE TABLE entidadesBancarias (
    idEntidad NUMBER NOT NULL,
    entidad VARCHAR(50) NOT NULL,
    condicionpago_id NUMBER NOT NULL
);
/*Primarias*/
ALTER TABLE ofertas ADD CONSTRAINT PK_codigoVivienda PRIMARY KEY (codigoVivienda);
ALTER TABLE ubicaciones ADD CONSTRAINT PK_latitud_longitud PRIMARY KEY (latitud, longitud);
ALTER TABLE condicionesDePago ADD CONSTRAINT PK_idCondicionPago PRIMARY KEY (idCondicionPago);
ALTER TABLE entidadesBancarias ADD CONSTRAINT PK_idEntidad PRIMARY KEY (idEntidad);
/*Unicas*/
/*Foraneas*/
ALTER TABLE ubicaciones ADD CONSTRAINT FK_ubicaciones_ofertas FOREIGN KEY (ofertas_codigo) REFERENCES ofertas(codigoVivienda);
ALTER TABLE condicionesDePago ADD CONSTRAINT FK_condPago_ofertas FOREIGN KEY (ofertas_codigo) REFERENCES ofertas(codigoVivienda);
ALTER TABLE entidadesBancarias ADD CONSTRAINT FK_entidades_condPago FOREIGN KEY (condicionpago_id) REFERENCES condicionesDePago(idCondicionPago);



/*POBLANDO Y CONSULTANDO*/
/*PoblarOk*/
--LaHausP.sql
/*Indices*/
/*Vistas*/
-- Usuarios con mayor cantidad de demandas en sus ofertas, organizados descendentemente.
CREATE VIEW VCantDemandasXUsuario AS SELECT numeroDocumento, numDemandas, AVG(numDemandas) FROM personasNaturales ORDER BY numDemandas DESC;



/*DEFINIENDO DATOS EN XML*/
/*DTD*/
--'<?xml version="1.0" encoding="UTF-8"?>
--<!DOCTYPE Annexes [
--    <!ELEMENT HouseNumber (#PCDATA)>
--    <!ELEMENT Documents (Document+)>
--    <!ELEMENT Document EMPTY>
--    <!ATTLIST Document Name CDATA #REQUIRED>
--    <!ATTLIST Document NumIdentification CDATA #REQUIRED>
--    <!ATTLIST Document URL CDATA #REQUIRED>
--]>'
/*PoblarXML*/
--LaHausP.sql
/*Consulta Operativa*/
--- Ofertas que tienen certificados de libertad en formato PDF
-- Tablas personasNaturales y clientes no definidas
SELECT EXTRACTVALUE(anexo, 'Annexes/HouseNumber/text()') AS codigoVivienda,
EXTRACTVALUE(anexo, 'Annexes/Documents/Document/@NumIdentification') AS idDocumento,
EXTRACTVALUE(anexo, 'Annexes/Documents/Document/@URL') AS extensionDocumento,
nombres, correoElectronio FROM clientes JOIN personasNaturales ON (cliente_documento = numeroDocumento)
JOIN ofertas ON (cliente_documento = numeroDocumento);



/*REGLAS DE NEGOCIO*/
/*Tuplas*/
ALTER TABLE ofertas ADD CONSTRAINT CK_ofertas_codigoVivienda CHECK (REGEXP_LIKE(codigoVivienda, '[A-Z]{2}\d{3}[1-9]'));
ALTER TABLE ofertas ADD CONSTRAINT CK_ofertas_costo  CHECK (costo > 0);
ALTER TABLE ofertas ADD CONSTRAINT CK_ofertas_tipoVivienda  CHECK (tipoVivienda IN ('Casa', 'Apartamento', 'Bodega', 'Finca'));
ALTER TABLE ofertas ADD CONSTRAINT CK_ofertas_estado  CHECK (estado  IN ('Disponible', 'Vendida'));
ALTER TABLE ubicaciones ADD CONSTRAINT CK_ubicaciones_zona CHECK (zona IN ('Norte', 'Sur', 'Occidente', 'Oriente'));
ALTER TABLE condicionesDePago ADD CONSTRAINT CK_condPago_valor CHECK (valor > 0);
/*Acciones*/
ALTER TABLE ubicaciones DROP CONSTRAINT FK_ubicaciones_ofertas;
ALTER TABLE condicionesDePago DROP CONSTRAINT FK_condPago_ofertas;

ALTER TABLE ubicaciones ADD CONSTRAINT FK_ubicaciones_ofertas FOREIGN KEY (ofertas_codigo) REFERENCES ofertas(codigoVivienda) ON DELETE CASCADE;
ALTER TABLE condicionesDePago ADD CONSTRAINT FK_condPago_ofertas FOREIGN KEY (ofertas_codigo) REFERENCES ofertas(codigoVivienda) ON DELETE CASCADE;
/*Disparadores*/
CREATE SEQUENCE codVivienda_seq START WITH 1; -- Se va a automatizar el cod de la Vivienda

CREATE OR REPLACE TRIGGER TG_OFERTAS_BI
BEFORE INSERT ON ofertas
FOR EACH ROW
BEGIN
    SELECT 'AA'||LPAD(codVivienda_seq.NEXTVAL,4,1) INTO :new.codigoVivienda FROM dual;
    INSERT INTO ubicaciones (latitud, longitud, ciudad, zona, direccion, barrio, ofertas_codigo)
    VALUES ('','','','','','',:new.codigoVivienda);    
END;
--
CREATE OR REPLACE TRIGGER TG_OFERTAS_BU
BEFORE UPDATE ON ofertas
FOR EACH ROW
BEGIN
    -- Solo se puede actualizar la descripcion y los anexos
    IF (:new.codigoVivienda != :old.codigoVivienda 
    AND :new.costo != :old.costo 
    AND :new.condicion != :old.condicion
    AND :new.tipoVivienda != :old.tipoVivienda
    AND :new.tamanno != :old.tamanno
    AND :new.proyectoVivienda != :old.proyectoVivienda
    AND :new.estado != :old.estado
    AND :new.cliente_documento != :old.cliente_documento)
    THEN
        RAISE_APPLICATION_ERROR(-20015, 'No se actualizr la oferta.');
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_OFERTAS_BD
BEFORE DELETE ON ofertas
FOR EACH ROW
DECLARE
    cantDemandas NUMBER;
BEGIN
    SELECT count(*) INTO cantDemandas FROM demandas WHERE cliente_doc = :new.cliente_documento;
    -- Si no tiene demandas se elimana la oferta
    IF (cantDemandas = 0) THEN
        DELETE FROM ofertas WHERE cliente_documento = :new.cliente_documento;
    END IF;
END;



/*PAQUETES*/
/*CRUDE*/
CREATE OR REPLACE PACKAGE PC_OFERTAS IS 
    PROCEDURE adicionar (xCodigoVivienda IN VARCHAR, xCosto IN NUMBER, xDescripcion IN VARCHAR, 
    xCondicion IN CHAR, xTipoVivienda IN VARCHAR, xTamanno IN NUMBER, xProyectoVivienda IN CHAR, xEstado IN VARCHAR, xAnexo IN XMLTYPE);
    FUNCTION consultar(xCodigoVivienda IN VARCHAR) RETURN SYS_REFCURSOR;
    FUNCTION co_cantidadDemandadas RETURN SYS_REFCURSOR;
END;
/*CRUDI*/
CREATE OR REPLACE PACKAGE BODY PC_OFERTAS IS
    PROCEDURE adicionar(xCodigoVivienda IN VARCHAR, xCosto IN NUMBER, xDescripcion IN VARCHAR, 
    xCondicion IN CHAR, xTipoVivienda IN VARCHAR, xTamanno IN NUMBER, xProyectoVivienda IN CHAR, xEstado IN VARCHAR, xAnexo IN XMLTYPE) IS
    BEGIN
        INSERT INTO ofertas (codigoVivienda, costo, descripcion, condicion, tipoVivienda, tamanno, proyectoVivienda, estado, anexo)
        VALUES (xCodigoVivienda, xCosto, xDescripcion, xCondicion, xTipoVivienda, xTamanno, xProyectoVivienda, xEstado, xAnexo);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede agregar la oferta.');
    END;
    --
    FUNCTION consultar(xCodigoVivienda IN VARCHAR) RETURN SYS_REFCURSOR IS consultar SYS_REFCURSOR;
    BEGIN
    OPEN consultar FOR
        SELECT * FROM ofertas WHERE codigoVivienda = xCodigoVivienda;
        RETURN consultar;
    END;
    --
    FUNCTION co_cantidadDemandadas RETURN SYS_REFCURSOR IS co_cantidadDemandadas SYS_REFCURSOR;
    BEGIN
    OPEN co_cantidadDemandadas FOR
        SELECT * FROM VCantDemandasXUsuario;
        RETURN co_cantidadDemandadas;
    END;
END;
/*CRUDOK*/
/*CRUDNoOK*/
/*Seguridad*/
CREATE ROLE usuarioLaHaus;
GRANT INSERT, UPDATE, DELETE ON ofertas TO usuarioLaHaus;




/*XTablas*/
DROP TABLE ofertas CASCADE CONSTRAINTS PURGE;
DROP TABLE ubicaciones CASCADE CONSTRAINTS PURGE;
DROP TABLE condicionesDePago CASCADE CONSTRAINTS PURGE;
DROP TABLE entidadesBancarias CASCADE CONSTRAINTS PURGE;