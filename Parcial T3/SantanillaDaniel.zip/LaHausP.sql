/*PoblarOk*/
INSERT INTO ofertas (codigoVivienda, costo, descripcion, condicion, tipoVivienda, tamanno, proyectoVivienda, estado, anexo)
VALUES ('AA1234', 500000000, '3 habitaciones 2 ba�os, cocina integral y dos
parqueaderos ', 1, 'Casa', 200, 0, 'Disponible', NULL);
INSERT INTO ubicaciones (latitud, longitud, ciudad, zona, direccion, barrio, ofertas_codigo)
VALUES ('4.729083004417865', '-74.07114789769088', 'Bogota', 'Norte', 'xxxxx','Colina Campestre', 'AA1234');
/*PoblarXML*/
INSERT INTO ofertas (codigoVivienda, costo, descripcion, condicion, tipoVivienda, tamanno, proyectoVivienda, estado, anexo)
VALUES ('AA5678', 300000000, '2 habitaciones 1 ba�os', 1, 'Casa', 150, 0, 'Disponible', 
'<?xml version="1.0" encoding="UTF-8"?>
<Annexes>
    <HouseNumber>1234</HouseNumber>
    <Documents>
        <Document Name = "Certificado" NumIdentification = "12345" URL = "www.certificados.com"></Document>
    </Documents>
</Annexes>');
INSERT INTO ofertas (codigoVivienda, costo, descripcion, condicion, tipoVivienda, tamanno, proyectoVivienda, estado, anexo)
VALUES ('AA9101', 400000000, '3 habitaciones 1 ba�o, cocina y parqueadero', 
1, 'Apartamento', 180, 0, 'Disponible', 
'<?xml version="1.0" encoding="UTF-8"?>
<Annexes>
    <HouseNumber>1234</HouseNumber>
    <Documents>
        <Document Name = "Certificado" NumIdentification = "98762" URL = "www.certificados.com"></Document>
    </Documents>
</Annexes>');
INSERT INTO ubicaciones (latitud, longitud, ciudad, zona, direccion, barrio, ofertas_codigo)
VALUES ('4.85686756', '54.24523453245234', 'Bogota', 'Oeste', 'xxxxx','Oeste', 'AA5678');
INSERT INTO ubicaciones (latitud, longitud, ciudad, zona, direccion, barrio, ofertas_codigo)
VALUES ('8.78134687123412', '34.314123412', 'Bogota', 'Sur', 'xxxxx','Sur', 'AA9101');
/*PoblarNoOk*/
