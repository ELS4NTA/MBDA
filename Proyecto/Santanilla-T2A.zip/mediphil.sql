/*ESTRUCTURA Y RESTRICCIONES DECLARATIVAS*/
/*PERSISTENCIA*/
/*TABLAS*/
CREATE TABLE ubicaciones(calle NUMBER(3) NOT NULL, carrera NUMBER(3) NOT NULL, torre NUMBER(3), apartamento NUMBER(5), manzana NUMBER(3), localUbi NUMBER(3));
CREATE TABLE despachos(despachosId NUMBER NOT NULL, farmacia_nit NUMBER, zonaSalida  NUMBER(20), zonaLlegada  NUMBER(20));
CREATE TABLE telefonos(numero NUMBER(10) NOT NULL, farmacia_nit NUMBER);
CREATE TABLE farmacias(nit NUMBER NOT NULL, sucursal NUMBER(10), ubicacion_calle NUMBER(3), ubicacion_carrera NUMBER(3));
CREATE TABLE medicamentos(medicamentoId NUMBER NOT NULL, laboratorio VARCHAR(50), nombre VARCHAR(20), descripcion VARCHAR(50), fechaElaboracion DATE, fechaVencimiento DATE, farmacia_nit NUMBER);
CREATE TABLE ventas(noFactura NUMBER NOT NULL, precio NUMBER(10), horaVenta DATE, cantidadProductos NUMBER, tipoPago VARCHAR(10), despacho_id NUMBER);
CREATE TABLE productos(PI NUMBER NOT NULL, idMedicamento NUMBER, despacho_id NUMBER);
CREATE TABLE recetasMedicas(RMI NUMBER NOT NULL, prescipcion VARCHAR(50), candidadMedicamento NUMBER, idMedicamento NUMBER, nombreMedicamento VARCHAR(20));
CREATE TABLE revisiones(pedido_id NUMBER NOT NULL, recetasMedicas_RM NUMBER NOT NULL);
CREATE TABLE clientes(usuario_cedula NUMBER NOT NULL, correo VARCHAR(20), ubicacion_calle NUMBER(3), ubicacion_carrera NUMBER(3));
CREATE TABLE pedidos(pedidoId NUMBER NOT NULL, cliente_cedula NUMBER, cantidadMedicamento NUMBER);
CREATE TABLE eleccionesZonas(domiciliario_usuario_cedula NUMBER NOT NULL, zona_id NUMBER(20) NOT NULL);
CREATE TABLE entregas(codEntrega VARCHAR(20) NOT NULL, horaEntrega DATE, domiciliario_cedula NUMBER, cantidadMedicamento NUMBER, cliente_cedula NUMBER);
CREATE TABLE usuarios(cedula NUMBER NOT NULL, nombre VARCHAR(20), telefono NUMBER(10));
CREATE TABLE zonas(zonaId NUMBER(20) NOT NULL, localidad NUMBER(10));
CREATE TABLE barrios(BI NUMBER NOT NULL, zona_id NUMBER(20), barrio VARCHAR(50));
CREATE TABLE domiciliarios(usuario_cedula NUMBER NOT NULL, licencia VARCHAR(20));
CREATE TABLE vehiculos(placa VARCHAR(10) NOT NULL, tipoVehiculo VARCHAR(20), domiciliario_cedula NUMBER);
/*ATRIBUTOS*/
ALTER TABLE clientes ADD CONSTRAINT CK_clientes_correo CHECK (REGEXP_LIKE(correo, '(.)+\@(.)+\.(.)+'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_placa CHECK (REGEXP_LIKE(placa, '[:upper:]{3}\d{3}'));
ALTER TABLE ventas ADD CONSTRAINT CK_venta_tipoPago CHECK (VALUE IN ('PSE', 'EFECTIVO', 'TARJETA'));
ALTER TABLE ventas ADD CONSTRAINT CK_venta_precio CHECK (VALUE >= 0);
/*PRIMARIAS*/
ALTER TABLE ubicaciones ADD CONSTRAINT PK_calle_carrera PRIMARY KEY (calle, carrera);
ALTER TABLE despachos ADD CONSTRAINT PK_despachosId PRIMARY KEY (despachosId);
ALTER TABLE telefonos ADD CONSTRAINT PK_numero PRIMARY KEY (numero);
ALTER TABLE farmacias ADD CONSTRAINT PK_nit PRIMARY KEY (nit);
ALTER TABLE medicamentos ADD CONSTRAINT PK_medicamentosID PRIMARY KEY (medicamentoId);
ALTER TABLE ventas ADD CONSTRAINT PK_noFactura PRIMARY KEY (noFactura);
ALTER TABLE productos ADD CONSTRAINT PK_PI PRIMARY KEY (PI);
ALTER TABLE recetasMedicas ADD CONSTRAINT PK_RMI PRIMARY KEY (RMI);
ALTER TABLE revisiones ADD CONSTRAINT PK_pedidoId_recetasMedicasRM PRIMARY KEY (pedido_id, recetasMedicas_RM);
ALTER TABLE clientes ADD CONSTRAINT PK_cliente_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT PK_pedidoId PRIMARY KEY (pedidoId);
ALTER TABLE eleccionesZonas ADD CONSTRAINT PK_domiciliario_zona PRIMARY KEY (domiciliario_usuario_cedula, zona_id);
ALTER TABLE entregas ADD CONSTRAINT PK_codEntrega PRIMARY KEY (codEntrega);
ALTER TABLE usuarios ADD CONSTRAINT PK_cedula PRIMARY KEY (cedula);
ALTER TABLE zonas ADD CONSTRAINT PK_zonaId PRIMARY KEY (zonaId);
ALTER TABLE barrios ADD CONSTRAINT PK_BI PRIMARY KEY (BI);
ALTER TABLE domiciliarios ADD CONSTRAINT PK_domiciliario_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE vehiculos ADD CONSTRAINT PK_placa PRIMARY KEY (placa);
/*UNICAS*/
ALTER TABLE usuarios ADD CONSTRAINT UK_telefono UNIQUE (telefono);
ALTER TABLE domiciliarios ADD CONSTRAINT UK_licencia UNIQUE (licencia);
ALTER TABLE clientes ADD CONSTRAINT UK_correo UNIQUE (correo);
/*FORANEAS*/
ALTER TABLE despachos ADD CONSTRAINT FK_despachos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE despachos ADD CONSTRAINT FK_despachos_zonasSale FOREIGN KEY (zonaSalida) REFERENCES zonas(zonaId);
ALTER TABLE despachos ADD CONSTRAINT FK_despachos_zonasLlega FOREIGN KEY (zonaLlegada) REFERENCES zonas(zonaId);
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE farmacias ADD CONSTRAINT FK_farmacias_ubiCalle FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
ALTER TABLE medicamentos ADD CONSTRAINT FK_medicamentos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE ventas ADD CONSTRAINT FK_ventas_despachos FOREIGN KEY (despacho_id) REFERENCES despachos(despachosId);
ALTER TABLE productos ADD CONSTRAINT FK_productos_despachos FOREIGN KEY (despacho_id) REFERENCES despachos(despachosId);
ALTER TABLE productos ADD CONSTRAINT FK_productos_medicamentos FOREIGN KEY (idMedicamento) REFERENCES  medicamentos(medicamentoId);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMed_medicamentos FOREIGN KEY (idMedicamento) REFERENCES medicamentos(medicamentoId);
ALTER TABLE revisiones ADD CONSTRAINT FK_revisiones_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(pedidoId);
ALTER TABLE revisiones ADD CONSTRAINT FK_revisiones_recetasMed FOREIGN KEY (recetasMedicas_RM) REFERENCES recetasMedicas(RMI);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuario FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_ubicacionCalle FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
ALTER TABLE eleccionesZonas ADD CONSTRAINT FK_eleccionesZ_domiciliarios FOREIGN KEY (domiciliario_usuario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE eleccionesZonas ADD CONSTRAINT FK_eleccionesZ_zonas FOREIGN KEY (zona_id) REFERENCES zonas(zonaId);
ALTER TABLE entregas ADD CONSTRAINT FK_entregas_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE entregas ADD CONSTRAINT FK_entregas_cliente FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula);
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(zonaId);
ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
/*XTablas*/
DROP TABLE telefonos PURGE;
DROP TABLE revisiones PURGE;
DROP TABLE barrios PURGE;
DROP TABLE entregas PURGE;
DROP TABLE ventas PURGE;
DROP TABLE eleccionesZonas PURGE;
DROP TABLE vehiculos PURGE;
DROP TABLE productos PURGE;
DROP TABLE recetasMedicas PURGE;
DROP TABLE pedidos PURGE;
DROP TABLE clientes PURGE;
DROP TABLE domiciliarios PURGE;
DROP TABLE usuarios PURGE;
DROP TABLE medicamentos PURGE;
DROP TABLE despachos PURGE;
DROP TABLE farmacias PURGE;
DROP TABLE zonas PURGE;
DROP TABLE ubicaciones PURGE;
/*CONSULTAS*/


/*PRUEBAS*/
/*PoblarOk*/

/*PoblarNoOk*/

/*XPoblar*/
DELETE FROM ubicaciones;
DELETE FROM despachos;
DELETE FROM telefonos;
DELETE FROM farmacias;
DELETE FROM medicamentos;
DELETE FROM ventas;
DELETE FROM productos;
DELETE FROM recetasMedicas;
DELETE FROM revisiones;
DELETE FROM clientes;
DELETE FROM pedidos;
DELETE FROM eleccionesZonas;
DELETE FROM entregas;
DELETE FROM usuarios;
DELETE FROM zonas;
DELETE FROM barrios;
DELETE FROM domiciliarios;
DELETE FROM vehiculos;



/*RESTRICCIONES DECLARATIVAS-PROCEDIMENTALES Y AUTOMATIZACION*/
/*PERSISTENCIA*/
/*ACCIONES*/
/*DISPARADORES*/
/*XDisparadores*/

/*PRUEBAS*/
/*TuplasOk*/
/*TuplasNoOk*/
/*AccionesOk*/
/*DisparadoresOk*/
/*DisparadoresNoOk*/



