/*ESTRUCTURA Y RESTRICCIONES DECLARATIVAS*/
/*TABLAS*/
CREATE TABLE usuarios(
    cedula NUMBER NOT NULL, 
    nomrbe VARCHAR(20), 
    telefono NUMBER
);
CREATE TABLE domiciliarios(
    usuario_cedula NUMBER NOT NULL, 
    licencia VARCHAR(20)
);
CREATE TABLE vehiculos(
    placa VARCHAR(7) NOT NULL, 
    tipoVehiculo VARCHAR(10), 
    domiciliario_cedula NUMBER NOT NULL
);
CREATE TABLE zonas(
    idZona NUMBER(20) NOT NULL, 
    localidad VARCHAR(20)
);
CREATE TABLE barrios(
    idBarrio NUMBER NOT NULL, 
    barrio VARCHAR(20), 
    zona_id NUMBER(20)
);
CREATE TABLE zonaXDomiciliario(
    domiciliario_cedula NUMBER NOT NULL, 
    zona_id NUMBER(20) NOT NULL, 
    fechaAsignacion DATE
);
CREATE TABLE ubicaciones(
    calle NUMBER(3) NOT NULL, 
    carrera NUMBER(3) NOT NULL, 
    torre NUMBER(3), 
    apartamento NUMBER(5), 
    manzana NUMBER(3), 
    localUbi NUMBER(3), 
    zona_id NUMBER(20) NOT NULL
);
CREATE TABLE clientes(
    usuario_cedula NUMBER NOT NULL, 
    correo VARCHAR(20), 
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE farmacias(
    nit NUMBER NOT NULL, 
    sucursal NUMBER(10),
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE telefonos(
    idTelefono NUMBER NOT NULL, 
    telefono  NUMBER(10), 
    armacia_nit  NUMBER NOT NULL
);
CREATE TABLE medicamentos(
    idMedicamento NUMBER NOT NULL, 
    laboratorio VARCHAR(50), 
    nombre VARCHAR(20), 
    descripcion VARCHAR(50), 
    fechaElaboracion DATE, 
    fechaVencimiento DATE, 
    farmacia_nit NUMBER)
;
CREATE TABLE recetasMedicas(
    idRecetaM NUMBER NOT NULL, 
    prescipcion VARCHAR(50), 
    candidadMedicamento NUMBER, 
    medicamento_id NUMBER NOT NULL, 
    pedido_id NUMBER
);
CREATE TABLE pedidos(
    idPedido NUMBER NOT NULL, 
    totalMedicamento NUMBER, 
    fechaYHoraEntrega DATE NOT NULL, 
    estado VARCHAR(20) NOT NULL, 
    domiciliario_cedula NUMBER NOT NULL, 
    cliente_cedula NUMBER NOT NULL
);
CREATE TABLE ventas(
    noFactura NUMBER NOT NULL, 
    precio NUMBER(10), 
    horaVenta DATE, 
    tipoPago VARCHAR(10), 
    pedido_id NUMBER
);
/*ATRIBUTOS*/
ALTER TABLE clientes ADD CONSTRAINT CK_clientes_correo CHECK (REGEXP_LIKE(correo, '^(\S+)\@(\S+)\.(\S+)$'));
ALTER TABLE pedidos ADD CONSTRAINT CK_pedidos_estado CHECK (estado IN ('Entregado', 'Cancelado', 'Enviado'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_placa CHECK (REGEXP_LIKE(placa, '[:upper:]{3}\d{3}'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_tipoVehiculo CHECK (tipoVehiculo IN ('Bici', 'Carro', 'Moto'));
ALTER TABLE ventas ADD CONSTRAINT CK_venta_tipoPago CHECK (tipoPago IN ('PSE', 'EFECTIVO', 'TARJETA'));
ALTER TABLE ventas ADD CONSTRAINT CK_venta_precio CHECK (precio >= 0);
ALTER TABLE ventas ADD CONSTRAINT CK_venta_horaVenta CHECK (horaVenta LIKE (TO_CHAR(horaVenta,'HH24:MI:SS')));
/*Primarias*/
ALTER TABLE ubicaciones ADD CONSTRAINT PK_calle_carrera PRIMARY KEY (calle, carrera);
ALTER TABLE telefonos ADD CONSTRAINT PK_numero PRIMARY KEY (idTelefono);
ALTER TABLE farmacias ADD CONSTRAINT PK_nit PRIMARY KEY (nit);
ALTER TABLE medicamentos ADD CONSTRAINT PK_medicamentosID PRIMARY KEY (idMedicamento);
ALTER TABLE ventas ADD CONSTRAINT PK_noFactura PRIMARY KEY (noFactura);
ALTER TABLE recetasMedicas ADD CONSTRAINT PK_RMI PRIMARY KEY (idRecetaM);
ALTER TABLE clientes ADD CONSTRAINT PK_cliente_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT PK_pedidoId PRIMARY KEY (idPedido);
ALTER TABLE usuarios ADD CONSTRAINT PK_cedula PRIMARY KEY (cedula);
ALTER TABLE zonas ADD CONSTRAINT PK_zonaId PRIMARY KEY (idZona);
ALTER TABLE barrios ADD CONSTRAINT PK_BI PRIMARY KEY (idBarrio);
ALTER TABLE domiciliarios ADD CONSTRAINT PK_domiciliario_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE vehiculos ADD CONSTRAINT PK_placa PRIMARY KEY (placa);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT PK_domiciliariosCedula_zonasId PRIMARY KEY (domiciliario_cedula, zona_id);
/*Unicas*/
ALTER TABLE usuarios ADD CONSTRAINT UK_telefono UNIQUE (telefono);
ALTER TABLE domiciliarios ADD CONSTRAINT UK_licencia UNIQUE (licencia);
ALTER TABLE clientes ADD CONSTRAINT UK_correo UNIQUE (correo);
/*Foraneas*/
ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE ventas ADD CONSTRAINT FK_ventas_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(idPedido);
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE medicamentos ADD CONSTRAINT FK_medicamentos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE ubicaciones ADD CONSTRAINT FK_ubicaciones_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_medicamentos FOREIGN KEY (medicamento_id) REFERENCES medicamentos(idMedicamento);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(idPedido);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_clientes FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula);
ALTER TABLE farmacias ADD CONSTRAINT FK_farmacias_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT FK_zonaXDomi_domiciliaros FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT FK_zonaXDomi_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
/*XTablas*/
DROP TABLE telefonos CASCADE CONSTRAINTS PURGE;
DROP TABLE barrios CASCADE CONSTRAINTS PURGE;
DROP TABLE ventas CASCADE CONSTRAINTS PURGE;
DROP TABLE vehiculos CASCADE CONSTRAINTS PURGE;
DROP TABLE recetasMedicas CASCADE CONSTRAINTS PURGE;
DROP TABLE pedidos CASCADE CONSTRAINTS PURGE;
DROP TABLE clientes CASCADE CONSTRAINTS PURGE;
DROP TABLE domiciliarios CASCADE CONSTRAINTS PURGE;
DROP TABLE usuarios CASCADE CONSTRAINTS PURGE;
DROP TABLE medicamentos CASCADE CONSTRAINTS PURGE;
DROP TABLE farmacias CASCADE CONSTRAINTS PURGE;
DROP TABLE zonas CASCADE CONSTRAINTS PURGE;
DROP TABLE ubicaciones CASCADE CONSTRAINTS PURGE;
DROP TABLE zonaXDomiciliario CASCADE CONSTRAINTS PURGE;
/*Consultas*/

/*PoblarOk*/

/*PoblarNoOk*/

/*XPoblar*/
DELETE FROM telefonos ;
DELETE FROM barrios;
DELETE FROM ventas;
DELETE FROM vehiculos;
DELETE FROM recetasMedicas;
DELETE FROM pedidos;
DELETE FROM clientes;
DELETE FROM domiciliarios;
DELETE FROM usuarios;
DELETE FROM medicamentos;
DELETE FROM farmacias;
DELETE FROM zonas;
DELETE FROM ubicaciones;
DELETE FROM zonaXDomiciliaro;



/*RESTRICCIONES DECLARATIVAS-PROCEDIMENTALES Y AUTOMATIZACION*/
/*ACCIONES*/
/*DISPARADORES*/
CREATE SEQUENCE zonas_seq START WITH 1; --Se va a automatizar idZona
CREATE SEQUENCE barrios_seq START WITH 1; -- Se va a automatizar idBarrio
CREATE SEQUENCE medicamentos_seq START WITH 1; -- Se va a automatizar idMedicamento
CREATE SEQUENCE recetasMed_seq START WITH 1; -- Se va a automatizar idReceta
CREATE SEQUENCE pedidos_seq START WITH 1; -- Se va a automatizar idPedido
CREATE SEQUENCE ventas_seq START WITH 1; -- Se va a automatizar noFactura
CREATE SEQUENCE telefonos_seq START WITH 1; -- Se va a automatizar idTelefono
/*BI*/
---
CREATE OR REPLACE TRIGGER TG_ZONAS_BI
BEFORE INSERT ON zonas
FOR EACH ROW
BEGIN
    SELECT zonas_seq.NEXTVAL INTO :new.idZona FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_BARRIOS_BI
BEFORE INSERT ON barrios
FOR EACH ROW
BEGIN
    SELECT barrios_seq.NEXTVAL INTO :new.idBarrio FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_MEDICAMENTOS_BI
BEFORE INSERT ON medicamentos
FOR EACH ROW
BEGIN
    IF (:new.fechaElaboracion > :new.fechaVencimiento) THEN
        raise_application_error(-20002,'No se puede tener una fecha de fabricacion mayor a la de venecimiento.'); 
    END IF;
    SELECT medicamentos_seq.NEXTVAL INTO :new.idMedicamento FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_RECETASMED_BI
BEFORE INSERT ON recetasMedicas
FOR EACH ROW
BEGIN
    SELECT recetasMed_seq.NEXTVAL INTO :new.idReceta FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_PEDIDOS_BI
BEFORE INSERT ON pedidos
FOR EACH ROW
BEGIN
    SELECT pedidos_seq.NEXTVAL INTO :new.idPedido FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_VENTAS_BI
BEFORE INSERT ON ventas
FOR EACH ROW
BEGIN
    SELECT TO_DATE(sysdate, 'HH24:MI:SS') INTO :new.horaVenta FROM dual;
    SELECT LPAD(ventas_seq.NEXTVAL,6,0) INTO :new.noFactura FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_TELEFONOS_BI
BEFORE INSERT ON telefonos
FOR EACH ROW
BEGIN
    SELECT telefonos_seq.NEXTVAL INTO :new.idTelefono FROM dual;
END;
/*BU*/
CREATE OR REPLACE TRIGGER TG_USUARIOS_BU
BEFORE UPDATE ON usuarios
FOR EACH ROW
BEGIN
    IF (:new.cedula != :old.cedula) THEN 
        raise_application_error(-20000,'No se puede actualizar el numero de cedula.'); 
    END IF;
END;
CREATE OR REPLACE TRIGGER TG_FARMACIAS_BU
BEFORE UPDATE ON farmacias
FOR EACH ROW
BEGIN
    IF (:new.nit != :old.nit) THEN 
        raise_application_error(-20001,'No se puede actualizar el nit.'); 
    END IF;
END;
/*XDisparadores*/
DROP TRIGGER TG_ZONAS_BI;
DROP TRIGGER TG_BARRIOS_BI;
DROP TRIGGER TG_MEDICAMENTOS_BI;
DROP TRIGGER TG_RECETASMED_BI;
DROP TRIGGER TG_PEDIDOS_BI;
DROP TRIGGER TG_VENTAS_BI;
DROP TRIGGER TG_TELEFONOS_BI;
DROP TRIGGER TG_USUARIOS_BU;
DROP TRIGGER TG_FARMACIAS_BU;


/*TuplasOk*/
/*TuplasNoOk*/
/*AccionesOk*/
/*DisparadoresOk*/
/*DisparadoresNoOk*/



