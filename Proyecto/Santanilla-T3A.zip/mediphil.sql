/*ESTRUCTURA*/
/*TABLAS*/
CREATE TABLE usuarios(
    cedula NUMBER NOT NULL, 
    nombre VARCHAR(20) NOT NULL, 
    telefono NUMBER NOT NULL
);
CREATE TABLE domiciliarios(
    usuario_cedula NUMBER NOT NULL, 
    licencia VARCHAR(20) NOT NULL
);
CREATE TABLE vehiculos(
    placa VARCHAR(7) NOT NULL, 
    tipoVehiculo VARCHAR(10) NOT NULL, 
    domiciliario_cedula NUMBER NOT NULL
);
CREATE TABLE zonas(
    idZona NUMBER(20) NOT NULL, 
    localidad VARCHAR(20) NOT NULL
);
CREATE TABLE barrios(
    idBarrio NUMBER NOT NULL, 
    barrio VARCHAR(20) NOT NULL, 
    zona_id NUMBER(20) NOT NULL
);
CREATE TABLE zonaXDomiciliario(
    domiciliario_cedula NUMBER NOT NULL, 
    zona_id NUMBER(20) NOT NULL, 
    fechaAsignacion DATE
);
CREATE TABLE ubicaciones(
    calle NUMBER(3) NOT NULL, 
    carrera NUMBER(3) NOT NULL, 
    torre NUMBER(3), 
    apartamento NUMBER(5), 
    manzana NUMBER(3), 
    localUbi NUMBER(3), 
    zona_id NUMBER(20) NOT NULL
);
CREATE TABLE clientes(
    usuario_cedula NUMBER NOT NULL, 
    correo VARCHAR(50) NOT NULL, 
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE farmacias(
    nit NUMBER NOT NULL, 
    sucursal NUMBER(10),
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE telefonos(
    idTelefono NUMBER NOT NULL, 
    telefono  NUMBER(10) NOT NULL, 
    farmacia_nit  NUMBER NOT NULL
);
CREATE TABLE medicamentos(
    idMedicamento NUMBER NOT NULL, 
    laboratorio VARCHAR(50) NOT NULL, 
    nombre VARCHAR(50) NOT NULL, 
    descripcion VARCHAR(100) NOT NULL, 
    fechaElaboracion DATE NOT NULL, 
    fechaVencimiento DATE NOT NULL, 
    farmacia_nit NUMBER NOT NULL
);
CREATE TABLE recetasMedicas(
    idRecetaM NUMBER NOT NULL, 
    prescipcion VARCHAR(50) NOT NULL, 
    candidadMedicamento NUMBER NOT NULL, 
    medicamento_id NUMBER NOT NULL, 
    pedido_id NUMBER NOT NULL
);
CREATE TABLE pedidos(
    idPedido NUMBER NOT NULL, 
    fechaYHoraEntrega DATE, 
    estado VARCHAR(20) NOT NULL, 
    domiciliario_cedula NUMBER NOT NULL, 
    cliente_cedula NUMBER NOT NULL,
    noFactura NUMBER NOT NULL,
    horaVenta DATE NOT NULL,
    precio VARCHAR(20) NOT NULL,
    tipoPago VARCHAR(10) NOT NULL
);
-------------
/*Primarias*/
ALTER TABLE ubicaciones ADD CONSTRAINT PK_calle_carrera PRIMARY KEY (calle, carrera);
ALTER TABLE telefonos ADD CONSTRAINT PK_numero PRIMARY KEY (idTelefono);
ALTER TABLE farmacias ADD CONSTRAINT PK_nit PRIMARY KEY (nit);
ALTER TABLE medicamentos ADD CONSTRAINT PK_medicamentosID PRIMARY KEY (idMedicamento);
ALTER TABLE recetasMedicas ADD CONSTRAINT PK_RMI PRIMARY KEY (idRecetaM);
ALTER TABLE clientes ADD CONSTRAINT PK_cliente_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT PK_pedidoId PRIMARY KEY (idPedido);
ALTER TABLE usuarios ADD CONSTRAINT PK_cedula PRIMARY KEY (cedula);
ALTER TABLE zonas ADD CONSTRAINT PK_zonaId PRIMARY KEY (idZona);
ALTER TABLE barrios ADD CONSTRAINT PK_BI PRIMARY KEY (idBarrio);
ALTER TABLE domiciliarios ADD CONSTRAINT PK_domiciliario_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE vehiculos ADD CONSTRAINT PK_placa PRIMARY KEY (placa);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT PK_domiciliariosCedula_zonasId PRIMARY KEY (domiciliario_cedula, zona_id);
/*Unicas*/
ALTER TABLE usuarios ADD CONSTRAINT UK_telefono UNIQUE (telefono);
ALTER TABLE clientes ADD CONSTRAINT UK_correo UNIQUE (correo);
/*Foraneas*/
ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE medicamentos ADD CONSTRAINT FK_medicamentos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE ubicaciones ADD CONSTRAINT FK_ubicaciones_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_medicamentos FOREIGN KEY (medicamento_id) REFERENCES medicamentos(idMedicamento);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(idPedido);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_clientes FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula);
ALTER TABLE farmacias ADD CONSTRAINT FK_farmacias_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT FK_zonaXDomi_domiciliaros FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT FK_zonaXDomi_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
-------------
/*RESTRICCIONES DECLARATIVAS-PROCEDIMENTALES Y AUTOMATIZACION*/
/*ACCIONES*/
ALTER TABLE domiciliarios DROP CONSTRAINT FK_domiciliarios_usuarios;
ALTER TABLE clientes DROP CONSTRAINT FK_clientes_usuarios;
ALTER TABLE vehiculos DROP CONSTRAINT FK_vehiculos_domiciliarios;
ALTER TABLE telefonos DROP CONSTRAINT FK_telefonos_farmacias;
ALTER TABLE barrios DROP CONSTRAINT FK_barrios_zonas;
ALTER TABLE clientes DROP CONSTRAINT FK_clientes_ubicaciones;
ALTER TABLE recetasMedicas DROP CONSTRAINT FK_recetasMedicas_medicamentos;

ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula) ON DELETE CASCADE;
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula) ON DELETE CASCADE;
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula) ON DELETE CASCADE;
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit) ON DELETE CASCADE;
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona) ON DELETE CASCADE;
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_medicamentos FOREIGN KEY (medicamento_id) REFERENCES medicamentos(idMedicamento) ON DELETE SET NULL;
-------------
/*TUPLAS*/
ALTER TABLE clientes ADD CONSTRAINT CK_clientes_correo CHECK (REGEXP_LIKE(correo, '(.+)\@(.+)\.(.+)'));
ALTER TABLE domiciliarios ADD CONSTRAINT CK_domiciliarios_licencia CHECK (licencia IN ('Valida', 'Invalida'));
ALTER TABLE pedidos ADD CONSTRAINT CK_pedidos_estado CHECK (estado IN ('Entregado', 'Cancelado', 'Enviado'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_placa CHECK (REGEXP_LIKE(placa, '[:upper:]{3}\d{3}'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_tipoVehiculo CHECK (tipoVehiculo IN ('Bici', 'Carro', 'Moto'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_tipoPago CHECK (tipoPago IN ('PSE', 'EFECTIVO', 'TARJETA'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_precio CHECK (REGEXP_LIKE(precio, '^\$[0-9]{1,7}([\\.][0-9]{3})'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_horaVenta CHECK (horaVenta LIKE (TO_CHAR(horaVenta,'HH24:MI')));
-------------
/*DISPARADORES*/
CREATE SEQUENCE zonas_seq START WITH 1; --Se va a automatizar idZona
CREATE SEQUENCE barrios_seq START WITH 1; -- Se va a automatizar idBarrio
CREATE SEQUENCE medicamentos_seq START WITH 1; -- Se va a automatizar idMedicamento
CREATE SEQUENCE recetasMed_seq START WITH 1; -- Se va a automatizar idReceta
CREATE SEQUENCE pedidos_seq START WITH 1; -- Se va a automatizar idPedido
CREATE SEQUENCE telefonos_seq START WITH 1; -- Se va a automatizar idTelefono
CREATE SEQUENCE ventas_seq START WITH 1; -- Se va a automatizar noFactura
/*BI*/
CREATE OR REPLACE TRIGGER TG_ZONAS_BI
BEFORE INSERT ON zonas
FOR EACH ROW
BEGIN
    SELECT zonas_seq.NEXTVAL INTO :new.idZona FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_BARRIOS_BI
BEFORE INSERT ON barrios
FOR EACH ROW
BEGIN
    SELECT barrios_seq.NEXTVAL INTO :new.idBarrio FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_MEDICAMENTOS_BI
BEFORE INSERT ON medicamentos
FOR EACH ROW
BEGIN
    IF (:new.fechaElaboracion > :new.fechaVencimiento) THEN
        raise_application_error(-20001,'No se puede tener una fecha de fabricacion mayor a la de venecimiento.'); 
    END IF;
    SELECT medicamentos_seq.NEXTVAL INTO :new.idMedicamento FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_RECETASMED_BI
BEFORE INSERT ON recetasMedicas
FOR EACH ROW
BEGIN
    SELECT recetasMed_seq.NEXTVAL INTO :new.idRecetaM FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_PEDIDOS_BI
BEFORE INSERT ON pedidos
FOR EACH ROW
BEGIN
    SELECT TO_DATE(sysdate, 'HH24:MI') INTO :new.horaVenta FROM dual;
    SELECT pedidos_seq.NEXTVAL INTO :new.idPedido FROM dual;
    SELECT LPAD(ventas_seq.NEXTVAL,6,0) INTO :new.noFactura FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_TELEFONOS_BI
BEFORE INSERT ON telefonos
FOR EACH ROW
BEGIN
    SELECT telefonos_seq.NEXTVAL INTO :new.idTelefono FROM dual;
END;
/*BU*/
CREATE OR REPLACE TRIGGER TG_USUARIOS_BU
BEFORE UPDATE ON usuarios
FOR EACH ROW
BEGIN
    IF (:new.cedula != :old.cedula) THEN 
        raise_application_error(-20002,'No se puede actualizar el numero de cedula.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_FARMACIAS_BU
BEFORE UPDATE ON farmacias
FOR EACH ROW
BEGIN
    IF (:new.nit != :old.nit) THEN 
        raise_application_error(-20003,'No se puede actualizar el nit.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_MEDICAMENTOS_BU
BEFORE UPDATE ON medicamentos
FOR EACH ROW
BEGIN
    IF (:new.fechaElaboracion != :old.fechaElaboracion OR :new.fechaVencimiento != :old.fechaVencimiento) THEN 
        raise_application_error(-20004,'No se puede actualizar el medicamento.'); 
    END IF;
END;
-------------
/*COMPONENTES*/
/*CRUDE*/
CREATE OR REPLACE PACKAGE PC_FARMACIAS IS
    PROCEDURE add_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER);
    PROCEDURE mod_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR);
    FUNCTION co_medicamento (xNombre IN VARCHAR)  RETURN SYS_REFCURSOR;
    PROCEDURE el_medicamento (xIdMedicamento IN VARCHAR);
    FUNCTION co_farmacias RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PC_PEDIDOS IS
    PROCEDURE adicionar (xIdPedido IN NUMBER, xFechaYHoraEntrega IN DATE, xEstado IN VARCHAR, xDomiciliario IN NUMBER, xCliente IN NUMBER, xNoFactura IN NUMBER, xHoraVenta IN DATE, xPrecio IN NUMBER, xTipoPago IN VARCHAR);
    PROCEDURE mo_estadoCliente (xIdPedido IN NUMBER, xEstado IN VARCHAR);
    PROCEDURE mo_entregaYEstado (xIdPedido IN NUMBER, xEstado IN VARCHAR);
    FUNCTION co_pedido (xIdPedido IN NUMBER)  RETURN SYS_REFCURSOR;
    FUNCTION co_entregados RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PC_USUARIOS IS
    PROCEDURE adicionar (xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xLicencia IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE mod_nombre (xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mod_telefono (xCedula IN NUMBER, xTelefono IN NUMBER);
    PROCEDURE eliminar (xCedula IN NUMBER);
    FUNCTION co_usuario (xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    --FUNCTION co_catidadPedidos RETURN SYS_REFCURSOR;
    PROCEDURE add_vehiculo (xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE mod_vehiculo (xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR);
END;
---
CREATE OR REPLACE PACKAGE PC_UBICACIONES IS 
    PROCEDURE adicionar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE modificar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    FUNCTION co_cliente (xCedulaUsuario IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_ubicacion (xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
END;
/*CRUDI*/
CREATE OR REPLACE PACKAGE BODY PC_FARMACIAS IS
    PROCEDURE add_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER)
    IS
    BEGIN
        INSERT INTO medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit) 
        VALUES (xIdMedicamento, xLaboratorio, xNombre, xDescripcion, xElaboracion, xVencimiento, xNitFarmacia);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede insertar el medicamento.');
    END;
    --
    PROCEDURE mod_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR)
    IS
    BEGIN
        UPDATE medicamentos SET laboratorio = xLaboratorio, nombre = xNombre, descripcion = xDescripcion  WHERE idMedicamento = xIdMedicamento;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede actualizar el medicamento.');
    END;
    --
    FUNCTION co_medicamento (xNombre IN VARCHAR)  RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
    OPEN co_medicamento FOR
		SELECT nombre, laboratorio, fechaElaboracion, fechaVencimiento FROM medicamentos WHERE nombre = xNombre;
	RETURN co_medicamento;
    END;
    --
    PROCEDURE el_medicamento (xIdMedicamento IN VARCHAR)
    IS
    BEGIN
        DELETE FROM medicamentos WHERE idMedicamento = xIdMedicamento;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede eliminar el medicamento.');
    END;
    --
    FUNCTION co_farmacias RETURN SYS_REFCURSOR IS co_farmacias SYS_REFCURSOR;
    BEGIN
    OPEN co_farmacias FOR
		SELECT nit, sucursal FROM farmacias;
	RETURN co_farmacias;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_PEDIDOS IS
    PROCEDURE adicionar (xIdPedido IN NUMBER, xFechaYHoraEntrega IN DATE, xEstado IN VARCHAR, xDomiciliario IN NUMBER, xCliente IN NUMBER, xNoFactura IN NUMBER, xHoraVenta IN DATE, xPrecio IN NUMBER, xTipoPago IN VARCHAR)
    IS
    BEGIN
        INSERT INTO pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago)
        VALUES (xIdPedido, xFechaYHoraEntrega, xEstado, xDomiciliario, xCliente, xNoFactura, xHoraVenta, xPrecio, xTipoPago);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20006, 'No se puede insertar el pedido.');
    END;
    --
    PROCEDURE mo_estadoCliente (xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        UPDATE pedidos SET estado = xEstado WHERE idPedido = xIdPedido;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede actualizar el estado del pedido.');
    END;
    --
    PROCEDURE mo_entregaYEstado (xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    DECLARE
        xFechaYHoraEntrega DATE;
    BEGIN
        IF (xEstado != 'ENTREGADO') THEN
            RAISE_APPLICATION_ERROR(-20008, 'Estado de entrega incorrecto.');
        END IF;
        SELECT TO_DATE(sysdate, 'dd/mm/yyyy') INTO xFechaYHoraEntrega FROM dual;
        UPDATE pedidos SET estado = xEstado, fechaYHoraEntrega = xFechaYHoraEntrega  WHERE idPedido = xIdPedido;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20999, SQLERRM);
    END;
    --
    FUNCTION co_pedido (xIdPedido IN NUMBER)  RETURN SYS_REFCURSOR IS co_pedido SYS_REFCURSOR;
    BEGIN
    OPEN co_pedido FOR
		SELECT * FROM pedidos WHERE idPedido = xIdPedido;
	RETURN co_pedido;
    END;
    --
    FUNCTION co_entregados RETURN SYS_REFCURSOR IS co_entregados SYS_REFCURSOR;
    BEGIN
    OPEN co_entregados FOR
		SELECT * FROM pedidos WHERE estado = 'ENTREGADO';
	RETURN co_entregados;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_USUARIOS IS
    PROCEDURE adicionar (xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xLicencia IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        INSERT INTO usuarios (cedula, nombre, telefono)
        VALUES (xCedula, xNombre, xTelefono);
        IF (xCorreo != NULL) THEN
            INSERT INTO clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) VALUES (xCedula, xCorreo, xCalle, xCarrera);
        END IF;
        IF (xLicencia != NULL) THEN
            INSERT INTO domiciliarios (usuario_cedula, licencia) VALUES (xCedula, xLicencia);
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20009, 'No se puede insertar el usuario.');
    END;
    --
    PROCEDURE mod_nombre (xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        UPDATE usuarios SET nombre = xNombre WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'No se puede actualizar el nombre del usuario.');
    END;
    --
    PROCEDURE mod_telefono (xCedula IN NUMBER, xTelefono IN NUMBER)
    IS
    BEGIN
        UPDATE usuarios SET telefono = xTelefono WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede actualizar el telefono del usuario.');
    END;
    --
    PROCEDURE eliminar (xCedula IN NUMBER)
    IS
    BEGIN
        DELETE FROM usuarios WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede eliminar el usuario.');
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
    OPEN co_usuario FOR
		SELECT * FROM usuarios WHERE cedula = xCedula;
	RETURN co_usuario;
    END;
    --
    /*FUNCTION co_catidadPedidos RETURN SYS_REFCURSOR IS co_cantidadPedidos SYS_REFCURSOR;
    BEGIN
    OPEN co_cantidadPedidos FOR
		SELECT nombre, COUNT(idPedidos) FROM usuarios JOIN pedidos ON (usuario_cedula = cliente_cedula) WHERE estado = 'ENTREGADO' GROUP BY nombre;----
	RETURN co_cantidadPedidos;
    END;*/
    --
    PROCEDURE add_vehiculo (xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        INSERT INTO vehiculos (placa, tipoVehiculo, domiciliario_cedula) VALUES (xPlaca, xTipo, xCedula);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede insertar el vehiculo.');
    END;
    --
    PROCEDURE mod_vehiculo (xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        UPDATE vehiculos SET tipoVehiculo = xTipo WHERE placa = xPlaca;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede actualizar el vehiculo.');
    END;
    --
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR)
    IS
    BEGIN
        DELETE FROM vehiculos WHERE placa = xPlaca;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede eliminar el vehiculo.');
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_UBICACIONES IS 
    PROCEDURE adicionar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        INSERT INTO ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id)
        VALUES (xCalle, xCarrera, xTorre, xApto, xManz, xLocal, xZona);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'No se puede insertar la ubicacion.');
    END;
    --
    PROCEDURE modificar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        UPDATE ubicaciones SET calle=xCalle, carrera=xCarrera, torre=xTorre, apartamento=xApto, manzana=xManz, localUbi = xLocal, zona_id = xZona WHERE calle = xCalle AND carrera = xCarrera;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'No se puede actualizar la ubicacion.');
    END;
    --
    FUNCTION co_cliente (xCedulaUsuario IN NUMBER) RETURN SYS_REFCURSOR IS co_cliente SYS_REFCURSOR;
    DECLARE
        xCalle NUMBER;
        xCarrera NUMBER;
    BEGIN
    SELECT ubicacion_calle INTO xCalle FROM clientes WHERE usuario_cedula = xCedulaUsuario;
    SELECT ubicacion_carrera INTO xCarrera FROM clientes WHERE usuario_cedula = xCedulaUsuario;
    OPEN co_cliente FOR
		SELECT * FROM ubicaciones WHERE calle = xCalle AND carrera = xCarrera;
	RETURN co_cliente;
    END;
    --
    FUNCTION co_ubicacion (xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
    OPEN co_ubicacion FOR
        SELECT * FROM ubicaciones WHERE (calle = xCalle AND carrera = xCarrera);
	RETURN co_ubicacion;
    END;
END;
-------------
/*SEGURIDAD*/
/*ActoresE*/
CREATE OR REPLACE PACKAGE PA_CLIENTE IS
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR);
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE el_usuario(xCedula IN NUMBER);
    FUNCTION co_pedido(xIdPedido IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE mo_estadoPedido(xIdPedido IN NUMBER, xEstado IN VARCHAR);
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR;
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER);
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER);
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PA_DOMICILIARIO IS 
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xLicencia IN VARCHAR);
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR);
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE el_usuario(xCedula IN NUMBER);
    PROCEDURE ad_vehiculo(xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE mo_vehiculo(xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR);
    PROCEDURE mo_entregaYEstado(xIdPedido IN NUMBER, xEstado IN VARCHAR);
    FUNCTION co_ubicaCliente(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PA_FARMACEUTICO IS
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE ad_pedido(xDomiciliario IN NUMBER, xCliente IN NUMBER, xPrecio IN NUMBER, xTipoPago IN VARCHAR);
    PROCEDURE ad_medicamento(xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER);
    PROCEDURE mo_medicamento(xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR);
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR;
    PROCEDURE el_medicamento(xIdMedicamento IN VARCHAR);
END;
---
CREATE OR REPLACE PACKAGE PA_CONTADOR IS
    FUNCTION co_pedidoEntregados RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PA_ADMINISTRADOR IS
    FUNCTION co_usuarios RETURN SYS_REFCURSOR;
    FUNCTION co_farmacias RETURN SYS_REFCURSOR;
END;
/*ActoresI*/
CREATE OR REPLACE PACKAGE BODY PA_CLIENTE IS
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.adicionar(xCedula, xNombre, xTelefono, xCorreo, NULL, xCalle, xCarrera);
    END;
    --
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_nombre(xCedula, xNombre);
    END;
    --
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_telefono(xCedula, xTelefono);
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
        co_usuario := PC_USUARIOS.co_usuario(xCedula);
        RETURN co_usuario;
	END;
    --
    PROCEDURE el_usuario(xCedula IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.eliminar(xCedula);
    END;
    --
    FUNCTION co_pedido(xIdPedido IN NUMBER) RETURN SYS_REFCURSOR IS co_pedido SYS_REFCURSOR;
    BEGIN
        co_pedido := PC_PEDIDOS.co_pedido(xIdPedido);
        RETURN co_pedido;
	END;
    --
    PROCEDURE mo_estadoPedido(xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.mo_estadoCliente(xIdPedido, xEstado);
    END;
    --
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
        co_medicamento := PC_FARMACIAS.co_medicamento(xNombre);
        RETURN co_medicamento;
	END;
    --
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.adicionar(xCalle, xCarrera, xTorre, xApto, xManz, NULL, xZona);
    END;
    --
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.modificar(xCalle, xCarrera, xTorre, xApto, xManz, NULL, xZona);
    END;
    --
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR
    IS
    BEGIN
        PC_UBICACIONES.co_ubicacion(xCalle, xCarrera);
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_DOMICILIARIO IS 
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xLicencia IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.adicionar(xCedula, xNombre, xTelefono, NULL, xLicencia, NULL, NULL);
    END;
    --
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_nombre(xCedula, xNombre);
    END;
    --
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_telefono(xCedula, xTelefono);
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
        co_usuario := PC_USUARIOS.co_usuario(xCedula);
        RETURN co_usuario;
	END;
    --
    PROCEDURE el_usuario(xCedula IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.eliminar(xCedula);
    END;
    --
    PROCEDURE ad_vehiculo(xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.add_vehiculo(xCedula, xPlaca, xTipo);
    END;
    --
    PROCEDURE mo_vehiculo(xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_vehiculo(xPlaca, xTipo);
    END;
    --
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.el_vehiculo(xPlaca);
    END;
    --
    PROCEDURE mo_entregaYEstado(xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.mo_entregaYEstado(xIdPedido, xEstado);
    END;
    --
    FUNCTION co_ubicaCliente(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicaCliente SYS_REFCURSOR;
    BEGIN
        co_ubicaCliente := PC_UBICACIONES.co_cliente(xCedula);
        RETURN co_ubicaCliente;
	END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_FARMACEUTICO IS
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.adicionar(xCalle, xCarrera, NULL, NULL, NULL, xLocal, xZona);
    END;
    --
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.modificar(xCalle, xCarrera, NULL, NULL, NULL, xLocal, xZona);
    END;
    --
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN int) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
        co_ubicacion :=  PC_UBICACIONES.co_ubicacion(xCalle, xCarrera);
        RETURN co_ubicacion;
	END;
    --
    PROCEDURE ad_pedido(xDomiciliario IN NUMBER, xCliente IN NUMBER, xPrecio IN NUMBER, xTipoPago IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.adicionar(NULL, NULL, NULL, xDomiciliario, xCliente, NULL, NULL, xPrecio, xTipoPago);
    END;
    --
    PROCEDURE ad_medicamento(xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER)
    IS
    BEGIN
        PC_FARMACIAS.add_medicamento(NULL, xLaboratorio, xNombre, xDescripcion, xElaboracion, xVencimiento, xNitFarmacia);
    END;
    --
    PROCEDURE mo_medicamento(xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR)
    IS
    BEGIN
        PC_FARMACIAS.mod_medicamento (xIdMedicamento, xLaboratorio, xNombre, xDescripcion);
    END;
    --
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
        co_medicamento :=  PC_FARMACIAS.co_medicamento(xNombre);
        RETURN co_medicamento;
	END;
    --
    PROCEDURE el_medicamento(xIdMedicamento IN VARCHAR)
    IS
    BEGIN
        PC_FARMACIAS.el_medicamento(xIdMedicamento);
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_CONTADOR IS
    FUNCTION co_pedidoEntregados RETURN SYS_REFCURSOR IS co_pedidoEntregados SYS_REFCURSOR;
    BEGIN
        co_pedidoEntregados :=  PC_PEDIDOS.co_entregados;
        RETURN co_pedidoEntregados;
	END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_ADMINISTRADOR IS
    FUNCTION co_usuarios RETURN SYS_REFCURSOR IS co_usuarios SYS_REFCURSOR;
    BEGIN
        co_usuarios :=  PC_USUARIOS.co_catidadPedidos;
        RETURN co_usuarios;
	END;
    --
    FUNCTION co_farmacias RETURN SYS_REFCURSOR IS co_farmacias SYS_REFCURSOR;
    BEGIN
        co_farmacias :=  PC_FARMACIAS.co_farmacias;
        RETURN co_farmacias;
	END;
END;
/*Seguridad*/
CREATE ROLE cliente;
CREATE ROLE domiciliario;
CREATE ROLE farmaceutico;
CREATE ROLE administrador;
CREATE ROLE contador;

GRANT INSERT, SELECT, UPDATE, DELETE ON usuarios TO cliente;
GRANT SELECT ON pedidos TO cliente;
GRANT SELECT ON medicamentos TO cliente;
GRANT INSERT, SELECT, UPDATE, DELETE ON ubicaciones TO cliente;
GRANT INSERT, SELECT, UPDATE, DELETE ON vehiculos TO domiciliario;
GRANT SELECT, UPDATE ON pedidos TO domiciliario;
GRANT SELECT ON ubicaciones TO domiciliario;
GRANT INSERT, SELECT, UPDATE, DELETE ON ubicaciones TO farmaceutico;
GRANT INSERT, SELECT ON pedidos TO farmaceutico;
GRANT INSERT, SELECT, UPDATE, DELETE ON medicamentos TO farmaceutico;
GRANT SELECT ON pedidos TO contador;
GRANT SELECT ON usuarios TO administrador;
GRANT SELECT ON farmacias TO administrador;
-------------
/*XSeguridad*/
DROP PACKAGE PA_CLIENTE;
DROP PACKAGE PA_DOMICILIARIO;
DROP PACKAGE PA_FARMACEUTICO;
DROP PACKAGE PA_CONTADOR;
DROP PACKAGE PA_ADMINISTRADOR;
-------------
/*XCRUD*/
DROP PACKAGE PC_FARMACIAS;
DROP PACKAGE PC_PEDIDOS;
DROP PACKAGE PC_USUARIOS;
DROP PACKAGE PC_UBICACIONES;
-------------
/*XDisparadores*/
DROP TRIGGER TG_ZONAS_BI;
DROP TRIGGER TG_BARRIOS_BI;
DROP TRIGGER TG_MEDICAMENTOS_BI;
DROP TRIGGER TG_RECETASMED_BI;
DROP TRIGGER TG_PEDIDOS_BI;
DROP TRIGGER TG_VENTAS_BI;
DROP TRIGGER TG_TELEFONOS_BI;
DROP TRIGGER TG_USUARIOS_BU;
DROP TRIGGER TG_FARMACIAS_BU;
-------------
/*XPoblar*/
DELETE FROM telefonos ;
DELETE FROM barrios;
DELETE FROM vehiculos;
DELETE FROM recetasMedicas;
DELETE FROM pedidos;
DELETE FROM clientes;
DELETE FROM domiciliarios;
DELETE FROM usuarios;
DELETE FROM medicamentos;
DELETE FROM farmacias;
DELETE FROM zonas;
DELETE FROM ubicaciones;
DELETE FROM zonaXDomiciliaro;
-------------
/*XTablas*/
DROP TABLE telefonos CASCADE CONSTRAINTS PURGE;
DROP TABLE barrios CASCADE CONSTRAINTS PURGE;
DROP TABLE vehiculos CASCADE CONSTRAINTS PURGE;
DROP TABLE recetasMedicas CASCADE CONSTRAINTS PURGE;
DROP TABLE pedidos CASCADE CONSTRAINTS PURGE;
DROP TABLE clientes CASCADE CONSTRAINTS PURGE;
DROP TABLE domiciliarios CASCADE CONSTRAINTS PURGE;
DROP TABLE usuarios CASCADE CONSTRAINTS PURGE;
DROP TABLE medicamentos CASCADE CONSTRAINTS PURGE;
DROP TABLE farmacias CASCADE CONSTRAINTS PURGE;
DROP TABLE zonas CASCADE CONSTRAINTS PURGE;
DROP TABLE ubicaciones CASCADE CONSTRAINTS PURGE;
DROP TABLE zonaXDomiciliario CASCADE CONSTRAINTS PURGE;