/*CRUDE*/
CREATE OR REPLACE PACKAGE PC_FARMACIAS IS
    PROCEDURE add_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER);
    PROCEDURE mod_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR);
    FUNCTION co_medicamento (xNombre IN VARCHAR)  RETURN SYS_REFCURSOR;
    PROCEDURE el_medicamento (xIdMedicamento IN VARCHAR);
    FUNCTION co_farmacias RETURN SYS_REFCURSOR;
    FUNCTION co_ubicacionFarm (xNit IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_medicamentos (xNit IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_socios RETURN SYS_REFCURSOR;
END; 
---
CREATE OR REPLACE PACKAGE PC_PEDIDOS IS
    PROCEDURE adicionar (xIdPedido IN NUMBER, xFechaYHoraEntrega IN DATE, xEstado IN VARCHAR, xDomiciliario IN NUMBER, xCliente IN NUMBER, xNoFactura IN NUMBER, xHoraVenta IN DATE, xPrecio IN NUMBER, xTipoPago IN VARCHAR);
    PROCEDURE mo_estadoCliente (xIdPedido IN NUMBER, xEstado IN VARCHAR);
    PROCEDURE mo_entregaYEstado (xIdPedido IN NUMBER, xEstado IN VARCHAR);
    FUNCTION co_pedido (xIdPedido IN NUMBER)  RETURN SYS_REFCURSOR;
    FUNCTION co_pedidos_ganancia RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PC_USUARIOS IS
    PROCEDURE adicionar (xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xLicencia IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE mod_nombre (xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mod_telefono (xCedula IN NUMBER, xTelefono IN NUMBER);
    PROCEDURE eliminar (xCedula IN NUMBER);
    FUNCTION co_usuario (xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_catidadPedidos RETURN SYS_REFCURSOR;
    PROCEDURE add_vehiculo (xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE mod_vehiculo (xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE el_vehiculo (xPlaca IN VARCHAR);
    FUNCTION co_vehiculo (xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_ubicacion_cliente (xCedula IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PC_UBICACIONES IS 
    PROCEDURE adicionar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE modificar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    FUNCTION co_ubicacion (xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
END;
