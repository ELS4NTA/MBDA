/*CRUDI*/
CREATE OR REPLACE PACKAGE BODY PC_FARMACIAS IS
    PROCEDURE add_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER)
    IS
    BEGIN
        INSERT INTO medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit) 
        VALUES (xIdMedicamento, xLaboratorio, xNombre, xDescripcion, xElaboracion, xVencimiento, xNitFarmacia);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede insertar el medicamento.');
    END;
    --
    PROCEDURE mod_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR)
    IS
    BEGIN
        UPDATE medicamentos SET laboratorio = xLaboratorio, nombre = xNombre, descripcion = xDescripcion  WHERE idMedicamento = xIdMedicamento;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede actualizar el medicamento.');
    END;
    --
    FUNCTION co_medicamento (xNombre IN VARCHAR)  RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
    OPEN co_medicamento FOR
		SELECT * FROM VMedicamentos WHERE nombre = xNombre;
	RETURN co_medicamento;
    END;
    --
    PROCEDURE el_medicamento (xIdMedicamento IN VARCHAR)
    IS
    BEGIN
        DELETE FROM medicamentos WHERE idMedicamento = xIdMedicamento;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20005, 'No se puede eliminar el medicamento.');
    END;
    --
    FUNCTION co_farmacias RETURN SYS_REFCURSOR IS co_farmacias SYS_REFCURSOR;
    BEGIN
    OPEN co_farmacias FOR
		SELECT nit, sucursal FROM farmacias;
	RETURN co_farmacias;
    END;
    FUNCTION co_ubicacionFarm (xNit IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacionFarm SYS_REFCURSOR;
    BEGIN
    OPEN co_ubicacionFarm FOR
		SELECT * FROM vubicacionesfarm WHERE nit = xNit;
	RETURN co_ubicacionFarm;
    END;
    FUNCTION co_medicamentos (xNit IN NUMBER) RETURN SYS_REFCURSOR IS co_medicamentos SYS_REFCURSOR;
    BEGIN
    OPEN co_medicamentos FOR
        SELECT * FROM VMedicamentos WHERE farmacia_nit = xNit;
    RETURN co_medicamentos;
    END;
    FUNCTION co_socios RETURN SYS_REFCURSOR IS co_socios SYS_REFCURSOR;
    BEGIN
    OPEN co_socios FOR
        SELECT * FROM VFarmacias;
    RETURN co_socios;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_PEDIDOS IS
    PROCEDURE adicionar (xIdPedido IN NUMBER, xFechaYHoraEntrega IN DATE, xEstado IN VARCHAR, xDomiciliario IN NUMBER, xCliente IN NUMBER, xNoFactura IN NUMBER, xHoraVenta IN DATE, xPrecio IN NUMBER, xTipoPago IN VARCHAR)
    IS
    BEGIN
        INSERT INTO pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago)
        VALUES (xIdPedido, xFechaYHoraEntrega, xEstado, xDomiciliario, xCliente, xNoFactura, xHoraVenta, xPrecio, xTipoPago);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20006, 'No se puede insertar el pedido.');
    END;
    --
    PROCEDURE mo_estadoCliente (xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        UPDATE pedidos SET estado = xEstado WHERE idPedido = xIdPedido;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede actualizar el estado del pedido.');
    END;
    --
    PROCEDURE mo_entregaYEstado (xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        IF (xEstado != 'Entregado') THEN
            RAISE_APPLICATION_ERROR(-20008, 'Estado de entrega incorrecto.');
        END IF;
        UPDATE pedidos SET estado = xEstado  WHERE idPedido = xIdPedido; -- hacer disparador para fecha y hora de entrega
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20999, SQLERRM);
    END;
    --
    FUNCTION co_pedido (xIdPedido IN NUMBER)  RETURN SYS_REFCURSOR IS co_pedido SYS_REFCURSOR;
    BEGIN
    OPEN co_pedido FOR
		SELECT * FROM pedidos WHERE idPedido = xIdPedido;
	RETURN co_pedido;
    END;
    --
    FUNCTION co_pedidos_ganancia RETURN SYS_REFCURSOR IS co_entregados SYS_REFCURSOR;
    BEGIN
    OPEN co_entregados FOR
		SELECT * FROM VPedidosCont;
	RETURN co_entregados;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_USUARIOS IS
    PROCEDURE adicionar (xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xLicencia IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        INSERT INTO usuarios (cedula, nombre, telefono)
        VALUES (xCedula, xNombre, xTelefono);
        IF (xCorreo != NULL) THEN
            INSERT INTO clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) VALUES (xCedula, xCorreo, xCalle, xCarrera);
        END IF;
        IF (xLicencia != NULL) THEN
            INSERT INTO domiciliarios (usuario_cedula, licencia) VALUES (xCedula, xLicencia);
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20009, 'No se puede insertar el usuario.');
    END;
    --
    PROCEDURE mod_nombre (xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        UPDATE usuarios SET nombre = xNombre WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'No se puede actualizar el nombre del usuario.');
    END;
    --
    PROCEDURE mod_telefono (xCedula IN NUMBER, xTelefono IN NUMBER)
    IS
    BEGIN
        UPDATE usuarios SET telefono = xTelefono WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede actualizar el telefono del usuario.');
    END;
    --
    PROCEDURE eliminar (xCedula IN NUMBER)
    IS
    BEGIN
        DELETE FROM usuarios WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede eliminar el usuario.');
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
    OPEN co_usuario FOR
		SELECT * FROM usuarios WHERE cedula = xCedula;
	RETURN co_usuario;
    END;
    --
    FUNCTION co_catidadPedidos RETURN SYS_REFCURSOR IS co_cantidadPedidos SYS_REFCURSOR;
    BEGIN
    OPEN co_cantidadPedidos FOR
		SELECT * FROM VPedidosClient;
	RETURN co_cantidadPedidos;
    END;
    --
    PROCEDURE add_vehiculo (xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        INSERT INTO vehiculos (placa, tipoVehiculo, domiciliario_cedula) VALUES (xPlaca, xTipo, xCedula);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede insertar el vehiculo.');
    END;
    --
    PROCEDURE mod_vehiculo (xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        UPDATE vehiculos SET tipoVehiculo = xTipo WHERE placa = xPlaca;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede actualizar el vehiculo.');
    END;
    --
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR)
    IS
    BEGIN
        DELETE FROM vehiculos WHERE placa = xPlaca;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20011, 'No se puede eliminar el vehiculo.');
    END;
    --
    FUNCTION co_vehiculo (xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_vehiculo SYS_REFCURSOR;
    BEGIN
    OPEN co_vehiculo FOR
		SELECT * FROM vehiculos WHERE domiciliario_cedula = xCedula;
        RETURN co_vehiculo;
    END;
    FUNCTION co_ubicacion_cliente (xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion_cliente SYS_REFCURSOR;
    BEGIN
    OPEN co_ubicacion_cliente FOR
        SELECT * FROM VUbicacionesClient WHERE usuario_cedula = xCedula;
        RETURN co_ubicacion_cliente;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_UBICACIONES IS 
    PROCEDURE adicionar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        INSERT INTO ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id)
        VALUES (xCalle, xCarrera, xTorre, xApto, xManz, xLocal, xZona);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'No se puede insertar la ubicacion.');
    END;
    --
    PROCEDURE modificar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        UPDATE ubicaciones SET calle=xCalle, carrera=xCarrera, torre=xTorre, apartamento=xApto, manzana=xManz, localUbi = xLocal, zona_id = xZona WHERE calle = xCalle AND carrera = xCarrera;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'No se puede actualizar la ubicacion.');
    END;
    --
    FUNCTION co_ubicacion (xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
    OPEN co_ubicacion FOR
        SELECT * FROM ubicaciones WHERE (calle = xCalle AND carrera = xCarrera);
	RETURN co_ubicacion;
    END;
END;
