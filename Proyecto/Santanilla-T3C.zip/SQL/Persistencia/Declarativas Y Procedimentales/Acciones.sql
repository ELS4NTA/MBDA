/*ACCIONES*/
ALTER TABLE domiciliarios DROP CONSTRAINT FK_domiciliarios_usuarios;
ALTER TABLE clientes DROP CONSTRAINT FK_clientes_usuarios;
ALTER TABLE vehiculos DROP CONSTRAINT FK_vehiculos_domiciliarios;
ALTER TABLE telefonos DROP CONSTRAINT FK_telefonos_farmacias;
ALTER TABLE barrios DROP CONSTRAINT FK_barrios_zonas;
ALTER TABLE clientes DROP CONSTRAINT FK_clientes_ubicaciones;
ALTER TABLE recetasMedicas DROP CONSTRAINT FK_recetasMedicas_medicamentos;
ALTER TABLE pedidos DROP CONSTRAINT FK_pedidos_domiciliarios;
ALTER TABLE pedidos DROP CONSTRAINT FK_pedidos_clientes;
ALTER TABLE zonaXDomiciliario DROP CONSTRAINT FK_zonaXDomi_domiciliaros;
ALTER TABLE recetasMedicas DROP CONSTRAINT FK_recetasMedicas_pedidos;

ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula) ON DELETE CASCADE;
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula) ON DELETE SET NULL;
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_clientes FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula) ON DELETE CASCADE;
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(idPedido) ON DELETE CASCADE;
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT FK_zonaXDomi_domiciliaros FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula) ON DELETE CASCADE;
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula) ON DELETE CASCADE;
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula) ON DELETE CASCADE;
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit) ON DELETE SET NULL;
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona) ON DELETE SET NULL;
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_medicamentos FOREIGN KEY (medicamento_id) REFERENCES medicamentos(idMedicamento) ON DELETE SET NULL;
