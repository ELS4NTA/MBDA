/*DISPARADORES*/
DROP SEQUENCE zonas_seq;
DROP SEQUENCE barrios_seq;
DROP SEQUENCE medicamentos_seq;
DROP SEQUENCE recetasMed_seq;
DROP SEQUENCE pedidos_seq;
DROP SEQUENCE telefonos_seq;
DROP SEQUENCE ventas_seq;
CREATE SEQUENCE zonas_seq START WITH 1; --Se va a automatizar idZona
CREATE SEQUENCE barrios_seq START WITH 1; -- Se va a automatizar idBarrio
CREATE SEQUENCE medicamentos_seq START WITH 1; -- Se va a automatizar idMedicamento
CREATE SEQUENCE recetasMed_seq START WITH 1; -- Se va a automatizar idReceta
CREATE SEQUENCE pedidos_seq START WITH 1; -- Se va a automatizar idPedido
CREATE SEQUENCE telefonos_seq START WITH 1; -- Se va a automatizar idTelefono
CREATE SEQUENCE ventas_seq START WITH 1; -- Se va a automatizar noFactura
/*BI*/
CREATE OR REPLACE TRIGGER TG_ZONAS_BI
BEFORE INSERT ON zonas
FOR EACH ROW
BEGIN
    SELECT zonas_seq.NEXTVAL INTO :new.idZona FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_BARRIOS_BI
BEFORE INSERT ON barrios
FOR EACH ROW
BEGIN
    SELECT barrios_seq.NEXTVAL INTO :new.idBarrio FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_MEDICAMENTOS_BI
BEFORE INSERT ON medicamentos
FOR EACH ROW
BEGIN
    IF (:new.fechaElaboracion > :new.fechaVencimiento) THEN
        raise_application_error(-20001,'No se puede tener una fecha de fabricacion mayor a la de venecimiento.'); 
    END IF;
    SELECT medicamentos_seq.NEXTVAL INTO :new.idMedicamento FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_RECETASMED_BI
BEFORE INSERT ON recetasMedicas
FOR EACH ROW
BEGIN
    SELECT recetasMed_seq.NEXTVAL INTO :new.idRecetaM FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_PEDIDOS_BI
BEFORE INSERT ON pedidos
FOR EACH ROW
BEGIN
    SELECT TO_CHAR(sysdate, 'HH24:MI:SS') INTO :new.horaVenta FROM dual;
    SELECT pedidos_seq.NEXTVAL INTO :new.idPedido FROM dual;
    SELECT LPAD(ventas_seq.NEXTVAL,6,0) INTO :new.noFactura FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_TELEFONOS_BI
BEFORE INSERT ON telefonos
FOR EACH ROW
BEGIN
    SELECT telefonos_seq.NEXTVAL INTO :new.idTelefono FROM dual;
END;
/*BU*/
CREATE OR REPLACE TRIGGER TG_USUARIOS_BU
BEFORE UPDATE ON usuarios
FOR EACH ROW
BEGIN
    IF (:new.cedula != :old.cedula) THEN 
        raise_application_error(-20002,'No se puede actualizar el numero de cedula.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_FARMACIAS_BU
BEFORE UPDATE ON farmacias
FOR EACH ROW
BEGIN
    IF (:new.nit != :old.nit) THEN 
        raise_application_error(-20003,'No se puede actualizar el nit.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_MEDICAMENTOS_BU
BEFORE UPDATE ON medicamentos
FOR EACH ROW
BEGIN
    IF (:new.fechaElaboracion != :old.fechaElaboracion OR :new.fechaVencimiento != :old.fechaVencimiento) THEN 
        raise_application_error(-20004,'No se puede actualizar el medicamento.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_PEDIDOS_BU
BEFORE UPDATE ON pedidos
FOR EACH ROW
DECLARE
    fechaActual DATE;
BEGIN
    IF (:new.estado = 'Entregado') THEN
        SELECT SYSDATE INTO fechaActual FROM dual;
        UPDATE pedidos SET fechaYHoraEntrega = fechaActual;
    END IF;
    UPDATE pedidos SET estado = :new.estado;
END;
