/*TUPLAS*/
ALTER TABLE clientes ADD CONSTRAINT CK_clientes_correo CHECK (REGEXP_LIKE(correo, '(.+)\@(.+)\.(.+)'));
ALTER TABLE domiciliarios ADD CONSTRAINT CK_domiciliarios_licencia CHECK (licencia IN ('Valida', 'Invalida'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_placa CHECK (REGEXP_LIKE(placa, '[A-Z]{3}\d{3}'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_tipoVehiculo CHECK (tipoVehiculo IN ('Bici', 'Carro', 'Moto'));
ALTER TABLE pedidos ADD CONSTRAINT CK_pedidos_estado CHECK (estado IN ('Entregado', 'Cancelado', 'Enviado'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_tipoPago CHECK (tipoPago IN ('PSE', 'EFECTIVO', 'TARJETA'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_precio CHECK (REGEXP_LIKE(precio, '(\$)[0-9]{1,7}(\.)[0-9]{1,3}'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_horaVenta CHECK (REGEXP_LIKE(horaVenta, '[0-9]{0,2}(\:)[0-9]{0,2}(\:)[0-9]{0,2}'));
