/*Primarias*/
ALTER TABLE ubicaciones ADD CONSTRAINT PK_calle_carrera PRIMARY KEY (calle, carrera);
ALTER TABLE telefonos ADD CONSTRAINT PK_numero PRIMARY KEY (idTelefono);
ALTER TABLE farmacias ADD CONSTRAINT PK_nit PRIMARY KEY (nit);
ALTER TABLE medicamentos ADD CONSTRAINT PK_medicamentosID PRIMARY KEY (idMedicamento);
ALTER TABLE recetasMedicas ADD CONSTRAINT PK_RMI PRIMARY KEY (idRecetaM);
ALTER TABLE clientes ADD CONSTRAINT PK_cliente_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT PK_pedidoId PRIMARY KEY (idPedido);
ALTER TABLE usuarios ADD CONSTRAINT PK_cedula PRIMARY KEY (cedula);
ALTER TABLE zonas ADD CONSTRAINT PK_zonaId PRIMARY KEY (idZona);
ALTER TABLE barrios ADD CONSTRAINT PK_BI PRIMARY KEY (idBarrio);
ALTER TABLE domiciliarios ADD CONSTRAINT PK_domiciliario_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE vehiculos ADD CONSTRAINT PK_placa PRIMARY KEY (placa);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT PK_domiciliariosCedula_zonasId PRIMARY KEY (domiciliario_cedula, zona_id);
/*Unicas*/
ALTER TABLE usuarios ADD CONSTRAINT UK_telefono UNIQUE (telefono);
ALTER TABLE clientes ADD CONSTRAINT UK_correo UNIQUE (correo);
/*Foraneas*/
ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE medicamentos ADD CONSTRAINT FK_medicamentos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE ubicaciones ADD CONSTRAINT FK_ubicaciones_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_medicamentos FOREIGN KEY (medicamento_id) REFERENCES medicamentos(idMedicamento);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(idPedido);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_clientes FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula);
ALTER TABLE farmacias ADD CONSTRAINT FK_farmacias_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT FK_zonaXDomi_domiciliaros FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE zonaXDomiciliario ADD CONSTRAINT FK_zonaXDomi_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
