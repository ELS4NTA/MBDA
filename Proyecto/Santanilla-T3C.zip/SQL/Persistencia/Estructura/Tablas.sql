/*ESTRUCTURA*/
/*TABLAS*/
CREATE TABLE usuarios(
    cedula NUMBER NOT NULL, 
    nombre VARCHAR(70) NOT NULL, 
    telefono NUMBER NOT NULL
);
CREATE TABLE domiciliarios(
    usuario_cedula NUMBER NOT NULL, 
    licencia VARCHAR(70) NOT NULL
);
CREATE TABLE vehiculos(
    placa VARCHAR(50) NOT NULL, 
    tipoVehiculo VARCHAR(50) NOT NULL, 
    domiciliario_cedula NUMBER NOT NULL
);
CREATE TABLE zonas(
    idZona NUMBER(70) NOT NULL, 
    localidad VARCHAR(70) NOT NULL
);
CREATE TABLE barrios(
    idBarrio NUMBER NOT NULL, 
    barrio VARCHAR(70) NOT NULL, 
    zona_id NUMBER(20) NOT NULL
);
CREATE TABLE zonaXDomiciliario(
    domiciliario_cedula NUMBER NOT NULL, 
    zona_id NUMBER(20) NOT NULL, 
    fechaAsignacion DATE
);
CREATE TABLE ubicaciones(
    calle NUMBER(3) NOT NULL, 
    carrera NUMBER(3) NOT NULL, 
    torre NUMBER(3), 
    apartamento NUMBER(5), 
    manzana NUMBER(3), 
    localUbi NUMBER(3), 
    zona_id NUMBER(20) NOT NULL
);
CREATE TABLE clientes(
    usuario_cedula NUMBER NOT NULL, 
    correo VARCHAR(70) NOT NULL, 
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE farmacias(
    nit NUMBER NOT NULL, 
    sucursal NUMBER(10),
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE telefonos(
    idTelefono NUMBER NOT NULL, 
    telefono  NUMBER(10) NOT NULL, 
    farmacia_nit  NUMBER NOT NULL
);
CREATE TABLE medicamentos(
    idMedicamento NUMBER NOT NULL, 
    laboratorio VARCHAR(70) NOT NULL, 
    nombre VARCHAR(70) NOT NULL, 
    descripcion VARCHAR(100) NOT NULL, 
    fechaElaboracion DATE NOT NULL, 
    fechaVencimiento DATE NOT NULL, 
    farmacia_nit NUMBER NOT NULL
);
CREATE TABLE recetasMedicas(
    idRecetaM NUMBER NOT NULL, 
    prescipcion VARCHAR(70) NOT NULL, 
    candidadMedicamento NUMBER NOT NULL, 
    medicamento_id NUMBER NOT NULL, 
    pedido_id NUMBER NOT NULL
);
CREATE TABLE pedidos(
    idPedido NUMBER NOT NULL, 
    fechaYHoraEntrega DATE, 
    estado VARCHAR(70) NOT NULL, 
    domiciliario_cedula NUMBER NOT NULL, 
    cliente_cedula NUMBER NOT NULL,
    noFactura NUMBER NOT NULL,
    horaVenta DATE NOT NULL,
    precio VARCHAR(70) NOT NULL,
    tipoPago VARCHAR(70) NOT NULL
);
