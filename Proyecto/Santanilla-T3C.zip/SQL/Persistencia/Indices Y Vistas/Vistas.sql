/*VISTAS*/
CREATE VIEW VPedidosCont AS SELECT tipoPago, precio FROM pedidos WHERE estado = 'Entregado';
CREATE VIEW VPedidosClient AS SELECT cliente_cedula, noFactura, estado, horaVenta, fechaYHoraEntrega FROM pedidos;
CREATE VIEW VClientes AS SELECT nombre, correo, count(idPedido) AS numPedidos FROM clientes 
JOIN pedidos ON (cliente_cedula = usuario_cedula)
JOIN usuarios ON (cedula = usuario_cedula) WHERE estado = 'Entregado'
GROUP BY nombre, correo ORDER BY numPedidos DESC;
CREATE VIEW VMedicamentos AS SELECT nombre, laboratorio, fechaElaboracion, fechaVencimiento, farmacia_nit FROM medicamentos;
CREATE VIEW VFarmacias AS SELECT nit, sucursal FROM farmacias;
CREATE VIEW VUbicacionesClient AS SELECT usuario_cedula, calle, carrera, torre, apartamento, manzana 
FROM clientes JOIN ubicaciones ON (calle = ubicacion_calle AND carrera = ubicacion_carrera);
CREATE VIEW VUbicacionesFarm AS SELECT nit, ubicacion_calle, ubicacion_carrera FROM farmacias;
