/*XIndicesVistas*/
DROP VIEW VPedidosCont;
DROP VIEW VPedidosClient;
DROP VIEW VClientes;
DROP VIEW VMedicamentos;
DROP VIEW VFarmacias;
DROP VIEW VUbicacionesClient;
DROP VIEW VUbicacionesFarm;
