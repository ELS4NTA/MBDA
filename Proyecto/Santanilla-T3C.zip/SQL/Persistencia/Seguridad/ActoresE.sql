/*ActoresE*/
CREATE OR REPLACE PACKAGE PA_CLIENTE IS
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR);
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE el_usuario(xCedula IN NUMBER);
    FUNCTION co_pedido(xIdPedido IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE mo_estadoPedido(xIdPedido IN NUMBER, xEstado IN VARCHAR);
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR;
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER);
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER);
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PA_DOMICILIARIO IS 
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xLicencia IN VARCHAR);
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR);
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE el_usuario(xCedula IN NUMBER);
    PROCEDURE ad_vehiculo(xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE mo_vehiculo(xPlaca IN VARCHAR, xTipo IN VARCHAR);
    FUNCTION co_vehiculo (xPlaca IN VARCHAR) RETURN SYS_REFCURSOR;
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR);
    PROCEDURE mo_entregaYEstado(xIdPedido IN NUMBER, xEstado IN VARCHAR);
    FUNCTION co_ubicaCliente(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_ubicaFarmacia (xNit IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PA_FARMACEUTICO IS
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
    PROCEDURE ad_pedido(xDomiciliario IN NUMBER, xCliente IN NUMBER, xPrecio IN NUMBER, xTipoPago IN VARCHAR);
    PROCEDURE ad_medicamento(xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER);
    PROCEDURE mo_medicamento(xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR);
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR;
    PROCEDURE el_medicamento(xIdMedicamento IN VARCHAR);
END;
---
CREATE OR REPLACE PACKAGE PA_CONTADOR IS

    FUNCTION co_pedidoEntregados RETURN SYS_REFCURSOR;
    
END;
---
CREATE OR REPLACE PACKAGE PA_ADMINISTRADOR IS
    FUNCTION co_usuarios RETURN SYS_REFCURSOR;
    FUNCTION co_farmacias RETURN SYS_REFCURSOR;
END;
