/*ActoresI*/
CREATE OR REPLACE PACKAGE BODY PA_CLIENTE IS
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.adicionar(xCedula, xNombre, xTelefono, xCorreo, NULL, xCalle, xCarrera);
    END;
    --
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_nombre(xCedula, xNombre);
    END;
    --
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_telefono(xCedula, xTelefono);
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
        co_usuario := PC_USUARIOS.co_usuario(xCedula);
        RETURN co_usuario;
	END;
    --
    PROCEDURE el_usuario(xCedula IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.eliminar(xCedula);
    END;
    --
    FUNCTION co_pedido(xIdPedido IN NUMBER) RETURN SYS_REFCURSOR IS co_pedido SYS_REFCURSOR;
    BEGIN
        co_pedido := PC_PEDIDOS.co_pedido(xIdPedido);
        RETURN co_pedido;
	END;
    --
    PROCEDURE mo_estadoPedido(xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.mo_estadoCliente(xIdPedido, xEstado);
    END;
    --
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
        co_medicamento := PC_FARMACIAS.co_medicamento(xNombre);
        RETURN co_medicamento;
	END;
    --
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.adicionar(xCalle, xCarrera, xTorre, xApto, xManz, NULL, xZona);
    END;
    --
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.modificar(xCalle, xCarrera, xTorre, xApto, xManz, NULL, xZona);
    END;
    --
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
        co_ubicacion := PC_UBICACIONES.co_ubicacion(xCalle, xCarrera);
        RETURN co_ubicacion;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_DOMICILIARIO IS 
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xLicencia IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.adicionar(xCedula, xNombre, xTelefono, NULL, xLicencia, NULL, NULL);
    END;
    --
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_nombre(xCedula, xNombre);
    END;
    --
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_telefono(xCedula, xTelefono);
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
        co_usuario := PC_USUARIOS.co_usuario(xCedula);
        RETURN co_usuario;
	END;
    --
    PROCEDURE el_usuario(xCedula IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.eliminar(xCedula);
    END;
    --
    PROCEDURE ad_vehiculo(xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.add_vehiculo(xCedula, xPlaca, xTipo);
    END;
    --
    PROCEDURE mo_vehiculo(xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_vehiculo(xPlaca, xTipo);
    END;
    --
    FUNCTION co_vehiculo (xPlaca IN VARCHAR) RETURN SYS_REFCURSOR IS co_vehiculo SYS_REFCURSOR;
    BEGIN
        co_vehiculo := PC_USUARIOS.co_vehiculo(xPlaca);
        RETURN co_vehiculo;
    END;
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.el_vehiculo(xPlaca);
    END;
    --
    PROCEDURE mo_entregaYEstado(xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.mo_entregaYEstado(xIdPedido, xEstado);
    END;
    --
    FUNCTION co_ubicaCliente(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicaCliente SYS_REFCURSOR;
    BEGIN
        co_ubicaCliente := PC_USUARIOS.co_ubicacion_cliente(xCedula);
        RETURN co_ubicaCliente;
	END;
    --
    FUNCTION co_ubicaFarmacia (xNit IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicaFarmacia SYS_REFCURSOR;
    BEGIN
        co_ubicaFarmacia := PC_FARMACIAS.co_ubicacionFarm(xNit);
        RETURN co_ubicaFarmacia;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_FARMACEUTICO IS
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.adicionar(xCalle, xCarrera, NULL, NULL, NULL, xLocal, xZona);
    END;
    --
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.modificar(xCalle, xCarrera, NULL, NULL, NULL, xLocal, xZona);
    END;
    --
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
        co_ubicacion :=  PC_UBICACIONES.co_ubicacion(xCalle, xCarrera);
        RETURN co_ubicacion;
	END;
    --
    PROCEDURE ad_pedido(xDomiciliario IN NUMBER, xCliente IN NUMBER, xPrecio IN NUMBER, xTipoPago IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.adicionar(0, NULL, 'Enviado', xDomiciliario, xCliente, 0, '00:00:00', xPrecio, xTipoPago);
    END;
    --
    PROCEDURE ad_medicamento(xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER)
    IS
    BEGIN
        PC_FARMACIAS.add_medicamento(0, xLaboratorio, xNombre, xDescripcion, xElaboracion, xVencimiento, xNitFarmacia);
    END;
    --
    PROCEDURE mo_medicamento(xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR)
    IS
    BEGIN
        PC_FARMACIAS.mod_medicamento (xIdMedicamento, xLaboratorio, xNombre, xDescripcion);
    END;
    --
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
        co_medicamento :=  PC_FARMACIAS.co_medicamento(xNombre);
        RETURN co_medicamento;
	END;
    --
    PROCEDURE el_medicamento(xIdMedicamento IN VARCHAR)
    IS
    BEGIN
        PC_FARMACIAS.el_medicamento(xIdMedicamento);
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_CONTADOR IS
    FUNCTION co_pedidoEntregados RETURN SYS_REFCURSOR IS co_pedidoEntregados SYS_REFCURSOR;
    BEGIN
        co_pedidoEntregados :=  PC_PEDIDOS.co_pedidos_ganancia;
        RETURN co_pedidoEntregados;
	END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_ADMINISTRADOR IS
    FUNCTION co_usuarios RETURN SYS_REFCURSOR IS co_usuarios SYS_REFCURSOR;
    BEGIN
        co_usuarios :=  PC_USUARIOS.co_catidadPedidos;
        RETURN co_usuarios;
	END;
    --
    FUNCTION co_farmacias RETURN SYS_REFCURSOR IS co_farmacias SYS_REFCURSOR;
    BEGIN
        co_farmacias :=  PC_FARMACIAS.co_socios;
        RETURN co_farmacias;
	END;
END;
