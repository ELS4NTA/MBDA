/*Seguridad*/
CREATE ROLE cliente;
CREATE ROLE domiciliario;
CREATE ROLE farmaceutico;
CREATE ROLE administrador;
CREATE ROLE contador;

GRANT INSERT, SELECT, UPDATE, DELETE ON usuarios TO cliente;
GRANT SELECT ON pedidos TO cliente;
GRANT SELECT ON medicamentos TO cliente;
GRANT INSERT, SELECT, UPDATE, DELETE ON ubicaciones TO cliente;
GRANT INSERT, SELECT, UPDATE, DELETE ON vehiculos TO domiciliario;
GRANT SELECT, UPDATE ON pedidos TO domiciliario;
GRANT SELECT ON ubicaciones TO domiciliario;
GRANT INSERT, SELECT, UPDATE, DELETE ON ubicaciones TO farmaceutico;
GRANT INSERT, SELECT ON pedidos TO farmaceutico;
GRANT INSERT, SELECT, UPDATE, DELETE ON medicamentos TO farmaceutico;
GRANT SELECT ON pedidos TO contador;
GRANT SELECT ON usuarios TO administrador;
GRANT SELECT ON farmacias TO administrador;
