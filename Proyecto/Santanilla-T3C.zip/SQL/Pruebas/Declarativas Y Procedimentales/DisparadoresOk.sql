/*DisparadoresOk*/
/*Para realizar las pruebas con insercion automatica (en caso de que aun no este
poblada la tabla) de deben reiniciar las secuencias (DROP-CREATE)
Las pruebas a realizar comienzan en:
INSERT linea 21
UPDATE o DELETE linea 256*/
DROP SEQUENCE zonas_seq;
DROP SEQUENCE barrios_seq;
DROP SEQUENCE medicamentos_seq;
DROP SEQUENCE recetasMed_seq;
DROP SEQUENCE pedidos_seq;
DROP SEQUENCE telefonos_seq;
DROP SEQUENCE ventas_seq;
CREATE SEQUENCE zonas_seq START WITH 1; --Se va a automatizar idZona
CREATE SEQUENCE barrios_seq START WITH 1; -- Se va a automatizar idBarrio
CREATE SEQUENCE medicamentos_seq START WITH 1; -- Se va a automatizar idMedicamento
CREATE SEQUENCE recetasMed_seq START WITH 1; -- Se va a automatizar idReceta
CREATE SEQUENCE pedidos_seq START WITH 1; -- Se va a automatizar idPedido
CREATE SEQUENCE telefonos_seq START WITH 1; -- Se va a automatizar idTelefono
CREATE SEQUENCE ventas_seq START WITH 1; -- Se va a automatizar noFactura
/*INSERT*/
/*zonas*/
insert into zonas (idZona, localidad) values (1, 'Terrace');
insert into zonas (idZona, localidad) values (2, 'Drive');
insert into zonas (idZona, localidad) values (3, 'Circle');
insert into zonas (idZona, localidad) values (4, 'Place');
insert into zonas (idZona, localidad) values (5, 'Junction');
insert into zonas (idZona, localidad) values (6, 'Place');
insert into zonas (idZona, localidad) values (7, 'Point');
insert into zonas (idZona, localidad) values (8, 'Point');
insert into zonas (idZona, localidad) values (9, 'Trail');
insert into zonas (idZona, localidad) values (10, 'Way');
insert into zonas (idZona, localidad) values (11, 'Place');
insert into zonas (idZona, localidad) values (12, 'Alley');
insert into zonas (idZona, localidad) values (13, 'Center');
insert into zonas (idZona, localidad) values (14, 'Drive');
insert into zonas (idZona, localidad) values (15, 'Point');
insert into zonas (idZona, localidad) values (16, 'Point');
insert into zonas (idZona, localidad) values (17, 'Junction');
insert into zonas (idZona, localidad) values (18, 'Plaza');
insert into zonas (idZona, localidad) values (19, 'Junction');
insert into zonas (idZona, localidad) values (20, 'Pass');
/*barrios*/
insert into barrios (idBarrio, barrio, zona_id) values (1, 'Sundown', 5);
insert into barrios (idBarrio, barrio, zona_id) values (2, 'Waubesa', 18);
insert into barrios (idBarrio, barrio, zona_id) values (3, 'Merchant', 4);
insert into barrios (idBarrio, barrio, zona_id) values (4, 'Oakridge', 20);
insert into barrios (idBarrio, barrio, zona_id) values (5, 'Brentwood', 4);
insert into barrios (idBarrio, barrio, zona_id) values (6, 'Melvin', 6);
insert into barrios (idBarrio, barrio, zona_id) values (7, 'Chive', 8);
insert into barrios (idBarrio, barrio, zona_id) values (8, 'Orin', 20);
insert into barrios (idBarrio, barrio, zona_id) values (9, 'Memorial', 6);
insert into barrios (idBarrio, barrio, zona_id) values (10, 'Merrick', 17);
insert into barrios (idBarrio, barrio, zona_id) values (11, 'West', 1);
insert into barrios (idBarrio, barrio, zona_id) values (12, 'Corscot', 5);
insert into barrios (idBarrio, barrio, zona_id) values (13, 'Brickson Park', 12);
insert into barrios (idBarrio, barrio, zona_id) values (14, 'Straubel', 11);
insert into barrios (idBarrio, barrio, zona_id) values (15, 'Merchant', 19);
insert into barrios (idBarrio, barrio, zona_id) values (16, 'Monica', 13);
insert into barrios (idBarrio, barrio, zona_id) values (17, 'Michigan', 2);
insert into barrios (idBarrio, barrio, zona_id) values (18, 'Mcbride', 2);
insert into barrios (idBarrio, barrio, zona_id) values (19, 'Basil', 7);
insert into barrios (idBarrio, barrio, zona_id) values (20, 'Mcbride', 9);
/*usuarios*/
insert into usuarios (cedula, nombre, telefono) values (449468454, 'Raoul Berthel', 3699617149);
insert into usuarios (cedula, nombre, telefono) values (101478125, 'Ronda Renowden', 8726031324);
insert into usuarios (cedula, nombre, telefono) values (553549636, 'Star Gutowska', 2288866770);
insert into usuarios (cedula, nombre, telefono) values (299249364, 'Jorrie Colter', 4139167923);
insert into usuarios (cedula, nombre, telefono) values (412307344, 'Meriel MacKall', 4953529485);
insert into usuarios (cedula, nombre, telefono) values (136513856, 'Aleda Tonks', 1811339155);
insert into usuarios (cedula, nombre, telefono) values (102308786, 'Marketa Couvet', 7524892989);
insert into usuarios (cedula, nombre, telefono) values (119880457, 'Brook Twitchett', 6673078049);
insert into usuarios (cedula, nombre, telefono) values (520917692, 'Catherine Tidmarsh', 8936258972);
insert into usuarios (cedula, nombre, telefono) values (126651085, 'Richardo Elt', 6221514343);
insert into usuarios (cedula, nombre, telefono) values (332763490, 'Dorine De Laci', 8454968310);
insert into usuarios (cedula, nombre, telefono) values (398763896, 'Florentia Biers', 7682361221);
insert into usuarios (cedula, nombre, telefono) values (712841788, 'Maribel Gilkes', 9924846190);
insert into usuarios (cedula, nombre, telefono) values (249048265, 'Veronique Cholomin', 5543433505);
insert into usuarios (cedula, nombre, telefono) values (886868376, 'Art Streetley', 7113196055);
insert into usuarios (cedula, nombre, telefono) values (735686206, 'Rasla Shickle', 3674999571);
insert into usuarios (cedula, nombre, telefono) values (787885261, 'Tripp McArtan', 4338267864);
insert into usuarios (cedula, nombre, telefono) values (888860192, 'Tracy Fashion', 6938328824);
insert into usuarios (cedula, nombre, telefono) values (489102693, 'Phoebe Erridge', 1856639288);
insert into usuarios (cedula, nombre, telefono) values (514621827, 'Pippy Ledamun', 9928203245);
/*ubicaciones*/
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (132, 161, 27, 564, 18, 235, 14);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (39, 113, 19, 477, 1, 6, 7);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (35, 2, 19, 218, 12, 302, 17);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (53, 190, null, null, null, null, 7);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (25, 191, 4, 813, 9, 470, 15);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (66, 133, null, null, null, null, 13);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (89, 186, 23, 433, 1, 346, 20);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (130, 170, null, null, null, null, 16);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (178, 120, null, null, null, null, 20);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (26, 11, 27, 558, 6, 281, 1);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (133, 5, null, null, null, null, 18);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (57, 196, 13, 747, 8, 53, 15);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (111, 53, 1, 206, 16, 473, 20);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (144, 36, null, null, null, null, 4);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (77, 29, 29, 419, 1, 238, 13);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (180, 28, 2, 694, 2, 448, 15);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (94, 61, 7, 33, 4, 431, 7);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (95, 10, null, null, null, null, 17);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (8, 16, 19, 143, 15, 74, 7);
insert into ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id) values (135, 183, null, null, null, null, 10);
/*clientes*/
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (449468454, 'eoulett0@bbc.co.uk', 132, 161);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (101478125, 'gokie1@xinhuanet.com', 39, 113);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (553549636, 'esandwith2@ed.gov', 35, 2);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (299249364, 'sabdee3@collective.com', 53, 190);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (412307344, 'rgiral4@omniture.com', 25, 191);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (136513856, 'cbridge5@apple.com', 66, 133);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (102308786, 'asost6@google.es', 89, 186);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (119880457, 'adinley7@auda.org.au', 130, 170);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (520917692, 'tzzi8@dagondesign.com', 178, 120);
insert into clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) values (126651085, 'dmole9@salon.com', 26, 11);
/*domiciliarios*/
insert into domiciliarios (usuario_cedula, licencia) values (332763490, 'Valida');
insert into domiciliarios (usuario_cedula, licencia) values (398763896, 'Valida');
insert into domiciliarios (usuario_cedula, licencia) values (712841788, 'Invalida');
insert into domiciliarios (usuario_cedula, licencia) values (249048265, 'Invalida');
insert into domiciliarios (usuario_cedula, licencia) values (886868376, 'Valida');
insert into domiciliarios (usuario_cedula, licencia) values (735686206, 'Valida');
insert into domiciliarios (usuario_cedula, licencia) values (787885261, 'Valida');
insert into domiciliarios (usuario_cedula, licencia) values (888860192, 'Invalida');
insert into domiciliarios (usuario_cedula, licencia) values (489102693, 'Valida');
insert into domiciliarios (usuario_cedula, licencia) values (514621827, 'Invalida');
/*zonasActivas*/
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (332763490, 13, '01/09/2021');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (398763896, 1, '04/06/2021');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (712841788, 1, '05/01/2022');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (249048265, 18, '16/11/2021');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (886868376, 19, '27/02/2022');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (735686206, 6, '14/09/2021');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (787885261, 13, '17/09/2021');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (888860192, 16, '25/06/2021');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (489102693, 7, '05/08/2021');
insert into zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) values (514621827, 1, '26/09/2021');
/*vehiculos*/
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('XPF167', 'Moto', 332763490);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('QIA530', 'Bici', 332763490);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('DJN384', 'Moto', 398763896);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('DRW836', 'Carro', 398763896);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('QET999', 'Moto', 712841788);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('ARN392', 'Bici', 712841788);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('DQZ737', 'Bici', 249048265);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('SLN960', 'Carro', 249048265);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('UMF555', 'Moto', 886868376);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('MOB513', 'Moto', 886868376);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('DKF131', 'Carro', 735686206);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('YXM056', 'Moto', 735686206);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('PAJ347', 'Moto', 787885261);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('MWG125', 'Moto', 787885261);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('TAU796', 'Bici', 888860192);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('JAN844', 'Bici', 888860192);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('ADM049', 'Carro', 489102693);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('SOE897', 'Carro', 489102693);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('UKP581', 'Moto', 514621827);
insert into vehiculos (placa, tipoVehiculo, domiciliario_cedula) values ('UZY349', 'Moto', 514621827);
/*farmacias*/
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (579550003,'a', 2, 133, 5);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (30698453,'b', 9, 57, 196);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (37205781,'c', 6, 111, 53);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (42254287,'d', 1, 144, 36);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (438570208,'h', 4, 77, 29);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (42808405,'i', 7, 180, 28);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (49643105,'j', 9, 94, 61);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (582320532,'k', 1, 95, 10);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (76354106,'l', 5, 8, 16);
insert into farmacias (nit, nombre, sucursal, ubicacion_calle, ubicacion_carrera) values (548681119,'m', 7, 135, 183);
/*telefonos*/
insert into telefonos (idTelefono, telefono, farmacia_nit) values (1, '8248652325', 579550003);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (2, '4355242873', 579550003);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (3, '2111158909', 30698453);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (4, '4266449445', 30698453);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (5, '7725654575', 37205781);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (6, '5024430813', 37205781);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (7, '6374229369', 42254287);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (8, '5366086206', 42254287);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (9, '1205687167', 438570208);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (10, '7585255540', 438570208);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (11, '4831955926', 42808405);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (12, '5687202880', 42808405);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (13, '7639151319', 49643105);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (14, '6636194115', 49643105);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (15, '7989324134', 582320532);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (16, '3263404752', 582320532);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (17, '8986777589', 76354106);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (18, '4289133755', 76354106);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (19, '6697969797', 548681119);
insert into telefonos (idTelefono, telefono, farmacia_nit) values (20, '9525260377', 548681119);
/*pedidos*/
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (1, '15/02/2022', 'Enviado', 332763490, 449468454, 6759230661679731, '5:22:05', '$5952.05', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (2, '01/11/2021', 'Cancelado', 332763490, 449468454, 3535349759638033, '21:47:36', '$67498.47', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (3, '15/08/2021', 'Enviado', 398763896, 101478125, 3531801268552406, '19:56:18', '$54432.16', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (4, '20/01/2022', 'Cancelado', 398763896, 101478125, 3529309309763333, '3:53:40', '$99716.39', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (5, '09/02/2022', 'Entregado', 712841788, 553549636, 5002350378920033, '7:20:28', '$23857.04', 'EFECTIVO');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (6, '12/08/2021', 'Entregado', 712841788, 553549636, 3546111432843142, '19:22:38', '$44018.45', 'EFECTIVO');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (7, '09/03/2022', 'Enviado', 249048265, 299249364, 3534136266507590, '19:08:23', '$60945.97', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (8, '28/01/2022', 'Enviado', 249048265, 299249364, 3562836444725676, '2:14:03', '$43114.82', 'EFECTIVO');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (9, '08/06/2021', 'Enviado', 886868376, 412307344, 3580231994122847, '13:19:49', '$42799.92', 'PSE');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (10, '29/07/2021', 'Enviado', 886868376, 412307344, 4508455748547077, '13:33:12', '$77781.04', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (11, '30/03/2022', 'Cancelado', 735686206, 136513856, 4041594613614, '21:01:19', '$24795.46', 'PSE');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (12, '11/12/2021', 'Entregado', 735686206, 136513856, 3549215227410947, '17:40:50', '$29748.55', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (13, '27/01/2022', 'Enviado', 787885261, 102308786, 5105997113768428, '18:50:01', '$5076.50', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (14, '24/12/2021', 'Cancelado', 787885261, 102308786, 201675202850653, '9:53:06', '$22502.06', 'EFECTIVO');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (15, '05/03/2022', 'Cancelado', 888860192, 119880457, 4657496300719, '9:30:40', '$41622.64', 'EFECTIVO');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (16, '13/09/2021', 'Enviado', 888860192, 119880457, 3537009959489474, '18:36:57', '$64393.61', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (17, '08/08/2021', 'Entregado', 489102693, 520917692, 560223997246011556, '18:30:25', '$29800.94', 'PSE');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (18, '17/10/2021', 'Enviado', 489102693, 520917692, 5165055890010287, '23:04:47', '$65423.83', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (19, '05/03/2022', 'Enviado', 514621827, 126651085, 5108759719413735, '3:44:10', '$74898.38', 'TARJETA');
insert into pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago) values (20, '12/01/2022', 'Enviado', 514621827, 126651085, 30361425233673, '14:28:36', '$82414.46', 'TARJETA');
/*medicamentos*/
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (1, 'Mynte', 'Minoxidil', 'iaculis congue vivamus metus arcu adipiscing molestie hendrerit at', '11/11/2020', '28/05/2021', 579550003,1);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (2, 'LiveZ', 'riociguat', 'tincidunt lacus at velit vivamus vel nulla eget eros', '31/05/2020', '15/04/2022', 579550003,2);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (3, 'Tagtune', 'Anacardium orientale', 'nulla mollis molestie lorem quisque ut erat curabitur gravida nisi', '16/03/2021', '27/03/2022', 30698453,3);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (4, 'Fivechat', 'Disopyramide Phosphate', 'pretium quis lectus suspendisse potenti in', '29/10/2020', '12/08/2021', 30698453,4);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (5, 'Topdrive', 'TRICLOSAN', 'neque vestibulum eget vulputate ut ultrices vel augue', '05/04/2021', '31/08/2021', 37205781,5);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (6, 'Skiba', 'Terazosin Hydrochloride', 'sollicitudin vitae consectetuer eget rutrum at lorem integer tincidunt ante', '11/12/2020', '05/08/2021', 37205781,6);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (7, 'Mydeo', 'STRYCHNOS IGNATII SEED', 'id mauris vulputate elementum nullam varius', '09/11/2020', '21/11/2021', 42254287,7);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (8, 'Quatz', 'urea', 'augue vestibulum rutrum rutrum neque', '30/05/2020', '02/09/2021', 42254287,8);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (9, 'Riffpedia', 'Losartan Potassium', 'elementum pellentesque quisque porta volutpat erat quisque erat', '16/05/2020', '24/02/2022', 49643105,9);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (10, 'Aibox', 'GLYCERIN, DIMETHICONE', 'ligula in lacus curabitur at ipsum ac', '10/02/2021', '09/12/2021', 49643105,10);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (11, 'Flashpoint', 'penicillium', 'condimentum id luctus nec molestie sed justo pellentesque viverra pede', '29/12/2020', '06/08/2021', 582320532,11);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (12, 'Bubbletube', 'norethindrone', 'sapien iaculis congue vivamus metus', '23/04/2021', '01/02/2022', 582320532,12);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (13, 'Trilia', 'Digoxin', 'suscipit nulla elit ac nulla sed vel enim sit amet', '08/03/2021', '23/01/2022', 42808405,13);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (14, 'Fivechat', 'Trazodone Hydrochloride', 'nullam orci pede venenatis non sodales sed', '27/10/2020', '23/03/2022', 76354106,14);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (15, 'Twitterbridge', 'Acetaminophen', 'semper est quam pharetra magna ac', '28/08/2020', '26/08/2021', 76354106,15);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (16, 'Pixope', 'ENALAPRIL MALEATE', 'enim lorem ipsum dolor sit amet consectetuer', '27/06/2020', '06/06/2021', 548681119,16);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (17, 'Tazz', 'Bambusa Argentum', 'aliquam sit amet diam in magna bibendum imperdiet nullam', '23/12/2020', '06/03/2022', 548681119,17);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (18, 'Flipstorm', 'Camphor Menthol', 'ipsum praesent blandit lacinia erat vestibulum', '15/08/2020', '19/03/2022', 438570208,18);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (19, 'Jatri', 'Alcohol', 'sagittis dui vel nisl duis ac nibh', '12/06/2020', '02/10/2021', 438570208,19);
insert into medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit, pedido_id) values (20, 'Babbleset', 'alendronate sodium', 'ridiculus mus vivamus vestibulum sagittis sapien cum', '31/10/2020', '27/10/2021', 42808405,20);
/*recetasMedicas*/
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (1, 'sem fusce consequat nulla nisl nunc nisl', 18, 17, 449468454);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (2, 'eleifend pede libero quis orci nullam molestie', 60, 11, 101478125 );
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (3, 'a nibh in quis justo maecenas rhoncus aliquam', 30, 13, 553549636);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (4, 'in faucibus orci luctus et ultrices', 59, 10, 299249364);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (5, 'nulla quisque arcu libero rutrum ac', 22, 2, 412307344);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (6, 'amet sem fusce consequat nulla nisl nunc nisl', 39, 5, 136513856);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (7, 'sed nisl nunc rhoncus dui vel sem sed', 7, 10, 102308786);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (8, 'justo sollicitudin ut suscipit a feugiat et eros', 45, 10, 119880457);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (9, 'nec molestie sed justo pellentesque viverra', 38, 12, 520917692);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (10, 'eros viverra eget congue eget semper rutrum nulla', 59, 18, 126651085);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (11, 'orci pede venenatis non sodales', 19, 3, 449468454);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (12, 'sit amet erat nulla tempus vivamus in felis', 17, 15, 101478125);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (13, 'vel lectus in quam fringilla', 45, 10, 553549636);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (14, 'pede lobortis ligula sit amet', 4, 11, 299249364);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (15, 'eu est congue elementum in hac habitasse platea', 41, 5, 412307344);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (16, 'nulla tellus in sagittis dui', 2, 15, 136513856);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (17, 'id justo sit amet sapien dignissim vestibulum v', 28, 15, 102308786);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (18, 'quis turpis sed ante vivamus tortor duis mattis', 8, 1, 119880457);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (19, 'praesent blandit lacinia erat vestibulum sed ma', 24, 6, 520917692);
insert into recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula) values (20, 'gravida nisi at nibh in', 35, 4, 126651085);
 
/*UPDATE OR DELETE*/
UPDATE usuarios SET cedula = 0128391 WHERE cedula = 449468454;
UPDATE farmacias SET nit = 9735 WHERE nit = 579550003;
UPDATE medicamentos SET fechavencimiento = TO_DATE('12/08/2022','dd/mm/yyyy') WHERE idmedicamento = 4;
UPDATE medicamentos SET fechaElaboracion = TO_DATE('12/08/2022','dd/mm/yyyy') WHERE idmedicamento = 4;
