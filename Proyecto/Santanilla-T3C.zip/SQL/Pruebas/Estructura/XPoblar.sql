/*XPoblar*/
DELETE FROM recetasMedicas;
DELETE FROM pedidos;
DELETE FROM clientes;
DELETE FROM medicamentos;
DELETE FROM telefonos;
DELETE FROM farmacias;
DELETE FROM ubicaciones;
DELETE FROM barrios;
DELETE FROM zonaXDomiciliario;
DELETE FROM zonas;
DELETE FROM vehiculos;
DELETE FROM domiciliarios;
DELETE FROM usuarios;
