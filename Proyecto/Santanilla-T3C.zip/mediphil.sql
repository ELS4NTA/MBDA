/*ESTRUCTURA*/
/*TABLAS*/
CREATE TABLE usuarios(
    cedula NUMBER NOT NULL, 
    nombre VARCHAR(70) NOT NULL, 
    telefono NUMBER NOT NULL
);
CREATE TABLE domiciliarios(
    usuario_cedula NUMBER NOT NULL, 
    licencia VARCHAR(70) NOT NULL
);
CREATE TABLE vehiculos(
    placa VARCHAR(50) NOT NULL, 
    tipoVehiculo VARCHAR(50) NOT NULL, 
    domiciliario_cedula NUMBER NOT NULL
);
CREATE TABLE zonas(
    idZona NUMBER(20) NOT NULL, 
    localidad VARCHAR(70) NOT NULL
);
CREATE TABLE barrios(
    idBarrio NUMBER NOT NULL, 
    barrio VARCHAR(70) NOT NULL, 
    zona_id NUMBER(20) NOT NULL
);
CREATE TABLE zonasActivas(
    domiciliario_cedula NUMBER NOT NULL, 
    zona_id NUMBER(20) NOT NULL, 
    fechaAsignacion DATE
);
CREATE TABLE ubicaciones(
    calle NUMBER(3) NOT NULL, 
    carrera NUMBER(3) NOT NULL, 
    torre NUMBER(3), 
    apartamento NUMBER(5), 
    manzana NUMBER(3), 
    localUbi NUMBER(3), 
    zona_id NUMBER(20) NOT NULL
);
CREATE TABLE clientes(
    usuario_cedula NUMBER NOT NULL, 
    correo VARCHAR(70) NOT NULL, 
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE farmacias(
    nit NUMBER NOT NULL, 
    nombre VARCHAR(70) NOT NULL,
    sucursal NUMBER(10) NOT NULL,
    ubicacion_calle NUMBER(3), 
    ubicacion_carrera NUMBER(3)
);
CREATE TABLE telefonos(
    idTelefono NUMBER NOT NULL, 
    telefono  NUMBER(10) NOT NULL, 
    farmacia_nit  NUMBER NOT NULL
);
CREATE TABLE medicamentos(
    idMedicamento NUMBER NOT NULL, 
    laboratorio VARCHAR(70) NOT NULL, 
    nombre VARCHAR(70) NOT NULL, 
    descripcion VARCHAR(100) NOT NULL, 
    fechaElaboracion DATE NOT NULL, 
    fechaVencimiento DATE NOT NULL, 
    farmacia_nit NUMBER NOT NULL,
    pedido_id NUMBER NOT NULL
);
CREATE TABLE recetasMedicas(
    idRecetaM NUMBER NOT NULL, 
    prescipcion VARCHAR(70) NOT NULL, 
    candidadMedicamento NUMBER NOT NULL, 
    medicamento_id NUMBER NOT NULL, 
    cliente_cedula NUMBER NOT NULL
);
CREATE TABLE pedidos(
    idPedido NUMBER NOT NULL, 
    fechaYHoraEntrega DATE, 
    estado VARCHAR(70) NOT NULL, 
    domiciliario_cedula NUMBER, 
    cliente_cedula NUMBER NOT NULL,
    noFactura NUMBER NOT NULL,
    horaVenta VARCHAR(70) NOT NULL,
    precio VARCHAR(70) NOT NULL,
    tipoPago VARCHAR(70) NOT NULL
);
-------------
/*Primarias*/
ALTER TABLE ubicaciones ADD CONSTRAINT PK_calle_carrera PRIMARY KEY (calle, carrera);
ALTER TABLE telefonos ADD CONSTRAINT PK_numero PRIMARY KEY (idTelefono);
ALTER TABLE farmacias ADD CONSTRAINT PK_nit PRIMARY KEY (nit);
ALTER TABLE medicamentos ADD CONSTRAINT PK_medicamentosID PRIMARY KEY (idMedicamento);
ALTER TABLE recetasMedicas ADD CONSTRAINT PK_RMI PRIMARY KEY (idRecetaM);
ALTER TABLE clientes ADD CONSTRAINT PK_cliente_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT PK_pedidoId PRIMARY KEY (idPedido);
ALTER TABLE usuarios ADD CONSTRAINT PK_cedula PRIMARY KEY (cedula);
ALTER TABLE zonas ADD CONSTRAINT PK_zonaId PRIMARY KEY (idZona);
ALTER TABLE barrios ADD CONSTRAINT PK_BI PRIMARY KEY (idBarrio);
ALTER TABLE domiciliarios ADD CONSTRAINT PK_domiciliario_usuario_cedula PRIMARY KEY (usuario_cedula);
ALTER TABLE vehiculos ADD CONSTRAINT PK_placa PRIMARY KEY (placa);
ALTER TABLE zonasActivas ADD CONSTRAINT PK_domiciliariosCedula_zonasId PRIMARY KEY (domiciliario_cedula, zona_id);
/*Unicas*/
ALTER TABLE usuarios ADD CONSTRAINT UK_telefono UNIQUE (telefono);
ALTER TABLE clientes ADD CONSTRAINT UK_correo UNIQUE (correo);
ALTER TABLE pedidos ADD CONSTRAINT UK_noFactura UNIQUE (noFactura);
/*Foraneas*/
ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE medicamentos ADD CONSTRAINT FK_medicamentos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit);
ALTER TABLE medicamentos ADD CONSTRAINT FK_medicamentos_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(idPedido);
ALTER TABLE ubicaciones ADD CONSTRAINT FK_ubicaciones_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_medicamentos FOREIGN KEY (medicamento_id) REFERENCES medicamentos(idMedicamento);
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_clientes FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_clientes FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula);
ALTER TABLE farmacias ADD CONSTRAINT FK_farmacias_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
ALTER TABLE zonasActivas ADD CONSTRAINT FK_zonaActiva_domiciliaros FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula);
ALTER TABLE zonasActivas ADD CONSTRAINT FK_zonaActiva_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula);
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_ubicaciones FOREIGN KEY (ubicacion_calle, ubicacion_carrera) REFERENCES ubicaciones(calle, carrera);
-------------
/*RESTRICCIONES DECLARATIVAS-PROCEDIMENTALES Y AUTOMATIZACION*/
/*ACCIONES*/
ALTER TABLE domiciliarios DROP CONSTRAINT FK_domiciliarios_usuarios;
ALTER TABLE clientes DROP CONSTRAINT FK_clientes_usuarios;
ALTER TABLE vehiculos DROP CONSTRAINT FK_vehiculos_domiciliarios;
ALTER TABLE telefonos DROP CONSTRAINT FK_telefonos_farmacias;
ALTER TABLE barrios DROP CONSTRAINT FK_barrios_zonas;
ALTER TABLE clientes DROP CONSTRAINT FK_clientes_ubicaciones;
ALTER TABLE pedidos DROP CONSTRAINT FK_pedidos_domiciliarios;
ALTER TABLE pedidos DROP CONSTRAINT FK_pedidos_clientes;
ALTER TABLE zonasActivas DROP CONSTRAINT FK_zonaActiva_domiciliaros;
ALTER TABLE recetasMedicas DROP CONSTRAINT FK_recetasMedicas_medicamentos;
ALTER TABLE medicamentos DROP CONSTRAINT FK_medicamentos_pedidos;

ALTER TABLE domiciliarios ADD CONSTRAINT FK_domiciliarios_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula) ON DELETE CASCADE;
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula) ON DELETE SET NULL;
ALTER TABLE pedidos ADD CONSTRAINT FK_pedidos_clientes FOREIGN KEY (cliente_cedula) REFERENCES clientes(usuario_cedula) ON DELETE CASCADE;
ALTER TABLE zonasActivas ADD CONSTRAINT FK_zonaActiva_domiciliaros FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula) ON DELETE CASCADE;
ALTER TABLE clientes ADD CONSTRAINT FK_clientes_usuarios FOREIGN KEY (usuario_cedula) REFERENCES usuarios(cedula) ON DELETE CASCADE;
ALTER TABLE vehiculos ADD CONSTRAINT FK_vehiculos_domiciliarios FOREIGN KEY (domiciliario_cedula) REFERENCES domiciliarios(usuario_cedula) ON DELETE CASCADE;
ALTER TABLE telefonos ADD CONSTRAINT FK_telefonos_farmacias FOREIGN KEY (farmacia_nit) REFERENCES farmacias(nit) ON DELETE SET NULL;
ALTER TABLE barrios ADD CONSTRAINT FK_barrios_zonas FOREIGN KEY (zona_id) REFERENCES zonas(idZona) ON DELETE CASCADE;
ALTER TABLE recetasMedicas ADD CONSTRAINT FK_recetasMedicas_medicamentos FOREIGN KEY (medicamento_id) REFERENCES medicamentos(idMedicamento) ON DELETE SET NULL;
ALTER TABLE medicamentos ADD CONSTRAINT FK_medicamentos_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(idPedido) ON DELETE CASCADE;
-------------
/*TUPLAS*/
ALTER TABLE clientes ADD CONSTRAINT CK_clientes_correo CHECK (REGEXP_LIKE(correo, '(.+)\@(.+)\.(.+)'));
ALTER TABLE domiciliarios ADD CONSTRAINT CK_domiciliarios_licencia CHECK (licencia IN ('Valida', 'Invalida'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_placa CHECK (REGEXP_LIKE(placa, '[A-Z]{3}\d{3}'));
ALTER TABLE vehiculos ADD CONSTRAINT CK_vehiculos_tipoVehiculo CHECK (tipoVehiculo IN ('Bici', 'Carro', 'Moto'));
ALTER TABLE pedidos ADD CONSTRAINT CK_pedidos_estado CHECK (estado IN ('Entregado', 'Cancelado', 'Enviado'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_tipoPago CHECK (tipoPago IN ('PSE', 'EFECTIVO', 'TARJETA'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_precio CHECK (REGEXP_LIKE(precio, '(\$)[0-9]{1,7}(\.)[0-9]{1,3}'));
ALTER TABLE pedidos ADD CONSTRAINT CK_venta_horaVenta CHECK (REGEXP_LIKE(horaVenta, '[0-9]{0,2}(\:)[0-9]{0,2}(\:)[0-9]{0,2}'));
-------------
/*DISPARADORES*/
CREATE SEQUENCE zonas_seq START WITH 1; --Se va a automatizar idZona
CREATE SEQUENCE barrios_seq START WITH 1; -- Se va a automatizar idBarrio
CREATE SEQUENCE medicamentos_seq START WITH 1; -- Se va a automatizar idMedicamento
CREATE SEQUENCE recetasMed_seq START WITH 1; -- Se va a automatizar idReceta
CREATE SEQUENCE pedidos_seq START WITH 1; -- Se va a automatizar idPedido
CREATE SEQUENCE telefonos_seq START WITH 1; -- Se va a automatizar idTelefono
CREATE SEQUENCE ventas_seq START WITH 1; -- Se va a automatizar noFactura
/*BI*/
CREATE OR REPLACE TRIGGER TG_ZONAS_BI
BEFORE INSERT ON zonas
FOR EACH ROW
BEGIN
    SELECT zonas_seq.NEXTVAL INTO :new.idZona FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_BARRIOS_BI
BEFORE INSERT ON barrios
FOR EACH ROW
BEGIN
    SELECT barrios_seq.NEXTVAL INTO :new.idBarrio FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_MEDICAMENTOS_BI
BEFORE INSERT ON medicamentos
FOR EACH ROW
BEGIN
    IF (:new.fechaElaboracion > :new.fechaVencimiento) THEN
        raise_application_error(-20001,'No se puede tener una fecha de fabricacion mayor a la de venecimiento.'); 
    END IF;
    SELECT medicamentos_seq.NEXTVAL INTO :new.idMedicamento FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_RECETASMED_BI
BEFORE INSERT ON recetasMedicas
FOR EACH ROW
BEGIN
    SELECT recetasMed_seq.NEXTVAL INTO :new.idRecetaM FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_PEDIDOS_BI
BEFORE INSERT ON pedidos
FOR EACH ROW
BEGIN
    SELECT TO_CHAR(sysdate, 'HH24:MI:SS') INTO :new.horaVenta FROM dual;
    SELECT pedidos_seq.NEXTVAL INTO :new.idPedido FROM dual;
    SELECT LPAD(ventas_seq.NEXTVAL,6,0) INTO :new.noFactura FROM dual;
END;
---
CREATE OR REPLACE TRIGGER TG_TELEFONOS_BI
BEFORE INSERT ON telefonos
FOR EACH ROW
BEGIN
    SELECT telefonos_seq.NEXTVAL INTO :new.idTelefono FROM dual;
END;
/*BU*/
CREATE OR REPLACE TRIGGER TG_USUARIOS_BU
BEFORE UPDATE ON usuarios
FOR EACH ROW
BEGIN
    IF (:new.cedula != :old.cedula) THEN 
        raise_application_error(-20002,'No se puede actualizar el numero de cedula.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_FARMACIAS_BU
BEFORE UPDATE ON farmacias
FOR EACH ROW
BEGIN
    IF (:new.nit != :old.nit) THEN 
        raise_application_error(-20003,'No se puede actualizar el nit.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_MEDICAMENTOS_BU
BEFORE UPDATE ON medicamentos
FOR EACH ROW
BEGIN
    IF (:new.fechaElaboracion != :old.fechaElaboracion OR :new.fechaVencimiento != :old.fechaVencimiento) THEN 
        raise_application_error(-20004,'No se puede actualizar el medicamento.'); 
    END IF;
END;
---
CREATE OR REPLACE TRIGGER TG_PEDIDOS_BU
BEFORE UPDATE ON pedidos
FOR EACH ROW
DECLARE
    fechaActual DATE;
BEGIN
    IF (:new.estado = 'Entregado') THEN
        SELECT SYSDATE INTO fechaActual FROM dual;
        UPDATE pedidos SET fechaYHoraEntrega = fechaActual;
    END IF;
    UPDATE pedidos SET estado = :new.estado;
END;
--
CREATE OR REPLACE TRIGGER TG_ZONASACTIVAS_BU
BEFORE UPDATE ON zonasActivas
FOR EACH ROW
BEGIN
    IF (:new.domiciliario_cedula != :old.domiciliario_cedula) THEN
        raise_application_error(-20005,'No se puede actualizar la zona activa.'); 
    END IF;
END;
-------------
/*INDICES Y VISTAS*/
/*INDICES*/
CREATE INDEX IFarmaciasNombre ON farmacias(nombre);
CREATE INDEX IMedicamentosNombre ON medicamentos(nombre);
/*VISTAS*/
CREATE VIEW VPedidosCont AS SELECT tipoPago, precio, zona_id FROM pedidos
JOIN clientes ON (cliente_cedula = usuario_cedula) 
JOIN ubicaciones ON (ubicacion_calle = calle AND ubicacion_carrera = carrera) 
WHERE estado = 'Entregado';

CREATE VIEW VPedidosClientes AS SELECT nombre, correo, count(idPedido) AS numPedidos FROM clientes 
JOIN pedidos ON (cliente_cedula = usuario_cedula)
JOIN usuarios ON (cedula = usuario_cedula) WHERE estado = 'Entregado'
GROUP BY nombre, correo ORDER BY numPedidos DESC;

CREATE VIEW VFarmacias AS SELECT nit, nombre, sucursal, localidad FROM farmacias
JOIN ubicaciones ON (ubicacion_calle = calle AND ubicacion_carrera = carrera) 
JOIN zonas ON (zona_id = idZona);

CREATE VIEW VUbicacionesClient AS SELECT usuario_cedula, calle, carrera, torre, apartamento, manzana 
FROM clientes JOIN ubicaciones ON (calle = ubicacion_calle AND carrera = ubicacion_carrera);

CREATE VIEW VUbicacionesFarm AS SELECT nit, nombre, ubicacion_calle, ubicacion_carrera, localidad FROM farmacias
JOIN ubicaciones ON (ubicacion_calle = calle AND ubicacion_carrera = carrera)
JOIN zonas ON (zona_id = idZona) ;
-------------
/*COMPONENTES*/
/*CRUDE*/
CREATE OR REPLACE PACKAGE PC_FARMACIAS IS
    PROCEDURE adicionar(xNit IN NUMBER, xNombre IN VARCHAR, xSucursal IN NUMBER, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE add_telefonos(xNit IN NUMBER, xTelefono IN NUMBER);
    PROCEDURE add_recetaMedica(xPrescipcion IN VARCHAR, xCantidadMedicamento IN NUMBER, xMedicamento IN NUMBER, xCedula IN NUMBER);
    PROCEDURE add_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER);
    PROCEDURE mod_telefonos(xNit IN NUMBER, xTelefono IN NUMBER);
    PROCEDURE mod_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR);
    PROCEDURE el_medicamento (xIdMedicamento IN VARCHAR);
    FUNCTION co_medicamento (xNombre IN VARCHAR)  RETURN SYS_REFCURSOR;
    FUNCTION co_farmacias RETURN SYS_REFCURSOR;
    FUNCTION co_ubicacionFarm (xNit IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_medicamentos (xNit IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_recetasMedicas(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_socios RETURN SYS_REFCURSOR;
END; 
---
CREATE OR REPLACE PACKAGE PC_PEDIDOS IS
    PROCEDURE adicionar (xIdPedido IN NUMBER, xFechaYHoraEntrega IN DATE, xEstado IN VARCHAR, xDomiciliario IN NUMBER, xCliente IN NUMBER, xNoFactura IN NUMBER, xHoraVenta IN DATE, xPrecio IN NUMBER, xTipoPago IN VARCHAR);
    PROCEDURE mo_estadoCliente (xIdPedido IN NUMBER, xEstado IN VARCHAR);
    PROCEDURE mo_entregaYEstado (xIdPedido IN NUMBER, xEstado IN VARCHAR);
    FUNCTION consultar (xIdPedido IN NUMBER)  RETURN SYS_REFCURSOR;
    FUNCTION co_pedidos_ganancia RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PC_USUARIOS IS
    PROCEDURE adicionar (xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xLicencia IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE add_vehiculo (xPlaca IN VARCHAR,  xTipo IN VARCHAR, xCedula IN NUMBER);
    PROCEDURE mod_nombre (xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mod_telefono (xCedula IN NUMBER, xTelefono IN NUMBER);
    PROCEDURE mod_vehiculo (xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE eliminar (xCedula IN NUMBER);
    PROCEDURE el_vehiculo (xPlaca IN VARCHAR);
    FUNCTION consultar (xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_catidadPedidos RETURN SYS_REFCURSOR;
    FUNCTION co_vehiculo (xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_ubicacion_cliente (xCedula IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PC_UBICACIONES IS 
    PROCEDURE adicionar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE add_zona(xLocalidad IN NUMBER);
    PROCEDURE add_barrio(xBarrio IN NUMBER, xZonaId IN NUMBER);
    PROCEDURE add_zonaActiva(xCedula IN NUMBER, xIdZona IN NUMBER, xFechaActiva IN DATE);
    PROCEDURE modificar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE mod_localidad(xLocalidad IN NUMBER, xIdZona IN NUMBER);
    PROCEDURE mod_barrio(xIdZona IN NUMBER, xBarrio IN NUMBER);
    FUNCTION consultar (xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_zonaActiva(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
END;
/*CRUDI*/
CREATE OR REPLACE PACKAGE BODY PC_FARMACIAS IS
    PROCEDURE adicionar(xNit IN NUMBER, xNombre IN VARCHAR, xSucursal IN NUMBER, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        INSERT INTO farmacias (nit, nombre, sucursal,ubicacion_calle, ubicacion_carrera) VALUES (xNit, xNombre, xSucursal, xCalle, xCarrera);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede insertar la farmacia.');
    END;
    --
    PROCEDURE add_telefonos(xNit IN NUMBER, xTelefono IN NUMBER)
    IS
    BEGIN
        INSERT INTO telefonos (idTelefono, telefono, farmacia_nit)  VALUES (0, xTelefono, xNit) ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede insertar el telefono de la farmacia.');
    END;
    --
    PROCEDURE add_recetaMedica(xPrescipcion IN VARCHAR, xCantidadMedicamento IN NUMBER, xMedicamento IN NUMBER, xCedula IN NUMBER)
    IS
    BEGIN
        INSERT INTO recetasMedicas (idRecetaM, prescipcion, candidadMedicamento, medicamento_id, cliente_cedula)  VALUES (0, xPrescipcion, xCantidadMedicamento, xMedicamento, xCedula) ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede insertar la receta medica.');
    END;
    --
    PROCEDURE add_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER)
    IS
    BEGIN
        INSERT INTO medicamentos (idMedicamento, laboratorio, nombre, descripcion, fechaElaboracion, fechaVencimiento, farmacia_nit) 
        VALUES (xIdMedicamento, xLaboratorio, xNombre, xDescripcion, xElaboracion, xVencimiento, xNitFarmacia);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20006, 'No se puede insertar el medicamento.');
    END;
    --
    PROCEDURE mod_telefonos(xNit IN NUMBER, xTelefono IN NUMBER)
    IS
    BEGIN
        UPDATE telefonos SET telefono = xTelefono WHERE farmacia_nit = xNit;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede actualizar el telefono de la farmacia.');
    END;
    --
    PROCEDURE mod_medicamento (xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR)
    IS
    BEGIN
        UPDATE medicamentos SET laboratorio = xLaboratorio, nombre = xNombre, descripcion = xDescripcion  WHERE idMedicamento = xIdMedicamento;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20007, 'No se puede actualizar el medicamento.');
    END;
    --
    PROCEDURE el_medicamento (xIdMedicamento IN VARCHAR)
    IS
    BEGIN
        DELETE FROM medicamentos WHERE idMedicamento = xIdMedicamento;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20008, 'No se puede eliminar el medicamento.');
    END;
    --
    FUNCTION co_medicamento (xNombre IN VARCHAR)  RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
    OPEN co_medicamento FOR
		SELECT * FROM medicamentos WHERE nombre = xNombre;
	RETURN co_medicamento;
    END;
    --
    FUNCTION co_farmacias RETURN SYS_REFCURSOR IS co_farmacias SYS_REFCURSOR;
    BEGIN
    OPEN co_farmacias FOR
		SELECT nit, sucursal FROM farmacias;
	RETURN co_farmacias;
    END;
    --
    FUNCTION co_ubicacionFarm (xNit IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacionFarm SYS_REFCURSOR;
    BEGIN
    OPEN co_ubicacionFarm FOR
		SELECT * FROM VUbicacionesFarm WHERE nit = xNit;
	RETURN co_ubicacionFarm;
    END;
    --
    FUNCTION co_medicamentos (xNit IN NUMBER) RETURN SYS_REFCURSOR IS co_medicamentos SYS_REFCURSOR;
    BEGIN
    OPEN co_medicamentos FOR
        SELECT * FROM medicamentos WHERE farmacia_nit = xNit;
    RETURN co_medicamentos;
    END;
    --
    FUNCTION co_recetasMedicas(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_recetasMedicas SYS_REFCURSOR;
    BEGIN
    OPEN co_recetasMedicas FOR
        SELECT medicamento_id,prescipcion,candidadMedicamento FROM recetasMedicas WHERE cliente_cedula = xCedula;
    RETURN co_recetasMedicas;
    END;
    --
    FUNCTION co_socios RETURN SYS_REFCURSOR IS co_socios SYS_REFCURSOR;
    BEGIN
    OPEN co_socios FOR
        SELECT * FROM VFarmacias;
    RETURN co_socios;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_PEDIDOS IS
    PROCEDURE adicionar (xIdPedido IN NUMBER, xFechaYHoraEntrega IN DATE, xEstado IN VARCHAR, xDomiciliario IN NUMBER, xCliente IN NUMBER, xNoFactura IN NUMBER, xHoraVenta IN DATE, xPrecio IN NUMBER, xTipoPago IN VARCHAR)
    IS
    BEGIN
        INSERT INTO pedidos (idPedido, fechaYHoraEntrega, estado, domiciliario_cedula, cliente_cedula, noFactura, horaVenta, precio, tipoPago)
        VALUES (xIdPedido, xFechaYHoraEntrega, xEstado, xDomiciliario, xCliente, xNoFactura, xHoraVenta, xPrecio, xTipoPago);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20009, 'No se puede insertar el pedido.');
    END;
    --
    PROCEDURE mo_estadoCliente (xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        UPDATE pedidos SET estado = xEstado WHERE idPedido = xIdPedido;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20010, 'No se puede actualizar el estado del pedido.');
    END;
    --
    PROCEDURE mo_entregaYEstado (xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        IF (xEstado != 'Entregado') THEN
            RAISE_APPLICATION_ERROR(-20011, 'Estado de entrega incorrecto.');
        END IF;
        UPDATE pedidos SET estado = xEstado  WHERE idPedido = xIdPedido;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20999, SQLERRM);
    END;
    --
    FUNCTION consultar (xIdPedido IN NUMBER)  RETURN SYS_REFCURSOR IS co_pedido SYS_REFCURSOR;
    BEGIN
    OPEN co_pedido FOR
		SELECT * FROM pedidos WHERE idPedido = xIdPedido;
	RETURN co_pedido;
    END;
    --
    FUNCTION co_pedidos_ganancia RETURN SYS_REFCURSOR IS co_entregados SYS_REFCURSOR;
    BEGIN
    OPEN co_entregados FOR
		SELECT * FROM VPedidosCont;
	RETURN co_entregados;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_USUARIOS IS
    PROCEDURE adicionar (xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xLicencia IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        INSERT INTO usuarios (cedula, nombre, telefono)
        VALUES (xCedula, xNombre, xTelefono);
        IF (xCorreo != NULL) THEN
            INSERT INTO clientes (usuario_cedula, correo, ubicacion_calle, ubicacion_carrera) VALUES (xCedula, xCorreo, xCalle, xCarrera);
        END IF;
        IF (xLicencia != NULL) THEN
            INSERT INTO domiciliarios (usuario_cedula, licencia) VALUES (xCedula, xLicencia);
        END IF;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20012, 'No se puede insertar el usuario.');
    END;
    --
    PROCEDURE add_vehiculo (xPlaca IN VARCHAR,  xTipo IN VARCHAR, xCedula IN NUMBER)
    IS
    BEGIN
        INSERT INTO vehiculos (placa,tipoVehiculo,domiciliario_cedula) VALUES (xPlaca, xTipo, xCedula);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20013, 'No se puede insertar el vehiculo.');
    END;
    --
    PROCEDURE mod_nombre (xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        UPDATE usuarios SET nombre = xNombre WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20013, 'No se puede actualizar el nombre del usuario.');
    END;
    --
    PROCEDURE mod_telefono (xCedula IN NUMBER, xTelefono IN NUMBER)
    IS
    BEGIN
        UPDATE usuarios SET telefono = xTelefono WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20014, 'No se puede actualizar el telefono del usuario.');
    END;
    --
    PROCEDURE mod_vehiculo (xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        UPDATE vehiculos SET tipoVehiculo = xTipo WHERE placa = xPlaca;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20014, 'No se puede actualizar el vehiculo.');
    END;
    --
    PROCEDURE eliminar (xCedula IN NUMBER)
    IS
    BEGIN
        DELETE FROM usuarios WHERE cedula = xCedula;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20015, 'No se puede eliminar el usuario.');
    END;
    --
    PROCEDURE el_vehiculo (xPlaca IN VARCHAR)
    IS
    BEGIN
        DELETE FROM vehiculos WHERE placa = xPlaca;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20015, 'No se puede eliminar el vehiculo.');
    END;
    --
    FUNCTION consultar(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
    OPEN co_usuario FOR
		SELECT * FROM usuarios WHERE cedula = xCedula;
	RETURN co_usuario;
    END;
    --
    FUNCTION co_catidadPedidos RETURN SYS_REFCURSOR IS co_cantidadPedidos SYS_REFCURSOR;
    BEGIN
    OPEN co_cantidadPedidos FOR
		SELECT * FROM VPedidosClientes;
	RETURN co_cantidadPedidos;
    END;
    --
    FUNCTION co_vehiculo (xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_vehiculo SYS_REFCURSOR;
    BEGIN
    OPEN co_vehiculo FOR
		SELECT * FROM vehiculos WHERE domiciliario_cedula = xCedula;
        RETURN co_vehiculo;
    END;
    --
    FUNCTION co_ubicacion_cliente (xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion_cliente SYS_REFCURSOR;
    BEGIN
    OPEN co_ubicacion_cliente FOR
        SELECT * FROM VUbicacionesClient WHERE usuario_cedula = xCedula;
        RETURN co_ubicacion_cliente;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PC_UBICACIONES IS 
    PROCEDURE adicionar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        INSERT INTO ubicaciones (calle, carrera, torre, apartamento, manzana, localUbi, zona_id)
        VALUES (xCalle, xCarrera, xTorre, xApto, xManz, xLocal, xZona);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20019, 'No se puede insertar la ubicacion.');
    END;
    --
    PROCEDURE add_zona(xLocalidad IN NUMBER)
    IS
    BEGIN
        INSERT INTO zonas (idZona, localidad) VALUES (0, xLocalidad);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20019, 'No se puede insertar la zona.');
    END;
    --
    PROCEDURE add_barrio(xBarrio IN NUMBER, xZonaId IN NUMBER)
    IS
    BEGIN
        INSERT INTO barrios (idBarrio, barrio, zona_id) VALUES (0, xBarrio, xZonaId);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20019, 'No se puede insertar el barrio en la zona.');
    END;
    --
    PROCEDURE add_zonaActiva(xCedula IN NUMBER, xIdZona IN NUMBER, xFechaActiva IN DATE)
    IS
    BEGIN
        INSERT INTO zonasActivas (domiciliario_cedula, zona_id, fechaAsignacion) VALUES (xCedula, xIdZona, xFechaActiva);
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20019, 'No se puede insertar la zona activa.');
    END;
    --
    PROCEDURE modificar (xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        UPDATE ubicaciones SET calle=xCalle, carrera=xCarrera, torre=xTorre, apartamento=xApto, manzana=xManz, localUbi = xLocal, zona_id = xZona WHERE calle = xCalle AND carrera = xCarrera;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20020, 'No se puede actualizar la ubicacion.');
    END;
    --
    PROCEDURE mod_localidad(xLocalidad IN NUMBER, xIdZona IN NUMBER)
    IS
    BEGIN
        UPDATE zonas SET localidad = xLocalidad WHERE idZona = xIdZona;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20020, 'No se puede actualizar la localidad de la zona.');
    END;
     --
    PROCEDURE mod_barrio(xIdZona IN NUMBER, xBarrio IN NUMBER)
    IS
    BEGIN
        UPDATE barrios SET barrio = xBarrio WHERE zona_id = xIdZona;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE_APPLICATION_ERROR(-20020, 'No se puede actualizar el barrio.');
    END;
    --
    FUNCTION consultar (xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
    OPEN co_ubicacion FOR
        SELECT * FROM ubicaciones WHERE (calle = xCalle AND carrera = xCarrera);
	RETURN co_ubicacion;
    END;
    --
    FUNCTION co_zonaActiva(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_zonaActiva SYS_REFCURSOR;
    BEGIN
    OPEN co_zonaActiva FOR
        SELECT * FROM zonasActivas WHERE domiciliario_cedula = xCedula;
	RETURN co_zonaActiva;
    END;
END;
-------------
/*SEGURIDAD*/
/*ActoresE*/
CREATE OR REPLACE PACKAGE PA_CLIENTE IS
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER);
    PROCEDURE ad_recetaMedica(xPrescipcion IN VARCHAR, xCantidadMedicamento IN NUMBER, xMedicamento IN NUMBER, xCedula IN NUMBER);
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR);
    PROCEDURE mo_estadoPedido(xIdPedido IN NUMBER, xEstado IN VARCHAR);
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER);
    PROCEDURE el_usuario(xCedula IN NUMBER);
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_pedido(xIdPedido IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR;
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_recetasMedicas(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PA_DOMICILIARIO IS 
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xLicencia IN VARCHAR);
    PROCEDURE ad_vehiculo(xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR);
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR);
    PROCEDURE mo_vehiculo(xPlaca IN VARCHAR, xTipo IN VARCHAR);
    PROCEDURE mo_entregaYEstado(xIdPedido IN NUMBER, xEstado IN VARCHAR);
    PROCEDURE el_usuario(xCedula IN NUMBER);
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR);
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_vehiculo (xPlaca IN VARCHAR) RETURN SYS_REFCURSOR;
    FUNCTION co_ubicaCliente(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_ubicaFarmacia (xNit IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_zonaActiva(xCedula IN NUMBER) RETURN SYS_REFCURSOR;
END;
---
CREATE OR REPLACE PACKAGE PA_FARMACEUTICO IS
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE ad_pedido(xDomiciliario IN NUMBER, xCliente IN NUMBER, xPrecio IN NUMBER, xTipoPago IN VARCHAR);
    PROCEDURE ad_medicamento(xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER);
    PROCEDURE ad_farmacia(xNit IN NUMBER, xNombre IN VARCHAR, xSucursal IN NUMBER, xCalle IN NUMBER, xCarrera IN NUMBER);
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER);
    PROCEDURE mo_medicamento(xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR);
    PROCEDURE mo_telefono(xNit IN NUMBER, xTelefono IN NUMBER);
    PROCEDURE el_medicamento(xIdMedicamento IN VARCHAR);
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR;
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR;
END;
--
CREATE OR REPLACE PACKAGE PA_DISTRIBUIDOR IS
    PROCEDURE ad_zona (xLocalidad IN NUMBER);
    PROCEDURE ad_barrio (xBarrio IN NUMBER, xZonaId IN NUMBER);
    PROCEDURE ad_ZonaActiva (xIdZona IN NUMBER, xCedula IN NUMBER, xFechaActiva IN DATE);
    PROCEDURE mo_localidad (xLocalidad IN NUMBER, xIdZona IN NUMBER);
    PROCEDURE mo_barrio (xIdZona IN NUMBER, xBarrio IN NUMBER);
END;
---
CREATE OR REPLACE PACKAGE PA_CONTADOR IS

    FUNCTION co_pedidoEntregados RETURN SYS_REFCURSOR;
    
END;
---
CREATE OR REPLACE PACKAGE PA_ADMINISTRADOR IS
    FUNCTION co_clientesVIP RETURN SYS_REFCURSOR;
    FUNCTION co_socios RETURN SYS_REFCURSOR;
END;
/*ActoresI*/
CREATE OR REPLACE PACKAGE BODY PA_CLIENTE IS
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xCorreo IN VARCHAR, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.adicionar(xCedula, xNombre, xTelefono, xCorreo, NULL, xCalle, xCarrera);
    END;
    --
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.adicionar(xCalle, xCarrera, xTorre, xApto, xManz, NULL, xZona);
    END;
    --
    PROCEDURE ad_recetaMedica(xPrescipcion IN VARCHAR, xCantidadMedicamento IN NUMBER, xMedicamento IN NUMBER, xCedula IN NUMBER)
    IS
    BEGIN
        PC_FARMACIAS.add_recetaMedica(xPrescipcion, xCantidadMedicamento, xMedicamento, xCedula);
    END;
    --
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_nombre(xCedula, xNombre);
    END;
    --
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_telefono(xCedula, xTelefono);
    END;
    --
    PROCEDURE mo_estadoPedido(xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.mo_estadoCliente(xIdPedido, xEstado);
    END;
    --
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xTorre IN NUMBER, xApto IN NUMBER, xManz IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.modificar(xCalle, xCarrera, xTorre, xApto, xManz, NULL, xZona);
    END;
    --
    PROCEDURE el_usuario(xCedula IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.eliminar(xCedula);
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
        co_usuario := PC_USUARIOS.consultar(xCedula);
        RETURN co_usuario;
	END;
    --
    FUNCTION co_pedido(xIdPedido IN NUMBER) RETURN SYS_REFCURSOR IS co_pedido SYS_REFCURSOR;
    BEGIN
        co_pedido := PC_PEDIDOS.consultar(xIdPedido);
        RETURN co_pedido;
	END;
    --
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
        co_medicamento := PC_FARMACIAS.co_medicamento(xNombre);
        RETURN co_medicamento;
	END;
    --
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
        co_ubicacion := PC_UBICACIONES.consultar(xCalle, xCarrera);
        RETURN co_ubicacion;
    END;
    --
    FUNCTION co_recetasMedicas(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_recetasMedicas SYS_REFCURSOR;
    BEGIN
        co_recetasMedicas := PC_FARMACIAS.co_recetasMedicas(xCedula);
        RETURN co_recetasMedicas;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_DOMICILIARIO IS 
    PROCEDURE ad_usuario(xCedula IN NUMBER, xNombre IN VARCHAR, xTelefono IN NUMBER, xLicencia IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.adicionar(xCedula, xNombre, xTelefono, NULL, xLicencia, NULL, NULL);
    END;
    --
    PROCEDURE ad_vehiculo(xCedula IN NUMBER, xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.add_vehiculo(xCedula, xPlaca, xTipo);
    END;
    --
    PROCEDURE mo_nombre(xCedula IN NUMBER, xNombre IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_nombre(xCedula, xNombre);
    END;
    --
    PROCEDURE mo_telefono(xCedula IN NUMBER, xTelefono IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_telefono(xCedula, xTelefono);
    END;
    --
    PROCEDURE mo_vehiculo(xPlaca IN VARCHAR, xTipo IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.mod_vehiculo(xPlaca, xTipo);
    END;
    --
    PROCEDURE mo_entregaYEstado(xIdPedido IN NUMBER, xEstado IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.mo_entregaYEstado(xIdPedido, xEstado);
    END;
    --
    PROCEDURE el_usuario(xCedula IN NUMBER)
    IS
    BEGIN
        PC_USUARIOS.eliminar(xCedula);
    END;
    --
    PROCEDURE el_vehiculo(xPlaca IN VARCHAR)
    IS
    BEGIN
        PC_USUARIOS.el_vehiculo(xPlaca);
    END;
    --
    FUNCTION co_usuario(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_usuario SYS_REFCURSOR;
    BEGIN
        co_usuario := PC_USUARIOS.consultar(xCedula);
        RETURN co_usuario;
	END;
    --
    FUNCTION co_vehiculo (xPlaca IN VARCHAR) RETURN SYS_REFCURSOR IS co_vehiculo SYS_REFCURSOR;
    BEGIN
        co_vehiculo := PC_USUARIOS.co_vehiculo(xPlaca);
        RETURN co_vehiculo;
    END;
    --
    FUNCTION co_ubicaCliente(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicaCliente SYS_REFCURSOR;
    BEGIN
        co_ubicaCliente := PC_USUARIOS.co_ubicacion_cliente(xCedula);
        RETURN co_ubicaCliente;
	END;
    --
    FUNCTION co_ubicaFarmacia (xNit IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicaFarmacia SYS_REFCURSOR;
    BEGIN
        co_ubicaFarmacia := PC_FARMACIAS.co_ubicacionFarm(xNit);
        RETURN co_ubicaFarmacia;
    END;
    --
    FUNCTION co_zonaActiva(xCedula IN NUMBER) RETURN SYS_REFCURSOR IS co_zonaActiva SYS_REFCURSOR;
    BEGIN
        co_zonaActiva := PC_UBICACIONES.co_zonaActiva(xCedula);
        RETURN co_zonaActiva;
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_FARMACEUTICO IS
    PROCEDURE ad_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.adicionar(xCalle, xCarrera, NULL, NULL, NULL, xLocal, xZona);
    END;
    --
    PROCEDURE ad_pedido(xDomiciliario IN NUMBER, xCliente IN NUMBER, xPrecio IN NUMBER, xTipoPago IN VARCHAR)
    IS
    BEGIN
        PC_PEDIDOS.adicionar(0, NULL, 'Enviado', xDomiciliario, xCliente, 0, '00:00:00', xPrecio, xTipoPago);
    END;
    --
    PROCEDURE ad_medicamento(xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR, xElaboracion IN DATE, xVencimiento IN DATE, xNitFarmacia IN NUMBER)
    IS
    BEGIN
        PC_FARMACIAS.add_medicamento(0, xLaboratorio, xNombre, xDescripcion, xElaboracion, xVencimiento, xNitFarmacia);
    END;
    --
    PROCEDURE ad_farmacia(xNit IN NUMBER, xNombre IN VARCHAR, xSucursal IN NUMBER, xCalle IN NUMBER, xCarrera IN NUMBER)
    IS
    BEGIN
        PC_FARMACIAS.adicionar(xNit, xNombre, xSucursal, xCalle, xCarrera);
    END;
    -- 
    PROCEDURE mo_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER, xLocal IN NUMBER, xZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.modificar(xCalle, xCarrera, NULL, NULL, NULL, xLocal, xZona);
    END;
    --
    PROCEDURE mo_medicamento(xIdMedicamento IN NUMBER, xLaboratorio IN VARCHAR, xNombre IN VARCHAR, xDescripcion IN VARCHAR)
    IS
    BEGIN
        PC_FARMACIAS.mod_medicamento (xIdMedicamento, xLaboratorio, xNombre, xDescripcion);
    END;
    --
    PROCEDURE mo_telefono(xNit IN NUMBER, xTelefono IN NUMBER)
    IS
    BEGIN
        PC_FARMACIAS.mod_telefonos (xNit, xTelefono);
    END;
    --
    PROCEDURE el_medicamento(xIdMedicamento IN VARCHAR)
    IS
    BEGIN
        PC_FARMACIAS.el_medicamento(xIdMedicamento);
    END;
    --
    FUNCTION co_ubicacion(xCalle IN NUMBER, xCarrera IN NUMBER) RETURN SYS_REFCURSOR IS co_ubicacion SYS_REFCURSOR;
    BEGIN
        co_ubicacion :=  PC_UBICACIONES.consultar(xCalle, xCarrera);
        RETURN co_ubicacion;
	END;    
    --
    FUNCTION co_medicamento(xNombre IN VARCHAR) RETURN SYS_REFCURSOR IS co_medicamento SYS_REFCURSOR;
    BEGIN
        co_medicamento :=  PC_FARMACIAS.co_medicamento(xNombre);
        RETURN co_medicamento;
	END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_DISTRIBUIDOR IS
    PROCEDURE ad_zona (xLocalidad IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.add_zona(xLocalidad);
    END;
    PROCEDURE ad_barrio (xBarrio IN NUMBER, xZonaId IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.add_barrio(xBarrio, xZonaId);
    END;
    PROCEDURE ad_ZonaActiva (xIdZona IN NUMBER, xCedula IN NUMBER, xFechaActiva IN DATE)
    IS
    BEGIN
        PC_UBICACIONES.add_zonaActiva(xIdZona, xCedula, xFechaActiva);
    END;
    PROCEDURE mo_localidad (xLocalidad IN NUMBER, xIdZona IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.mod_localidad(xLocalidad, xIdZona);
    END;
    PROCEDURE mo_barrio (xIdZona IN NUMBER, xBarrio IN NUMBER)
    IS
    BEGIN
        PC_UBICACIONES.mod_barrio(xIdZona, xBarrio);
    END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_CONTADOR IS
    FUNCTION co_pedidoEntregados RETURN SYS_REFCURSOR IS co_pedidoEntregados SYS_REFCURSOR;
    BEGIN
        co_pedidoEntregados :=  PC_PEDIDOS.co_pedidos_ganancia;
        RETURN co_pedidoEntregados;
	END;
END;
---
CREATE OR REPLACE PACKAGE BODY PA_ADMINISTRADOR IS
    FUNCTION co_clientesVIP RETURN SYS_REFCURSOR IS co_clientesVIP SYS_REFCURSOR;
    BEGIN
        co_clientesVIP :=  PC_USUARIOS.co_catidadPedidos;
        RETURN co_clientesVIP;
	END;
    --
    FUNCTION co_socios RETURN SYS_REFCURSOR IS co_socios SYS_REFCURSOR;
    BEGIN
        co_socios :=  PC_FARMACIAS.co_socios;
        RETURN co_socios;
	END;
END;
/*Seguridad*/
CREATE ROLE usuariocliente;
CREATE ROLE domiciliario;
CREATE ROLE farmaceutico;
CREATE ROLE distribuidor;
CREATE ROLE administradormediphil;
CREATE ROLE contador;

GRANT INSERT, SELECT, UPDATE, DELETE ON usuarios TO usuariocliente;
GRANT SELECT ON pedidos TO usuariocliente;
GRANT SELECT ON medicamentos TO usuariocliente;
GRANT INSERT, SELECT, UPDATE, DELETE ON ubicaciones TO usuariocliente;
GRANT INSERT, SELECT, UPDATE, DELETE ON vehiculos TO domiciliario;
GRANT SELECT, UPDATE ON pedidos TO domiciliario;
GRANT SELECT ON ubicaciones TO domiciliario;
GRANT INSERT, SELECT, UPDATE, DELETE ON ubicaciones TO farmaceutico;
GRANT INSERT, SELECT ON pedidos TO farmaceutico;
GRANT INSERT, SELECT, UPDATE, DELETE ON medicamentos TO farmaceutico;
GRANT INSERT, SELECT, UPDATE, DELETE ON zonas TO distribuidor;
GRANT SELECT ON pedidos TO contador;
GRANT SELECT ON usuarios TO administradormediphil;
GRANT SELECT ON farmacias TO administradormediphil;
-------------
/*XSeguridad*/
DROP ROLE usuariocliente;
DROP ROLE domiciliario;
DROP ROLE farmaceutico;
DROP ROLE distribuidor;
DROP ROLE administradormediphil;
DROP ROLE contador;
DROP PACKAGE PA_CLIENTE;
DROP PACKAGE PA_DOMICILIARIO;
DROP PACKAGE PA_FARMACEUTICO;
DROP PACKAGE PA_DISTRIBUIDOR;
DROP PACKAGE PA_CONTADOR;
DROP PACKAGE PA_ADMINISTRADOR;
-------------
/*XCRUD*/
DROP PACKAGE PC_FARMACIAS;
DROP PACKAGE PC_PEDIDOS;
DROP PACKAGE PC_USUARIOS;
DROP PACKAGE PC_UBICACIONES;
-------------
/*XIndicesVistas*/
DROP INDEX IFarmaciasNombre;
DROP INDEX IMedicamentosNombre;
DROP VIEW VPedidosCont;
DROP VIEW VPedidosClientes;
DROP VIEW VFarmacias;
DROP VIEW VUbicacionesClient;
DROP VIEW VUbicacionesFarm;
-------------
/*XDisparadores*/
DROP SEQUENCE zonas_seq;
DROP SEQUENCE barrios_seq;
DROP SEQUENCE medicamentos_seq;
DROP SEQUENCE recetasMed_seq;
DROP SEQUENCE pedidos_seq;
DROP SEQUENCE telefonos_seq;
DROP SEQUENCE ventas_seq;
DROP TRIGGER TG_ZONAS_BI;
DROP TRIGGER TG_BARRIOS_BI;
DROP TRIGGER TG_MEDICAMENTOS_BI;
DROP TRIGGER TG_RECETASMED_BI;
DROP TRIGGER TG_PEDIDOS_BI;
DROP TRIGGER TG_TELEFONOS_BI;
DROP TRIGGER TG_USUARIOS_BU;
DROP TRIGGER TG_FARMACIAS_BU;
DROP TRIGGER TG_ZONASACTIVAS_BU;
-------------
/*XPoblar*/
DELETE FROM recetasMedicas;
DELETE FROM clientes;
DELETE FROM pedidos;
DELETE FROM medicamentos;
DELETE FROM telefonos;
DELETE FROM farmacias;
DELETE FROM ubicaciones;
DELETE FROM barrios;
DELETE FROM zonasActivas;
DELETE FROM zonas;
DELETE FROM vehiculos;
DELETE FROM domiciliarios;
DELETE FROM usuarios;
-------------
/*XTablas*/
DROP TABLE telefonos CASCADE CONSTRAINTS PURGE;
DROP TABLE barrios CASCADE CONSTRAINTS PURGE;
DROP TABLE vehiculos CASCADE CONSTRAINTS PURGE;
DROP TABLE recetasMedicas CASCADE CONSTRAINTS PURGE;
DROP TABLE pedidos CASCADE CONSTRAINTS PURGE;
DROP TABLE clientes CASCADE CONSTRAINTS PURGE;
DROP TABLE domiciliarios CASCADE CONSTRAINTS PURGE;
DROP TABLE usuarios CASCADE CONSTRAINTS PURGE;
DROP TABLE medicamentos CASCADE CONSTRAINTS PURGE;
DROP TABLE farmacias CASCADE CONSTRAINTS PURGE;
DROP TABLE zonas CASCADE CONSTRAINTS PURGE;
DROP TABLE ubicaciones CASCADE CONSTRAINTS PURGE;
DROP TABLE zonasActivas CASCADE CONSTRAINTS PURGE;